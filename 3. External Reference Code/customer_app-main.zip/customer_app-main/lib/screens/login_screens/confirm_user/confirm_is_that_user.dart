import 'package:customer_app/screens/login_screens/confirm_user/confirm_body.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';

class ConfirmThisUser extends StatelessWidget {
  static String routeName = '/ConfirmThatUser';
  @override
  Widget build(BuildContext context) {
    return new Scaffold(
      body: Body(),
    );
  }
}
