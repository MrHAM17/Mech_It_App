const FOOD_DATA = [
  {
    "name": "Fuel Recharge",
    "price": 70,
  },
  {
    "name": "wheels and tires",
    "price": 50,
  }
];
