class Center
{
  String placeFormattedAddress;
  String centerName;
  String centerId;
  double rating;
  String imageUrl;

  Center({this.placeFormattedAddress, this.centerName, this.centerId, this.rating, this.imageUrl});
}