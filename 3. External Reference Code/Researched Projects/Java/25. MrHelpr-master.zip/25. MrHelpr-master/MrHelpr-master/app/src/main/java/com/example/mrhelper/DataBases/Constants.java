package com.example.mrhelper.DataBases;

class Constants {
    static String KEY_PHONE_NO = "phoneNo";
    static String KEY_PASSWORD = "password";
}
