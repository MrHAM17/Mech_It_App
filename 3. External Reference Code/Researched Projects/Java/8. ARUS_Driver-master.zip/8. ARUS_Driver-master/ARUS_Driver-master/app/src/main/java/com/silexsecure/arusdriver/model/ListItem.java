package com.silexsecure.arusdriver.model;

public class ListItem {

    String item;

    public ListItem(String item) {
        this.item = item;
    }

    public String getItem() {
        return item;
    }

    public void setItem(String item) {
        this.item = item;
    }
}
