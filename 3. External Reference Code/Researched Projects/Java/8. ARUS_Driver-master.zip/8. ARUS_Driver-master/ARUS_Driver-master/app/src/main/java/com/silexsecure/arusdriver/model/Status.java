package com.silexsecure.arusdriver.model;

public class Status {

    String status;

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}