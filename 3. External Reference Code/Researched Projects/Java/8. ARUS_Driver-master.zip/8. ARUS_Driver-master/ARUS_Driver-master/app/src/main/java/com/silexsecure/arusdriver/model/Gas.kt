package com.silexsecure.arusdriver.model

class Gas (
    var GasSize : String? = null,
    var GasImage : Int? = 0,
    var GasQuantity : Double? = 0.0
)