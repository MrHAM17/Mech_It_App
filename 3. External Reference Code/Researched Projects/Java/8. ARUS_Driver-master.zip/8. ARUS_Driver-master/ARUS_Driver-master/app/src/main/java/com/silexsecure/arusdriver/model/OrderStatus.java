package com.silexsecure.arusdriver.model;

public enum OrderStatus {
    Delivered,
    DriverAssigned,
    Pending
}
