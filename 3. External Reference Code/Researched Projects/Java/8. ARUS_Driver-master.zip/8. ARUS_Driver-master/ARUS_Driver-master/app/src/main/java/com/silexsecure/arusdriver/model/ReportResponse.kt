package com.silexsecure.arusdriver.model

data class ReportResponse(
        val status: Int? = null,
        val message: String? = null,
        val records: String? = null
)