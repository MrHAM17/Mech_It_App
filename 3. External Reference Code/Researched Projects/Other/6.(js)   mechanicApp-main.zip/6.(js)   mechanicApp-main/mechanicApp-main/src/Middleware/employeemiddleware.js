// var myLogger = async function (req, res, next) {
// console.log(req.body);
//   req.headers(
//     'authorization',
//     'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImF1dG9icjEiLCJpZCI6IjVmYmY4YzU3NjY3NGIzNzU2ZDUxZDQxNCIsImV4cCI6MTYxMzczNjk4MCwicGVybWlzc2lvbnMiOnsiZ2xhc3NVcGxvYWRzIjpmYWxzZSwicGVybWl0dGVkTWFrZXMiOlsiSGF0Y2giLCJTZWRhbiIsIlNVViIsIlByZW1pdW0iXSwicGVybWl0dGVkVGFicyI6WyJzZWdtZW50YXRpb24iXX0sInVzZXJ0eXBlIjoiZGVhbGVyIiwiZGVhbGVyQ29kZSI6IkF1dG9icml4IiwiZGVhbGVyIjoiNWZiN2EzNjI1NWYxMWEzZDZjNDc4NGFiIiwibmFtZSI6ImF1dG9icjEiLCJzdGF0dXMiOiJhY3RpdmUiLCJkZWFsZXJHcm91cCI6W10sImlzQXZhaWxhYmxlT25saW5lIjpmYWxzZSwiY3VycmVuY3kiOiJJTlIiLCJsYW5ndWFnZSI6eyJpZCI6ImVuLXVzIiwidGl0bGUiOiJFbmdsaXNoIiwiZW5nbGlzaE5hbWUiOiJFbmdsaXNoIn0sImlhdCI6MTYwODU1Mjk4MH0.lokZvmqm-RABjdIaVtoCvpGjd2w6HEjgO-ALNYyBoi0'
//   );

//   beforeSend: () => {
//     request.setRequestHeader(
//       'Authorization',
//       'BEARER ' +
//         localStorage.getItem(
//           'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImF1dG9icjEiLCJpZCI6IjVmYmY4YzU3NjY3NGIzNzU2ZDUxZDQxNCIsImV4cCI6MTYxMzc0Mzc1NCwicGVybWlzc2lvbnMiOnsiZ2xhc3NVcGxvYWRzIjpmYWxzZSwicGVybWl0dGVkTWFrZXMiOlsiSGF0Y2giLCJTZWRhbiIsIlNVViIsIlByZW1pdW0iXSwicGVybWl0dGVkVGFicyI6WyJzZWdtZW50YXRpb24iXX0sInVzZXJ0eXBlIjoiZGVhbGVyIiwiZGVhbGVyQ29kZSI6IkF1dG9icml4IiwiZGVhbGVyIjoiNWZiN2EzNjI1NWYxMWEzZDZjNDc4NGFiIiwibmFtZSI6ImF1dG9icjEiLCJzdGF0dXMiOiJhY3RpdmUiLCJkZWFsZXJHcm91cCI6W10sImlzQXZhaWxhYmxlT25saW5lIjpmYWxzZSwiY3VycmVuY3kiOiJJTlIiLCJsYW5ndWFnZSI6eyJpZCI6ImVuLXVzIiwidGl0bGUiOiJFbmdsaXNoIiwiZW5nbGlzaE5hbWUiOiJFbmdsaXNoIn0sImlhdCI6MTYwODU1OTc1NH0.YHQIqq-Me0OaKbfdNqsH4hosysQh2FxMv_YTeCdRkRU'
//         )
//     );
//   };
//   next();
// };

// module.exports = myLogger;
