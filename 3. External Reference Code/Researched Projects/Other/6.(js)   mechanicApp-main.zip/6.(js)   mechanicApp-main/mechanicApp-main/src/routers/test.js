const file1 = (data) => console.log(data);

// const file2 = (data)=>{​​​​​​console.log(data)}​​​​​​;

// const file3 = (data) => { console.log(data) };

file1('hello');

// module.export ={​file1,file2,file3}​
