﻿namespace MechTech.UI.Cadastros
{
    partial class frmUpdateEmpresa
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmUpdateEmpresa));
            DevExpress.Utils.SerializableAppearanceObject serializableAppearanceObject1 = new DevExpress.Utils.SerializableAppearanceObject();
            DevExpress.Utils.SerializableAppearanceObject serializableAppearanceObject2 = new DevExpress.Utils.SerializableAppearanceObject();
            this.barManager = new DevExpress.XtraBars.BarManager();
            this.bar2 = new DevExpress.XtraBars.Bar();
            this.btnSalvar = new DevExpress.XtraBars.BarButtonItem();
            this.btnCancelar = new DevExpress.XtraBars.BarButtonItem();
            this.btnPrimeiro = new DevExpress.XtraBars.BarButtonItem();
            this.btnAnterior = new DevExpress.XtraBars.BarButtonItem();
            this.btnProximo = new DevExpress.XtraBars.BarButtonItem();
            this.btnUltimo = new DevExpress.XtraBars.BarButtonItem();
            this.barDockControlTop = new DevExpress.XtraBars.BarDockControl();
            this.barDockControlBottom = new DevExpress.XtraBars.BarDockControl();
            this.barDockControlLeft = new DevExpress.XtraBars.BarDockControl();
            this.barDockControlRight = new DevExpress.XtraBars.BarDockControl();
            this.EmpresaDTOBindingSource = new System.Windows.Forms.BindingSource();
            this.NaturezaJuridicaDTOBindingSource = new System.Windows.Forms.BindingSource();
            this.ClassifTributariaeSocialBindigSoutce = new System.Windows.Forms.BindingSource();
            this.MunicipioDTOBindingSource = new System.Windows.Forms.BindingSource();
            this.PorteDTOBindingSource = new System.Windows.Forms.BindingSource();
            this.dxErrorProvider = new DevExpress.XtraEditors.DXErrorProvider.DXErrorProvider();
            this.groupControlEmpresas = new DevExpress.XtraEditors.GroupControl();
            this.xtraTabControl = new DevExpress.XtraTab.XtraTabControl();
            this.xtraTabPage1 = new DevExpress.XtraTab.XtraTabPage();
            this.labelControl22 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl7 = new DevExpress.XtraEditors.LabelControl();
            this.cepTextEdit = new DevExpress.XtraEditors.ButtonEdit();
            this.labelControl13 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl17 = new DevExpress.XtraEditors.LabelControl();
            this.naturezajuridicaLookUpEdit = new DevExpress.XtraEditors.LookUpEdit();
            this.cnpjTextEdit = new DevExpress.XtraEditors.TextEdit();
            this.labelControl10 = new DevExpress.XtraEditors.LabelControl();
            this.municipioTextEdit = new DevExpress.XtraEditors.TextEdit();
            this.faxTextEdit = new DevExpress.XtraEditors.TextEdit();
            this.imunicipalTextEdit = new DevExpress.XtraEditors.TextEdit();
            this.rdgTipo = new DevExpress.XtraEditors.RadioGroup();
            this.labelControl41 = new DevExpress.XtraEditors.LabelControl();
            this.cnaeContainerControl = new DevExpress.XtraEditors.PopupContainerControl();
            this.treeView = new DevExpress.Utils.Design.DXTreeView();
            this.cnaeContainerEdit = new DevExpress.XtraEditors.PopupContainerEdit();
            this.telefoneTextEdit = new DevExpress.XtraEditors.TextEdit();
            this.groupControlContatos = new DevExpress.XtraEditors.GroupControl();
            this.urlTextEdit = new DevExpress.XtraEditors.TextEdit();
            this.emailTextEdit = new DevExpress.XtraEditors.TextEdit();
            this.labelControl25 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl24 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl23 = new DevExpress.XtraEditors.LabelControl();
            this.inicioatividadeDateEdit = new DevExpress.XtraEditors.DateEdit();
            this.labelControl21 = new DevExpress.XtraEditors.LabelControl();
            this.dataregistroDateEdit = new DevExpress.XtraEditors.DateEdit();
            this.labelControl20 = new DevExpress.XtraEditors.LabelControl();
            this.orgaoregistroTextEdit = new DevExpress.XtraEditors.TextEdit();
            this.labelControl19 = new DevExpress.XtraEditors.LabelControl();
            this.registroTextEdit = new DevExpress.XtraEditors.TextEdit();
            this.labelControl18 = new DevExpress.XtraEditors.LabelControl();
            this.encerratividadeDateEdit = new DevExpress.XtraEditors.DateEdit();
            this.labelControl16 = new DevExpress.XtraEditors.LabelControl();
            this.codigoibgeButtonEdit = new DevExpress.XtraEditors.ButtonEdit();
            this.labelControl15 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl14 = new DevExpress.XtraEditors.LabelControl();
            this.iestadualTextEdit = new DevExpress.XtraEditors.TextEdit();
            this.labelControl12 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl11 = new DevExpress.XtraEditors.LabelControl();
            this.dddfaxTextEdit = new DevExpress.XtraEditors.TextEdit();
            this.dddtelefoneTextEdit = new DevExpress.XtraEditors.TextEdit();
            this.UFTextEdit = new DevExpress.XtraEditors.TextEdit();
            this.labelControl9 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl8 = new DevExpress.XtraEditors.LabelControl();
            this.bairroTextEdit = new DevExpress.XtraEditors.TextEdit();
            this.labelControl6 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl5 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl4 = new DevExpress.XtraEditors.LabelControl();
            this.complementoTextEdit = new DevExpress.XtraEditors.TextEdit();
            this.numeroTextEdit = new DevExpress.XtraEditors.TextEdit();
            this.enderecoTextEdit = new DevExpress.XtraEditors.TextEdit();
            this.EspecialidadeTextEdit = new DevExpress.XtraEditors.TextEdit();
            this.labelControl3 = new DevExpress.XtraEditors.LabelControl();
            this.idTextEdit = new DevExpress.XtraEditors.TextEdit();
            this.nomefantasiaTextEdit = new DevExpress.XtraEditors.TextEdit();
            this.razaosocialTextEdit = new DevExpress.XtraEditors.TextEdit();
            this.labelControl1 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl2 = new DevExpress.XtraEditors.LabelControl();
            this.xtraTabPage2 = new DevExpress.XtraTab.XtraTabPage();
            this.LogotipoGroupControl = new DevExpress.XtraEditors.GroupControl();
            this.labelControl42 = new DevExpress.XtraEditors.LabelControl();
            this.LogotipoPictureEdit = new DevExpress.XtraEditors.PictureEdit();
            ((System.ComponentModel.ISupportInitialize)(this.barManager)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.EmpresaDTOBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NaturezaJuridicaDTOBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ClassifTributariaeSocialBindigSoutce)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.MunicipioDTOBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PorteDTOBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dxErrorProvider)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.groupControlEmpresas)).BeginInit();
            this.groupControlEmpresas.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.xtraTabControl)).BeginInit();
            this.xtraTabControl.SuspendLayout();
            this.xtraTabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.cepTextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.naturezajuridicaLookUpEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cnpjTextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.municipioTextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.faxTextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.imunicipalTextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rdgTipo.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cnaeContainerControl)).BeginInit();
            this.cnaeContainerControl.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.cnaeContainerEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.telefoneTextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.groupControlContatos)).BeginInit();
            this.groupControlContatos.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.urlTextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emailTextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.inicioatividadeDateEdit.Properties.CalendarTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.inicioatividadeDateEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataregistroDateEdit.Properties.CalendarTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataregistroDateEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.orgaoregistroTextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.registroTextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.encerratividadeDateEdit.Properties.CalendarTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.encerratividadeDateEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.codigoibgeButtonEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.iestadualTextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dddfaxTextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dddtelefoneTextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.UFTextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bairroTextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.complementoTextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numeroTextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.enderecoTextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.EspecialidadeTextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.idTextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nomefantasiaTextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.razaosocialTextEdit.Properties)).BeginInit();
            this.xtraTabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.LogotipoGroupControl)).BeginInit();
            this.LogotipoGroupControl.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.LogotipoPictureEdit.Properties)).BeginInit();
            this.SuspendLayout();
            // 
            // barManager
            // 
            this.barManager.Bars.AddRange(new DevExpress.XtraBars.Bar[] {
            this.bar2});
            this.barManager.DockControls.Add(this.barDockControlTop);
            this.barManager.DockControls.Add(this.barDockControlBottom);
            this.barManager.DockControls.Add(this.barDockControlLeft);
            this.barManager.DockControls.Add(this.barDockControlRight);
            this.barManager.Form = this;
            this.barManager.Items.AddRange(new DevExpress.XtraBars.BarItem[] {
            this.btnSalvar,
            this.btnCancelar,
            this.btnPrimeiro,
            this.btnAnterior,
            this.btnProximo,
            this.btnUltimo});
            this.barManager.MainMenu = this.bar2;
            this.barManager.MaxItemId = 6;
            // 
            // bar2
            // 
            this.bar2.BarName = "Main menu";
            this.bar2.DockCol = 0;
            this.bar2.DockRow = 0;
            this.bar2.DockStyle = DevExpress.XtraBars.BarDockStyle.Top;
            this.bar2.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(DevExpress.XtraBars.BarLinkUserDefines.PaintStyle, this.btnSalvar, DevExpress.XtraBars.BarItemPaintStyle.CaptionGlyph),
            new DevExpress.XtraBars.LinkPersistInfo(DevExpress.XtraBars.BarLinkUserDefines.PaintStyle, this.btnCancelar, DevExpress.XtraBars.BarItemPaintStyle.CaptionGlyph),
            new DevExpress.XtraBars.LinkPersistInfo(DevExpress.XtraBars.BarLinkUserDefines.PaintStyle, this.btnPrimeiro, DevExpress.XtraBars.BarItemPaintStyle.CaptionGlyph),
            new DevExpress.XtraBars.LinkPersistInfo(DevExpress.XtraBars.BarLinkUserDefines.PaintStyle, this.btnAnterior, DevExpress.XtraBars.BarItemPaintStyle.CaptionGlyph),
            new DevExpress.XtraBars.LinkPersistInfo(DevExpress.XtraBars.BarLinkUserDefines.PaintStyle, this.btnProximo, DevExpress.XtraBars.BarItemPaintStyle.CaptionGlyph),
            new DevExpress.XtraBars.LinkPersistInfo(DevExpress.XtraBars.BarLinkUserDefines.PaintStyle, this.btnUltimo, DevExpress.XtraBars.BarItemPaintStyle.CaptionGlyph)});
            this.bar2.OptionsBar.AllowQuickCustomization = false;
            this.bar2.OptionsBar.DrawBorder = false;
            this.bar2.OptionsBar.UseWholeRow = true;
            this.bar2.Text = "Menu principal";
            // 
            // btnSalvar
            // 
            this.btnSalvar.Caption = "&Salvar";
            this.btnSalvar.Glyph = ((System.Drawing.Image)(resources.GetObject("btnSalvar.Glyph")));
            this.btnSalvar.Id = 0;
            this.btnSalvar.LargeGlyph = ((System.Drawing.Image)(resources.GetObject("btnSalvar.LargeGlyph")));
            this.btnSalvar.Name = "btnSalvar";
            this.btnSalvar.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnSalvar_ItemClick);
            // 
            // btnCancelar
            // 
            this.btnCancelar.Caption = "&Cancelar";
            this.btnCancelar.Glyph = ((System.Drawing.Image)(resources.GetObject("btnCancelar.Glyph")));
            this.btnCancelar.Id = 1;
            this.btnCancelar.LargeGlyph = ((System.Drawing.Image)(resources.GetObject("btnCancelar.LargeGlyph")));
            this.btnCancelar.Name = "btnCancelar";
            this.btnCancelar.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnCancelar_ItemClick);
            // 
            // btnPrimeiro
            // 
            this.btnPrimeiro.Caption = "&Primeiro";
            this.btnPrimeiro.Glyph = ((System.Drawing.Image)(resources.GetObject("btnPrimeiro.Glyph")));
            this.btnPrimeiro.Id = 2;
            this.btnPrimeiro.LargeGlyph = ((System.Drawing.Image)(resources.GetObject("btnPrimeiro.LargeGlyph")));
            this.btnPrimeiro.Name = "btnPrimeiro";
            this.btnPrimeiro.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnPrimeiro_ItemClick);
            // 
            // btnAnterior
            // 
            this.btnAnterior.Caption = "&Anterior";
            this.btnAnterior.Glyph = ((System.Drawing.Image)(resources.GetObject("btnAnterior.Glyph")));
            this.btnAnterior.Id = 3;
            this.btnAnterior.LargeGlyph = ((System.Drawing.Image)(resources.GetObject("btnAnterior.LargeGlyph")));
            this.btnAnterior.Name = "btnAnterior";
            this.btnAnterior.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnAnterior_ItemClick);
            // 
            // btnProximo
            // 
            this.btnProximo.Caption = "P&róximo";
            this.btnProximo.Glyph = ((System.Drawing.Image)(resources.GetObject("btnProximo.Glyph")));
            this.btnProximo.Id = 4;
            this.btnProximo.LargeGlyph = ((System.Drawing.Image)(resources.GetObject("btnProximo.LargeGlyph")));
            this.btnProximo.Name = "btnProximo";
            this.btnProximo.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnProximo_ItemClick);
            // 
            // btnUltimo
            // 
            this.btnUltimo.Caption = "&Último";
            this.btnUltimo.Glyph = ((System.Drawing.Image)(resources.GetObject("btnUltimo.Glyph")));
            this.btnUltimo.Id = 5;
            this.btnUltimo.LargeGlyph = ((System.Drawing.Image)(resources.GetObject("btnUltimo.LargeGlyph")));
            this.btnUltimo.Name = "btnUltimo";
            this.btnUltimo.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnUltimo_ItemClick);
            // 
            // barDockControlTop
            // 
            this.barDockControlTop.CausesValidation = false;
            this.barDockControlTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.barDockControlTop.Location = new System.Drawing.Point(0, 0);
            this.barDockControlTop.Size = new System.Drawing.Size(1020, 24);
            // 
            // barDockControlBottom
            // 
            this.barDockControlBottom.CausesValidation = false;
            this.barDockControlBottom.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.barDockControlBottom.Location = new System.Drawing.Point(0, 574);
            this.barDockControlBottom.Size = new System.Drawing.Size(1020, 0);
            // 
            // barDockControlLeft
            // 
            this.barDockControlLeft.CausesValidation = false;
            this.barDockControlLeft.Dock = System.Windows.Forms.DockStyle.Left;
            this.barDockControlLeft.Location = new System.Drawing.Point(0, 24);
            this.barDockControlLeft.Size = new System.Drawing.Size(0, 550);
            // 
            // barDockControlRight
            // 
            this.barDockControlRight.CausesValidation = false;
            this.barDockControlRight.Dock = System.Windows.Forms.DockStyle.Right;
            this.barDockControlRight.Location = new System.Drawing.Point(1020, 24);
            this.barDockControlRight.Size = new System.Drawing.Size(0, 550);
            // 
            // EmpresaDTOBindingSource
            // 
            this.EmpresaDTOBindingSource.DataSource = typeof(MechTech.Entities.EmpresaDTO);
            // 
            // NaturezaJuridicaDTOBindingSource
            // 
            this.NaturezaJuridicaDTOBindingSource.DataSource = typeof(MechTech.Entities.NaturezaJuridicaDTO);
            // 
            // ClassifTributariaeSocialBindigSoutce
            // 
            this.ClassifTributariaeSocialBindigSoutce.DataSource = typeof(MechTech.Entities.ClassifTributariaDTO);
            // 
            // MunicipioDTOBindingSource
            // 
            this.MunicipioDTOBindingSource.DataSource = typeof(MechTech.Entities.MunicipioDTO);
            // 
            // PorteDTOBindingSource
            // 
            this.PorteDTOBindingSource.DataSource = typeof(MechTech.Entities.PorteDTO);
            // 
            // dxErrorProvider
            // 
            this.dxErrorProvider.ContainerControl = this;
            // 
            // groupControlEmpresas
            // 
            this.groupControlEmpresas.AppearanceCaption.Options.UseTextOptions = true;
            this.groupControlEmpresas.AppearanceCaption.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.groupControlEmpresas.CaptionLocation = DevExpress.Utils.Locations.Left;
            this.groupControlEmpresas.Controls.Add(this.xtraTabControl);
            this.groupControlEmpresas.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupControlEmpresas.Location = new System.Drawing.Point(0, 24);
            this.groupControlEmpresas.Name = "groupControlEmpresas";
            this.groupControlEmpresas.Size = new System.Drawing.Size(1020, 550);
            this.groupControlEmpresas.TabIndex = 4;
            this.groupControlEmpresas.Text = "Empresas";
            // 
            // xtraTabControl
            // 
            this.xtraTabControl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.xtraTabControl.Location = new System.Drawing.Point(21, 2);
            this.xtraTabControl.Name = "xtraTabControl";
            this.xtraTabControl.SelectedTabPage = this.xtraTabPage1;
            this.xtraTabControl.Size = new System.Drawing.Size(997, 546);
            this.xtraTabControl.TabIndex = 0;
            this.xtraTabControl.TabPages.AddRange(new DevExpress.XtraTab.XtraTabPage[] {
            this.xtraTabPage1,
            this.xtraTabPage2});
            // 
            // xtraTabPage1
            // 
            this.xtraTabPage1.Controls.Add(this.labelControl22);
            this.xtraTabPage1.Controls.Add(this.labelControl7);
            this.xtraTabPage1.Controls.Add(this.cepTextEdit);
            this.xtraTabPage1.Controls.Add(this.labelControl13);
            this.xtraTabPage1.Controls.Add(this.labelControl17);
            this.xtraTabPage1.Controls.Add(this.naturezajuridicaLookUpEdit);
            this.xtraTabPage1.Controls.Add(this.cnpjTextEdit);
            this.xtraTabPage1.Controls.Add(this.labelControl10);
            this.xtraTabPage1.Controls.Add(this.municipioTextEdit);
            this.xtraTabPage1.Controls.Add(this.faxTextEdit);
            this.xtraTabPage1.Controls.Add(this.imunicipalTextEdit);
            this.xtraTabPage1.Controls.Add(this.rdgTipo);
            this.xtraTabPage1.Controls.Add(this.labelControl41);
            this.xtraTabPage1.Controls.Add(this.cnaeContainerControl);
            this.xtraTabPage1.Controls.Add(this.cnaeContainerEdit);
            this.xtraTabPage1.Controls.Add(this.telefoneTextEdit);
            this.xtraTabPage1.Controls.Add(this.groupControlContatos);
            this.xtraTabPage1.Controls.Add(this.labelControl23);
            this.xtraTabPage1.Controls.Add(this.inicioatividadeDateEdit);
            this.xtraTabPage1.Controls.Add(this.labelControl21);
            this.xtraTabPage1.Controls.Add(this.dataregistroDateEdit);
            this.xtraTabPage1.Controls.Add(this.labelControl20);
            this.xtraTabPage1.Controls.Add(this.orgaoregistroTextEdit);
            this.xtraTabPage1.Controls.Add(this.labelControl19);
            this.xtraTabPage1.Controls.Add(this.registroTextEdit);
            this.xtraTabPage1.Controls.Add(this.labelControl18);
            this.xtraTabPage1.Controls.Add(this.encerratividadeDateEdit);
            this.xtraTabPage1.Controls.Add(this.labelControl16);
            this.xtraTabPage1.Controls.Add(this.codigoibgeButtonEdit);
            this.xtraTabPage1.Controls.Add(this.labelControl15);
            this.xtraTabPage1.Controls.Add(this.labelControl14);
            this.xtraTabPage1.Controls.Add(this.iestadualTextEdit);
            this.xtraTabPage1.Controls.Add(this.labelControl12);
            this.xtraTabPage1.Controls.Add(this.labelControl11);
            this.xtraTabPage1.Controls.Add(this.dddfaxTextEdit);
            this.xtraTabPage1.Controls.Add(this.dddtelefoneTextEdit);
            this.xtraTabPage1.Controls.Add(this.UFTextEdit);
            this.xtraTabPage1.Controls.Add(this.labelControl9);
            this.xtraTabPage1.Controls.Add(this.labelControl8);
            this.xtraTabPage1.Controls.Add(this.bairroTextEdit);
            this.xtraTabPage1.Controls.Add(this.labelControl6);
            this.xtraTabPage1.Controls.Add(this.labelControl5);
            this.xtraTabPage1.Controls.Add(this.labelControl4);
            this.xtraTabPage1.Controls.Add(this.complementoTextEdit);
            this.xtraTabPage1.Controls.Add(this.numeroTextEdit);
            this.xtraTabPage1.Controls.Add(this.enderecoTextEdit);
            this.xtraTabPage1.Controls.Add(this.EspecialidadeTextEdit);
            this.xtraTabPage1.Controls.Add(this.labelControl3);
            this.xtraTabPage1.Controls.Add(this.idTextEdit);
            this.xtraTabPage1.Controls.Add(this.nomefantasiaTextEdit);
            this.xtraTabPage1.Controls.Add(this.razaosocialTextEdit);
            this.xtraTabPage1.Controls.Add(this.labelControl1);
            this.xtraTabPage1.Controls.Add(this.labelControl2);
            this.xtraTabPage1.Name = "xtraTabPage1";
            this.xtraTabPage1.Size = new System.Drawing.Size(991, 518);
            this.xtraTabPage1.Text = "Básico";
            // 
            // labelControl22
            // 
            this.labelControl22.Location = new System.Drawing.Point(3, 227);
            this.labelControl22.Name = "labelControl22";
            this.labelControl22.Size = new System.Drawing.Size(29, 13);
            this.labelControl22.TabIndex = 105;
            this.labelControl22.Text = "Início:";
            // 
            // labelControl7
            // 
            this.labelControl7.Location = new System.Drawing.Point(3, 120);
            this.labelControl7.Name = "labelControl7";
            this.labelControl7.Size = new System.Drawing.Size(32, 13);
            this.labelControl7.TabIndex = 104;
            this.labelControl7.Text = "Bairro:";
            // 
            // cepTextEdit
            // 
            this.cepTextEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.EmpresaDTOBindingSource, "Cep", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.cepTextEdit.EnterMoveNextControl = true;
            this.cepTextEdit.Location = new System.Drawing.Point(82, 67);
            this.cepTextEdit.Name = "cepTextEdit";
            this.cepTextEdit.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Glyph, "", -1, true, true, false, DevExpress.XtraEditors.ImageLocation.MiddleCenter, ((System.Drawing.Image)(resources.GetObject("cepTextEdit.Properties.Buttons"))), new DevExpress.Utils.KeyShortcut(System.Windows.Forms.Keys.None), serializableAppearanceObject1, "", null, null, false)});
            this.cepTextEdit.Properties.Mask.EditMask = "99.999-999";
            this.cepTextEdit.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Simple;
            this.cepTextEdit.Properties.Mask.SaveLiteral = false;
            this.cepTextEdit.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.cepTextEdit.Properties.MaxLength = 8;
            this.cepTextEdit.Size = new System.Drawing.Size(85, 22);
            this.cepTextEdit.TabIndex = 4;
            this.cepTextEdit.ToolTip = "Código de endereçamento postal fornecido pelos CORREIOS";
            this.cepTextEdit.ButtonClick += new DevExpress.XtraEditors.Controls.ButtonPressedEventHandler(this.cepTextEdit_ButtonClick);
            // 
            // labelControl13
            // 
            this.labelControl13.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl13.Location = new System.Drawing.Point(467, 149);
            this.labelControl13.Name = "labelControl13";
            this.labelControl13.Size = new System.Drawing.Size(0, 13);
            this.labelControl13.TabIndex = 91;
            // 
            // labelControl17
            // 
            this.labelControl17.Location = new System.Drawing.Point(415, 175);
            this.labelControl17.Name = "labelControl17";
            this.labelControl17.Size = new System.Drawing.Size(64, 13);
            this.labelControl17.TabIndex = 95;
            this.labelControl17.Text = "Nat. Jurídica:";
            this.labelControl17.ToolTip = "Natureza Jurídica";
            // 
            // naturezajuridicaLookUpEdit
            // 
            this.naturezajuridicaLookUpEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.EmpresaDTOBindingSource, "Naturezajuridica.Id", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.naturezajuridicaLookUpEdit.EnterMoveNextControl = true;
            this.naturezajuridicaLookUpEdit.Location = new System.Drawing.Point(485, 172);
            this.naturezajuridicaLookUpEdit.Name = "naturezajuridicaLookUpEdit";
            this.naturezajuridicaLookUpEdit.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.naturezajuridicaLookUpEdit.Properties.Columns.AddRange(new DevExpress.XtraEditors.Controls.LookUpColumnInfo[] {
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("Codigo", "Código", 10, DevExpress.Utils.FormatType.None, "", true, DevExpress.Utils.HorzAlignment.Center),
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("Descricao", 55, "Descrição")});
            this.naturezajuridicaLookUpEdit.Properties.DataSource = this.NaturezaJuridicaDTOBindingSource;
            this.naturezajuridicaLookUpEdit.Properties.DisplayMember = "Codigo";
            this.naturezajuridicaLookUpEdit.Properties.NullText = "";
            this.naturezajuridicaLookUpEdit.Properties.PopupWidth = 400;
            this.naturezajuridicaLookUpEdit.Properties.ValueMember = "Id";
            this.naturezajuridicaLookUpEdit.Size = new System.Drawing.Size(177, 20);
            this.naturezajuridicaLookUpEdit.TabIndex = 19;
            // 
            // cnpjTextEdit
            // 
            this.cnpjTextEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.EmpresaDTOBindingSource, "Cnpj", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.cnpjTextEdit.EnterMoveNextControl = true;
            this.cnpjTextEdit.Location = new System.Drawing.Point(485, 146);
            this.cnpjTextEdit.Name = "cnpjTextEdit";
            this.cnpjTextEdit.Properties.Mask.EditMask = "99.999.999/9999-99";
            this.cnpjTextEdit.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Simple;
            this.cnpjTextEdit.Properties.Mask.SaveLiteral = false;
            this.cnpjTextEdit.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.cnpjTextEdit.Properties.MaxLength = 14;
            this.cnpjTextEdit.Size = new System.Drawing.Size(177, 20);
            this.cnpjTextEdit.TabIndex = 16;
            // 
            // labelControl10
            // 
            this.labelControl10.Location = new System.Drawing.Point(170, 71);
            this.labelControl10.Name = "labelControl10";
            this.labelControl10.Size = new System.Drawing.Size(17, 13);
            this.labelControl10.TabIndex = 82;
            this.labelControl10.Text = "UF:";
            this.labelControl10.ToolTip = "Unidade Federativa (Estados)";
            // 
            // municipioTextEdit
            // 
            this.municipioTextEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.EmpresaDTOBindingSource, "Municipio.Nome", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.municipioTextEdit.EnterMoveNextControl = true;
            this.municipioTextEdit.Location = new System.Drawing.Point(485, 67);
            this.municipioTextEdit.Name = "municipioTextEdit";
            this.municipioTextEdit.Properties.ReadOnly = true;
            this.municipioTextEdit.Size = new System.Drawing.Size(177, 20);
            this.municipioTextEdit.TabIndex = 7;
            this.municipioTextEdit.TabStop = false;
            // 
            // faxTextEdit
            // 
            this.faxTextEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.EmpresaDTOBindingSource, "Fax", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.faxTextEdit.EnterMoveNextControl = true;
            this.faxTextEdit.Location = new System.Drawing.Point(318, 146);
            this.faxTextEdit.Name = "faxTextEdit";
            this.faxTextEdit.Properties.MaxLength = 9;
            this.faxTextEdit.Size = new System.Drawing.Size(91, 20);
            this.faxTextEdit.TabIndex = 15;
            // 
            // imunicipalTextEdit
            // 
            this.imunicipalTextEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.EmpresaDTOBindingSource, "Imunicipal", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.imunicipalTextEdit.EnterMoveNextControl = true;
            this.imunicipalTextEdit.Location = new System.Drawing.Point(277, 172);
            this.imunicipalTextEdit.Name = "imunicipalTextEdit";
            this.imunicipalTextEdit.Properties.MaxLength = 10;
            this.imunicipalTextEdit.Size = new System.Drawing.Size(132, 20);
            this.imunicipalTextEdit.TabIndex = 18;
            this.imunicipalTextEdit.ToolTip = "Número da Inscrição Municipal";
            // 
            // rdgTipo
            // 
            this.rdgTipo.Location = new System.Drawing.Point(410, 136);
            this.rdgTipo.Name = "rdgTipo";
            this.rdgTipo.Properties.Appearance.BackColor = System.Drawing.Color.Transparent;
            this.rdgTipo.Properties.Appearance.Options.UseBackColor = true;
            this.rdgTipo.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.rdgTipo.Properties.Items.AddRange(new DevExpress.XtraEditors.Controls.RadioGroupItem[] {
            new DevExpress.XtraEditors.Controls.RadioGroupItem(null, "CNPJ"),
            new DevExpress.XtraEditors.Controls.RadioGroupItem(null, "CPF")});
            this.rdgTipo.Size = new System.Drawing.Size(75, 42);
            this.rdgTipo.TabIndex = 77;
            this.rdgTipo.TabStop = false;
            this.rdgTipo.SelectedIndexChanged += new System.EventHandler(this.rdgTipo_SelectedIndexChanged);
            // 
            // labelControl41
            // 
            this.labelControl41.Location = new System.Drawing.Point(3, 253);
            this.labelControl41.Name = "labelControl41";
            this.labelControl41.Size = new System.Drawing.Size(59, 13);
            this.labelControl41.TabIndex = 103;
            this.labelControl41.Text = "Esp. Estab.:";
            this.labelControl41.ToolTip = "Especialidade do Estabelecimento";
            // 
            // cnaeContainerControl
            // 
            this.cnaeContainerControl.Controls.Add(this.treeView);
            this.cnaeContainerControl.Location = new System.Drawing.Point(216, 246);
            this.cnaeContainerControl.Name = "cnaeContainerControl";
            this.cnaeContainerControl.Size = new System.Drawing.Size(465, 360);
            this.cnaeContainerControl.TabIndex = 102;
            // 
            // treeView
            // 
            this.treeView.AllowHScrollBar = true;
            this.treeView.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.treeView.DefaultExpandCollapseButtonOffset = 5;
            this.treeView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.treeView.Location = new System.Drawing.Point(0, 0);
            this.treeView.Name = "treeView";
            this.treeView.SelectionMode = DevExpress.Utils.Design.DXTreeSelectionMode.MultiSelectChildrenSameBranch;
            this.treeView.Size = new System.Drawing.Size(465, 360);
            this.treeView.TabIndex = 2;
            this.treeView.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.treeView_AfterSelect);
            this.treeView.NodeMouseDoubleClick += new System.Windows.Forms.TreeNodeMouseClickEventHandler(this.treeView_NodeMouseDoubleClick);
            this.treeView.KeyDown += new System.Windows.Forms.KeyEventHandler(this.treeView_KeyDown);
            // 
            // cnaeContainerEdit
            // 
            this.cnaeContainerEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.EmpresaDTOBindingSource, "CNAE.codigo", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.cnaeContainerEdit.EditValue = "";
            this.cnaeContainerEdit.EnterMoveNextControl = true;
            this.cnaeContainerEdit.Location = new System.Drawing.Point(485, 224);
            this.cnaeContainerEdit.Name = "cnaeContainerEdit";
            this.cnaeContainerEdit.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.cnaeContainerEdit.Properties.PopupControl = this.cnaeContainerControl;
            this.cnaeContainerEdit.Size = new System.Drawing.Size(177, 20);
            this.cnaeContainerEdit.TabIndex = 25;
            this.cnaeContainerEdit.Popup += new System.EventHandler(this.cnaeContainerEdit_Popup);
            this.cnaeContainerEdit.EditValueChanged += new System.EventHandler(this.cnaeContainerEdit_EditValueChanged);
            // 
            // telefoneTextEdit
            // 
            this.telefoneTextEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.EmpresaDTOBindingSource, "Telefone", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.telefoneTextEdit.EnterMoveNextControl = true;
            this.telefoneTextEdit.Location = new System.Drawing.Point(123, 146);
            this.telefoneTextEdit.Name = "telefoneTextEdit";
            this.telefoneTextEdit.Properties.Mask.EditMask = "(999)0000-0000";
            this.telefoneTextEdit.Properties.MaxLength = 9;
            this.telefoneTextEdit.Size = new System.Drawing.Size(90, 20);
            this.telefoneTextEdit.TabIndex = 13;
            // 
            // groupControlContatos
            // 
            this.groupControlContatos.Controls.Add(this.urlTextEdit);
            this.groupControlContatos.Controls.Add(this.emailTextEdit);
            this.groupControlContatos.Controls.Add(this.labelControl25);
            this.groupControlContatos.Controls.Add(this.labelControl24);
            this.groupControlContatos.Location = new System.Drawing.Point(3, 276);
            this.groupControlContatos.Name = "groupControlContatos";
            this.groupControlContatos.Size = new System.Drawing.Size(613, 76);
            this.groupControlContatos.TabIndex = 26;
            this.groupControlContatos.Text = "Contatos";
            // 
            // urlTextEdit
            // 
            this.urlTextEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.EmpresaDTOBindingSource, "Url", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.urlTextEdit.EnterMoveNextControl = true;
            this.urlTextEdit.Location = new System.Drawing.Point(42, 25);
            this.urlTextEdit.Name = "urlTextEdit";
            this.urlTextEdit.Properties.MaxLength = 60;
            this.urlTextEdit.Size = new System.Drawing.Size(565, 20);
            this.urlTextEdit.TabIndex = 27;
            this.urlTextEdit.ToolTip = "Endereço na internet da empresa";
            // 
            // emailTextEdit
            // 
            this.emailTextEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.EmpresaDTOBindingSource, "Email", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.emailTextEdit.EnterMoveNextControl = true;
            this.emailTextEdit.Location = new System.Drawing.Point(42, 51);
            this.emailTextEdit.Name = "emailTextEdit";
            this.emailTextEdit.Properties.MaxLength = 60;
            this.emailTextEdit.Size = new System.Drawing.Size(565, 20);
            this.emailTextEdit.TabIndex = 28;
            this.emailTextEdit.ToolTip = "Endereço de email da empresa para contato";
            // 
            // labelControl25
            // 
            this.labelControl25.Location = new System.Drawing.Point(5, 54);
            this.labelControl25.Name = "labelControl25";
            this.labelControl25.Size = new System.Drawing.Size(28, 13);
            this.labelControl25.TabIndex = 54;
            this.labelControl25.Text = "Email:";
            // 
            // labelControl24
            // 
            this.labelControl24.Location = new System.Drawing.Point(5, 28);
            this.labelControl24.Name = "labelControl24";
            this.labelControl24.Size = new System.Drawing.Size(22, 13);
            this.labelControl24.TabIndex = 53;
            this.labelControl24.Text = "Site:";
            // 
            // labelControl23
            // 
            this.labelControl23.Location = new System.Drawing.Point(415, 227);
            this.labelControl23.Name = "labelControl23";
            this.labelControl23.Size = new System.Drawing.Size(31, 13);
            this.labelControl23.TabIndex = 100;
            this.labelControl23.Text = "CNAE:";
            // 
            // inicioatividadeDateEdit
            // 
            this.inicioatividadeDateEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.EmpresaDTOBindingSource, "Inicioatividade", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.inicioatividadeDateEdit.EditValue = null;
            this.inicioatividadeDateEdit.EnterMoveNextControl = true;
            this.inicioatividadeDateEdit.Location = new System.Drawing.Point(82, 224);
            this.inicioatividadeDateEdit.Name = "inicioatividadeDateEdit";
            this.inicioatividadeDateEdit.Properties.Appearance.Options.UseTextOptions = true;
            this.inicioatividadeDateEdit.Properties.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.inicioatividadeDateEdit.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.inicioatividadeDateEdit.Properties.CalendarTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            this.inicioatividadeDateEdit.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.DateTimeAdvancingCaret;
            this.inicioatividadeDateEdit.Size = new System.Drawing.Size(131, 20);
            this.inicioatividadeDateEdit.TabIndex = 23;
            this.inicioatividadeDateEdit.ToolTip = "Data do início das atividades da empresa";
            // 
            // labelControl21
            // 
            this.labelControl21.Location = new System.Drawing.Point(415, 201);
            this.labelControl21.Name = "labelControl21";
            this.labelControl21.Size = new System.Drawing.Size(67, 13);
            this.labelControl21.TabIndex = 99;
            this.labelControl21.Text = "Data registro:";
            this.labelControl21.ToolTip = "Data de registro";
            // 
            // dataregistroDateEdit
            // 
            this.dataregistroDateEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.EmpresaDTOBindingSource, "Dataregistro", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.dataregistroDateEdit.EditValue = null;
            this.dataregistroDateEdit.EnterMoveNextControl = true;
            this.dataregistroDateEdit.Location = new System.Drawing.Point(485, 198);
            this.dataregistroDateEdit.Name = "dataregistroDateEdit";
            this.dataregistroDateEdit.Properties.Appearance.Options.UseTextOptions = true;
            this.dataregistroDateEdit.Properties.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.dataregistroDateEdit.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.dataregistroDateEdit.Properties.CalendarTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            this.dataregistroDateEdit.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.DateTimeAdvancingCaret;
            this.dataregistroDateEdit.Size = new System.Drawing.Size(177, 20);
            this.dataregistroDateEdit.TabIndex = 22;
            this.dataregistroDateEdit.ToolTip = "Data do registro no orgão competente";
            // 
            // labelControl20
            // 
            this.labelControl20.Location = new System.Drawing.Point(219, 201);
            this.labelControl20.Name = "labelControl20";
            this.labelControl20.Size = new System.Drawing.Size(34, 13);
            this.labelControl20.TabIndex = 98;
            this.labelControl20.Text = "Órgão:";
            // 
            // orgaoregistroTextEdit
            // 
            this.orgaoregistroTextEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.EmpresaDTOBindingSource, "Orgaoregistro", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.orgaoregistroTextEdit.EnterMoveNextControl = true;
            this.orgaoregistroTextEdit.Location = new System.Drawing.Point(277, 198);
            this.orgaoregistroTextEdit.Name = "orgaoregistroTextEdit";
            this.orgaoregistroTextEdit.Properties.MaxLength = 20;
            this.orgaoregistroTextEdit.Size = new System.Drawing.Size(132, 20);
            this.orgaoregistroTextEdit.TabIndex = 21;
            this.orgaoregistroTextEdit.ToolTip = "Nome abreviado do orgão de registro";
            // 
            // labelControl19
            // 
            this.labelControl19.Location = new System.Drawing.Point(3, 201);
            this.labelControl19.Name = "labelControl19";
            this.labelControl19.Size = new System.Drawing.Size(44, 13);
            this.labelControl19.TabIndex = 97;
            this.labelControl19.Text = "Registro:";
            // 
            // registroTextEdit
            // 
            this.registroTextEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.EmpresaDTOBindingSource, "Registro", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.registroTextEdit.EnterMoveNextControl = true;
            this.registroTextEdit.Location = new System.Drawing.Point(82, 198);
            this.registroTextEdit.Name = "registroTextEdit";
            this.registroTextEdit.Properties.MaxLength = 20;
            this.registroTextEdit.Size = new System.Drawing.Size(131, 20);
            this.registroTextEdit.TabIndex = 20;
            this.registroTextEdit.ToolTip = "Número do registro em orgão competente, junta comercial, cartório, etc";
            // 
            // labelControl18
            // 
            this.labelControl18.Location = new System.Drawing.Point(219, 227);
            this.labelControl18.Name = "labelControl18";
            this.labelControl18.Size = new System.Drawing.Size(53, 13);
            this.labelControl18.TabIndex = 96;
            this.labelControl18.Text = "Encerram.:";
            this.labelControl18.ToolTip = "Data de encerramento das atividades";
            // 
            // encerratividadeDateEdit
            // 
            this.encerratividadeDateEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.EmpresaDTOBindingSource, "Encerratividade", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.encerratividadeDateEdit.EditValue = null;
            this.encerratividadeDateEdit.EnterMoveNextControl = true;
            this.encerratividadeDateEdit.Location = new System.Drawing.Point(278, 224);
            this.encerratividadeDateEdit.Name = "encerratividadeDateEdit";
            this.encerratividadeDateEdit.Properties.Appearance.Options.UseTextOptions = true;
            this.encerratividadeDateEdit.Properties.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.encerratividadeDateEdit.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.encerratividadeDateEdit.Properties.CalendarTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            this.encerratividadeDateEdit.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.DateTimeAdvancingCaret;
            this.encerratividadeDateEdit.Size = new System.Drawing.Size(131, 20);
            this.encerratividadeDateEdit.TabIndex = 24;
            this.encerratividadeDateEdit.ToolTip = "Data do encerramento das atividades da empresa";
            // 
            // labelControl16
            // 
            this.labelControl16.Location = new System.Drawing.Point(415, 71);
            this.labelControl16.Name = "labelControl16";
            this.labelControl16.Size = new System.Drawing.Size(47, 13);
            this.labelControl16.TabIndex = 94;
            this.labelControl16.Text = "Município:";
            // 
            // codigoibgeButtonEdit
            // 
            this.codigoibgeButtonEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.EmpresaDTOBindingSource, "Municipio.Codigoibge", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.codigoibgeButtonEdit.EnterMoveNextControl = true;
            this.codigoibgeButtonEdit.Location = new System.Drawing.Point(278, 67);
            this.codigoibgeButtonEdit.Name = "codigoibgeButtonEdit";
            this.codigoibgeButtonEdit.Properties.Appearance.Options.UseTextOptions = true;
            this.codigoibgeButtonEdit.Properties.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.codigoibgeButtonEdit.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Glyph, "", -1, true, true, false, DevExpress.XtraEditors.ImageLocation.MiddleCenter, ((System.Drawing.Image)(resources.GetObject("codigoibgeButtonEdit.Properties.Buttons"))), new DevExpress.Utils.KeyShortcut(System.Windows.Forms.Keys.None), serializableAppearanceObject2, "", null, null, true)});
            this.codigoibgeButtonEdit.Properties.Mask.EditMask = "d";
            this.codigoibgeButtonEdit.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.codigoibgeButtonEdit.Size = new System.Drawing.Size(131, 22);
            this.codigoibgeButtonEdit.TabIndex = 6;
            this.codigoibgeButtonEdit.ButtonClick += new DevExpress.XtraEditors.Controls.ButtonPressedEventHandler(this.codigoibgeButtonEdit_ButtonClick);
            this.codigoibgeButtonEdit.Validated += new System.EventHandler(this.codigoibgeButtonEdit_Validated);
            // 
            // labelControl15
            // 
            this.labelControl15.Location = new System.Drawing.Point(219, 175);
            this.labelControl15.Name = "labelControl15";
            this.labelControl15.Size = new System.Drawing.Size(55, 13);
            this.labelControl15.TabIndex = 93;
            this.labelControl15.Text = "Insc. Mun.:";
            this.labelControl15.ToolTip = "Inscrição Municipal";
            // 
            // labelControl14
            // 
            this.labelControl14.Location = new System.Drawing.Point(3, 175);
            this.labelControl14.Name = "labelControl14";
            this.labelControl14.Size = new System.Drawing.Size(72, 13);
            this.labelControl14.TabIndex = 92;
            this.labelControl14.Text = "Insc. Estadual:";
            this.labelControl14.ToolTip = "Inscrição Estadual";
            // 
            // iestadualTextEdit
            // 
            this.iestadualTextEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.EmpresaDTOBindingSource, "Iestadual", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.iestadualTextEdit.EnterMoveNextControl = true;
            this.iestadualTextEdit.Location = new System.Drawing.Point(82, 172);
            this.iestadualTextEdit.Name = "iestadualTextEdit";
            this.iestadualTextEdit.Properties.MaxLength = 20;
            this.iestadualTextEdit.Size = new System.Drawing.Size(131, 20);
            this.iestadualTextEdit.TabIndex = 17;
            this.iestadualTextEdit.ToolTip = "Número da Inscrição Estadual";
            // 
            // labelControl12
            // 
            this.labelControl12.Location = new System.Drawing.Point(219, 149);
            this.labelControl12.Name = "labelControl12";
            this.labelControl12.Size = new System.Drawing.Size(22, 13);
            this.labelControl12.TabIndex = 89;
            this.labelControl12.Text = "Fax:";
            // 
            // labelControl11
            // 
            this.labelControl11.Location = new System.Drawing.Point(3, 149);
            this.labelControl11.Name = "labelControl11";
            this.labelControl11.Size = new System.Drawing.Size(46, 13);
            this.labelControl11.TabIndex = 88;
            this.labelControl11.Text = "Telefone:";
            // 
            // dddfaxTextEdit
            // 
            this.dddfaxTextEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.EmpresaDTOBindingSource, "Dddfax", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.dddfaxTextEdit.EnterMoveNextControl = true;
            this.dddfaxTextEdit.Location = new System.Drawing.Point(277, 146);
            this.dddfaxTextEdit.Name = "dddfaxTextEdit";
            this.dddfaxTextEdit.Properties.Appearance.Options.UseTextOptions = true;
            this.dddfaxTextEdit.Properties.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.dddfaxTextEdit.Properties.MaxLength = 2;
            this.dddfaxTextEdit.Size = new System.Drawing.Size(35, 20);
            this.dddfaxTextEdit.TabIndex = 14;
            this.dddfaxTextEdit.ToolTip = "DDD do FAX";
            // 
            // dddtelefoneTextEdit
            // 
            this.dddtelefoneTextEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.EmpresaDTOBindingSource, "Dddtelefone", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.dddtelefoneTextEdit.EnterMoveNextControl = true;
            this.dddtelefoneTextEdit.Location = new System.Drawing.Point(82, 146);
            this.dddtelefoneTextEdit.Name = "dddtelefoneTextEdit";
            this.dddtelefoneTextEdit.Properties.Appearance.Options.UseTextOptions = true;
            this.dddtelefoneTextEdit.Properties.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.dddtelefoneTextEdit.Properties.MaxLength = 2;
            this.dddtelefoneTextEdit.Size = new System.Drawing.Size(35, 20);
            this.dddtelefoneTextEdit.TabIndex = 12;
            this.dddtelefoneTextEdit.ToolTip = "DDD do telefone principal";
            // 
            // UFTextEdit
            // 
            this.UFTextEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.EmpresaDTOBindingSource, "Municipio.UF.Codigo", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.UFTextEdit.EnterMoveNextControl = true;
            this.UFTextEdit.Location = new System.Drawing.Point(193, 67);
            this.UFTextEdit.Name = "UFTextEdit";
            this.UFTextEdit.Properties.ReadOnly = true;
            this.UFTextEdit.Size = new System.Drawing.Size(20, 20);
            this.UFTextEdit.TabIndex = 5;
            this.UFTextEdit.TabStop = false;
            // 
            // labelControl9
            // 
            this.labelControl9.Location = new System.Drawing.Point(219, 71);
            this.labelControl9.Name = "labelControl9";
            this.labelControl9.Size = new System.Drawing.Size(54, 13);
            this.labelControl9.TabIndex = 79;
            this.labelControl9.Text = "Cód. Mun.:";
            this.labelControl9.ToolTip = "Código do Município";
            // 
            // labelControl8
            // 
            this.labelControl8.Location = new System.Drawing.Point(3, 71);
            this.labelControl8.Name = "labelControl8";
            this.labelControl8.Size = new System.Drawing.Size(23, 13);
            this.labelControl8.TabIndex = 75;
            this.labelControl8.Text = "Cep:";
            // 
            // bairroTextEdit
            // 
            this.bairroTextEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.EmpresaDTOBindingSource, "Bairro", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.bairroTextEdit.EnterMoveNextControl = true;
            this.bairroTextEdit.Location = new System.Drawing.Point(82, 117);
            this.bairroTextEdit.Name = "bairroTextEdit";
            this.bairroTextEdit.Properties.MaxLength = 20;
            this.bairroTextEdit.Size = new System.Drawing.Size(327, 20);
            this.bairroTextEdit.TabIndex = 10;
            this.bairroTextEdit.ToolTip = "Bairro";
            // 
            // labelControl6
            // 
            this.labelControl6.Location = new System.Drawing.Point(415, 120);
            this.labelControl6.Name = "labelControl6";
            this.labelControl6.Size = new System.Drawing.Size(69, 13);
            this.labelControl6.TabIndex = 69;
            this.labelControl6.Text = "Complemento:";
            // 
            // labelControl5
            // 
            this.labelControl5.Location = new System.Drawing.Point(415, 94);
            this.labelControl5.Name = "labelControl5";
            this.labelControl5.Size = new System.Drawing.Size(16, 13);
            this.labelControl5.TabIndex = 68;
            this.labelControl5.Text = "Nº:";
            this.labelControl5.ToolTip = "Número";
            // 
            // labelControl4
            // 
            this.labelControl4.Location = new System.Drawing.Point(3, 94);
            this.labelControl4.Name = "labelControl4";
            this.labelControl4.Size = new System.Drawing.Size(49, 13);
            this.labelControl4.TabIndex = 65;
            this.labelControl4.Text = "Endereço:";
            // 
            // complementoTextEdit
            // 
            this.complementoTextEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.EmpresaDTOBindingSource, "Complemento", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.complementoTextEdit.EnterMoveNextControl = true;
            this.complementoTextEdit.Location = new System.Drawing.Point(485, 117);
            this.complementoTextEdit.Name = "complementoTextEdit";
            this.complementoTextEdit.Properties.MaxLength = 20;
            this.complementoTextEdit.Size = new System.Drawing.Size(177, 20);
            this.complementoTextEdit.TabIndex = 11;
            this.complementoTextEdit.ToolTip = "Complemento";
            // 
            // numeroTextEdit
            // 
            this.numeroTextEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.EmpresaDTOBindingSource, "Numero", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.numeroTextEdit.EnterMoveNextControl = true;
            this.numeroTextEdit.Location = new System.Drawing.Point(485, 91);
            this.numeroTextEdit.Name = "numeroTextEdit";
            this.numeroTextEdit.Properties.MaxLength = 6;
            this.numeroTextEdit.Size = new System.Drawing.Size(177, 20);
            this.numeroTextEdit.TabIndex = 9;
            this.numeroTextEdit.ToolTip = "Número";
            // 
            // enderecoTextEdit
            // 
            this.enderecoTextEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.EmpresaDTOBindingSource, "Endereco", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.enderecoTextEdit.EnterMoveNextControl = true;
            this.enderecoTextEdit.Location = new System.Drawing.Point(82, 91);
            this.enderecoTextEdit.Name = "enderecoTextEdit";
            this.enderecoTextEdit.Properties.MaxLength = 50;
            this.enderecoTextEdit.Size = new System.Drawing.Size(327, 20);
            this.enderecoTextEdit.TabIndex = 8;
            this.enderecoTextEdit.ToolTip = "Nome do logradouro";
            // 
            // EspecialidadeTextEdit
            // 
            this.EspecialidadeTextEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.EmpresaDTOBindingSource, "Especialidade", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.EspecialidadeTextEdit.EnterMoveNextControl = true;
            this.EspecialidadeTextEdit.Location = new System.Drawing.Point(82, 250);
            this.EspecialidadeTextEdit.MenuManager = this.barManager;
            this.EspecialidadeTextEdit.Name = "EspecialidadeTextEdit";
            this.EspecialidadeTextEdit.Properties.MaxLength = 20;
            this.EspecialidadeTextEdit.Size = new System.Drawing.Size(327, 20);
            this.EspecialidadeTextEdit.TabIndex = 90;
            // 
            // labelControl3
            // 
            this.labelControl3.Location = new System.Drawing.Point(155, 41);
            this.labelControl3.Name = "labelControl3";
            this.labelControl3.Size = new System.Drawing.Size(75, 13);
            this.labelControl3.TabIndex = 8;
            this.labelControl3.Text = "Nome Fantasia:";
            // 
            // idTextEdit
            // 
            this.idTextEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.EmpresaDTOBindingSource, "Id", true));
            this.idTextEdit.EnterMoveNextControl = true;
            this.idTextEdit.Location = new System.Drawing.Point(49, 16);
            this.idTextEdit.Name = "idTextEdit";
            this.idTextEdit.Properties.Appearance.Options.UseTextOptions = true;
            this.idTextEdit.Properties.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.idTextEdit.Properties.ReadOnly = true;
            this.idTextEdit.Size = new System.Drawing.Size(100, 20);
            this.idTextEdit.TabIndex = 1;
            this.idTextEdit.TabStop = false;
            // 
            // nomefantasiaTextEdit
            // 
            this.nomefantasiaTextEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.EmpresaDTOBindingSource, "Nomefantasia", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.nomefantasiaTextEdit.EnterMoveNextControl = true;
            this.nomefantasiaTextEdit.Location = new System.Drawing.Point(234, 38);
            this.nomefantasiaTextEdit.Name = "nomefantasiaTextEdit";
            this.nomefantasiaTextEdit.Properties.MaxLength = 52;
            this.nomefantasiaTextEdit.Size = new System.Drawing.Size(428, 20);
            this.nomefantasiaTextEdit.TabIndex = 3;
            this.nomefantasiaTextEdit.ToolTip = "Nome Fantasia (Apelido)";
            // 
            // razaosocialTextEdit
            // 
            this.razaosocialTextEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.EmpresaDTOBindingSource, "Razaosocial", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.razaosocialTextEdit.EnterMoveNextControl = true;
            this.razaosocialTextEdit.Location = new System.Drawing.Point(234, 15);
            this.razaosocialTextEdit.Name = "razaosocialTextEdit";
            this.razaosocialTextEdit.Properties.MaxLength = 52;
            this.razaosocialTextEdit.Size = new System.Drawing.Size(428, 20);
            this.razaosocialTextEdit.TabIndex = 2;
            this.razaosocialTextEdit.ToolTip = "Razão Social conforme registro em orgão competente";
            // 
            // labelControl1
            // 
            this.labelControl1.Location = new System.Drawing.Point(3, 19);
            this.labelControl1.Name = "labelControl1";
            this.labelControl1.Size = new System.Drawing.Size(37, 13);
            this.labelControl1.TabIndex = 9;
            this.labelControl1.Text = "Código:";
            // 
            // labelControl2
            // 
            this.labelControl2.Location = new System.Drawing.Point(155, 19);
            this.labelControl2.Name = "labelControl2";
            this.labelControl2.Size = new System.Drawing.Size(64, 13);
            this.labelControl2.TabIndex = 7;
            this.labelControl2.Text = "Razão Social:";
            // 
            // xtraTabPage2
            // 
            this.xtraTabPage2.Controls.Add(this.LogotipoGroupControl);
            this.xtraTabPage2.Name = "xtraTabPage2";
            this.xtraTabPage2.Size = new System.Drawing.Size(991, 518);
            this.xtraTabPage2.Text = "Configurações";
            // 
            // LogotipoGroupControl
            // 
            this.LogotipoGroupControl.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.LogotipoGroupControl.Controls.Add(this.labelControl42);
            this.LogotipoGroupControl.Controls.Add(this.LogotipoPictureEdit);
            this.LogotipoGroupControl.Location = new System.Drawing.Point(3, 3);
            this.LogotipoGroupControl.Name = "LogotipoGroupControl";
            this.LogotipoGroupControl.Size = new System.Drawing.Size(983, 221);
            this.LogotipoGroupControl.TabIndex = 4;
            this.LogotipoGroupControl.Text = "Logotipo";
            // 
            // labelControl42
            // 
            this.labelControl42.Appearance.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.labelControl42.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl42.Location = new System.Drawing.Point(345, 25);
            this.labelControl42.Name = "labelControl42";
            this.labelControl42.Size = new System.Drawing.Size(319, 47);
            this.labelControl42.TabIndex = 1;
            this.labelControl42.Text = "Utilize um logotipo para representar graficamente a empresa. O uso dessa opção po" +
    "derá ser visualizada no canto superior esquerdo em relatórios e impressos.";
            // 
            // LogotipoPictureEdit
            // 
            this.LogotipoPictureEdit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.LogotipoPictureEdit.Location = new System.Drawing.Point(5, 25);
            this.LogotipoPictureEdit.MenuManager = this.barManager;
            this.LogotipoPictureEdit.Name = "LogotipoPictureEdit";
            this.LogotipoPictureEdit.Properties.NullText = "Sem logotipo";
            this.LogotipoPictureEdit.Properties.SizeMode = DevExpress.XtraEditors.Controls.PictureSizeMode.Stretch;
            this.LogotipoPictureEdit.Size = new System.Drawing.Size(334, 191);
            this.LogotipoPictureEdit.TabIndex = 0;
            this.LogotipoPictureEdit.ToolTip = "Clique aqui para selecionar uma imagem";
            this.LogotipoPictureEdit.ToolTipIconType = DevExpress.Utils.ToolTipIconType.Information;
            this.LogotipoPictureEdit.ToolTipTitle = "Logotipo";
            this.LogotipoPictureEdit.Click += new System.EventHandler(this.LogotipoPictureEdit_Click);
            // 
            // frmUpdateEmpresa
            // 
            this.Appearance.Options.UseFont = true;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1020, 574);
            this.Controls.Add(this.groupControlEmpresas);
            this.Controls.Add(this.barDockControlLeft);
            this.Controls.Add(this.barDockControlRight);
            this.Controls.Add(this.barDockControlBottom);
            this.Controls.Add(this.barDockControlTop);
            this.Name = "frmUpdateEmpresa";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.frmUpdateEmpresa_FormClosed);
            this.Load += new System.EventHandler(this.frmUpdateEmpresa_Load);
            ((System.ComponentModel.ISupportInitialize)(this.barManager)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.EmpresaDTOBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NaturezaJuridicaDTOBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ClassifTributariaeSocialBindigSoutce)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.MunicipioDTOBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PorteDTOBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dxErrorProvider)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.groupControlEmpresas)).EndInit();
            this.groupControlEmpresas.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.xtraTabControl)).EndInit();
            this.xtraTabControl.ResumeLayout(false);
            this.xtraTabPage1.ResumeLayout(false);
            this.xtraTabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.cepTextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.naturezajuridicaLookUpEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cnpjTextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.municipioTextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.faxTextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.imunicipalTextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rdgTipo.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cnaeContainerControl)).EndInit();
            this.cnaeContainerControl.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.cnaeContainerEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.telefoneTextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.groupControlContatos)).EndInit();
            this.groupControlContatos.ResumeLayout(false);
            this.groupControlContatos.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.urlTextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emailTextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.inicioatividadeDateEdit.Properties.CalendarTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.inicioatividadeDateEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataregistroDateEdit.Properties.CalendarTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataregistroDateEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.orgaoregistroTextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.registroTextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.encerratividadeDateEdit.Properties.CalendarTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.encerratividadeDateEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.codigoibgeButtonEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.iestadualTextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dddfaxTextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dddtelefoneTextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.UFTextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bairroTextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.complementoTextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numeroTextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.enderecoTextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.EspecialidadeTextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.idTextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nomefantasiaTextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.razaosocialTextEdit.Properties)).EndInit();
            this.xtraTabPage2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.LogotipoGroupControl)).EndInit();
            this.LogotipoGroupControl.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.LogotipoPictureEdit.Properties)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private DevExpress.XtraBars.BarManager barManager;
        private DevExpress.XtraBars.Bar bar2;
        private DevExpress.XtraBars.BarButtonItem btnSalvar;
        private DevExpress.XtraBars.BarButtonItem btnCancelar;
        private DevExpress.XtraBars.BarButtonItem btnPrimeiro;
        private DevExpress.XtraBars.BarButtonItem btnAnterior;
        private DevExpress.XtraBars.BarButtonItem btnProximo;
        private DevExpress.XtraBars.BarButtonItem btnUltimo;
        private DevExpress.XtraBars.BarDockControl barDockControlTop;
        private DevExpress.XtraBars.BarDockControl barDockControlBottom;
        private DevExpress.XtraBars.BarDockControl barDockControlLeft;
        private DevExpress.XtraBars.BarDockControl barDockControlRight;
        private System.Windows.Forms.BindingSource EmpresaDTOBindingSource;
        private System.Windows.Forms.BindingSource NaturezaJuridicaDTOBindingSource;
        private System.Windows.Forms.BindingSource ClassifTributariaeSocialBindigSoutce;
        private System.Windows.Forms.BindingSource MunicipioDTOBindingSource;
        private System.Windows.Forms.BindingSource PorteDTOBindingSource;
        private DevExpress.XtraEditors.DXErrorProvider.DXErrorProvider dxErrorProvider;
        private DevExpress.XtraEditors.GroupControl groupControlEmpresas;
        private DevExpress.XtraTab.XtraTabControl xtraTabControl;
        private DevExpress.XtraTab.XtraTabPage xtraTabPage1;
        private DevExpress.XtraEditors.ButtonEdit cepTextEdit;
        private DevExpress.XtraEditors.LabelControl labelControl13;
        private DevExpress.XtraEditors.LabelControl labelControl17;
        private DevExpress.XtraEditors.LookUpEdit naturezajuridicaLookUpEdit;
        private DevExpress.XtraEditors.TextEdit cnpjTextEdit;
        private DevExpress.XtraEditors.LabelControl labelControl10;
        private DevExpress.XtraEditors.TextEdit municipioTextEdit;
        private DevExpress.XtraEditors.TextEdit faxTextEdit;
        private DevExpress.XtraEditors.TextEdit imunicipalTextEdit;
        private DevExpress.XtraEditors.RadioGroup rdgTipo;
        private DevExpress.XtraEditors.LabelControl labelControl41;
        private DevExpress.XtraEditors.PopupContainerControl cnaeContainerControl;
        private DevExpress.Utils.Design.DXTreeView treeView;
        private DevExpress.XtraEditors.PopupContainerEdit cnaeContainerEdit;
        private DevExpress.XtraEditors.TextEdit telefoneTextEdit;
        private DevExpress.XtraEditors.GroupControl groupControlContatos;
        private DevExpress.XtraEditors.TextEdit urlTextEdit;
        private DevExpress.XtraEditors.TextEdit emailTextEdit;
        private DevExpress.XtraEditors.LabelControl labelControl25;
        private DevExpress.XtraEditors.LabelControl labelControl24;
        private DevExpress.XtraEditors.LabelControl labelControl23;
        private DevExpress.XtraEditors.DateEdit inicioatividadeDateEdit;
        private DevExpress.XtraEditors.LabelControl labelControl21;
        private DevExpress.XtraEditors.DateEdit dataregistroDateEdit;
        private DevExpress.XtraEditors.LabelControl labelControl20;
        private DevExpress.XtraEditors.TextEdit orgaoregistroTextEdit;
        private DevExpress.XtraEditors.LabelControl labelControl19;
        private DevExpress.XtraEditors.TextEdit registroTextEdit;
        private DevExpress.XtraEditors.LabelControl labelControl18;
        private DevExpress.XtraEditors.DateEdit encerratividadeDateEdit;
        private DevExpress.XtraEditors.LabelControl labelControl16;
        private DevExpress.XtraEditors.ButtonEdit codigoibgeButtonEdit;
        private DevExpress.XtraEditors.LabelControl labelControl15;
        private DevExpress.XtraEditors.LabelControl labelControl14;
        private DevExpress.XtraEditors.TextEdit iestadualTextEdit;
        private DevExpress.XtraEditors.LabelControl labelControl12;
        private DevExpress.XtraEditors.LabelControl labelControl11;
        private DevExpress.XtraEditors.TextEdit dddfaxTextEdit;
        private DevExpress.XtraEditors.TextEdit dddtelefoneTextEdit;
        private DevExpress.XtraEditors.TextEdit UFTextEdit;
        private DevExpress.XtraEditors.LabelControl labelControl9;
        private DevExpress.XtraEditors.LabelControl labelControl8;
        private DevExpress.XtraEditors.TextEdit bairroTextEdit;
        private DevExpress.XtraEditors.LabelControl labelControl6;
        private DevExpress.XtraEditors.LabelControl labelControl5;
        private DevExpress.XtraEditors.LabelControl labelControl4;
        private DevExpress.XtraEditors.TextEdit complementoTextEdit;
        private DevExpress.XtraEditors.TextEdit numeroTextEdit;
        private DevExpress.XtraEditors.TextEdit enderecoTextEdit;
        private DevExpress.XtraEditors.TextEdit EspecialidadeTextEdit;
        private DevExpress.XtraEditors.LabelControl labelControl3;
        private DevExpress.XtraEditors.TextEdit idTextEdit;
        private DevExpress.XtraEditors.TextEdit nomefantasiaTextEdit;
        private DevExpress.XtraEditors.TextEdit razaosocialTextEdit;
        private DevExpress.XtraEditors.LabelControl labelControl1;
        private DevExpress.XtraEditors.LabelControl labelControl2;
        private DevExpress.XtraEditors.LabelControl labelControl7;
        private DevExpress.XtraEditors.LabelControl labelControl22;
        private DevExpress.XtraTab.XtraTabPage xtraTabPage2;
        private DevExpress.XtraEditors.GroupControl LogotipoGroupControl;
        private DevExpress.XtraEditors.LabelControl labelControl42;
        private DevExpress.XtraEditors.PictureEdit LogotipoPictureEdit;
    }
}