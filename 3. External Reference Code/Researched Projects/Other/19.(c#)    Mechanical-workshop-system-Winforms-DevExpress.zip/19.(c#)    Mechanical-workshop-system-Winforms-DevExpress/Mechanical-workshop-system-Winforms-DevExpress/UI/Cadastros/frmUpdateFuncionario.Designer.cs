﻿namespace MechTech.UI.Cadastros
{
    partial class frmUpdateFuncionario
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label sexoLabel;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmUpdateFuncionario));
            DevExpress.Utils.SerializableAppearanceObject serializableAppearanceObject1 = new DevExpress.Utils.SerializableAppearanceObject();
            DevExpress.Utils.SerializableAppearanceObject serializableAppearanceObject2 = new DevExpress.Utils.SerializableAppearanceObject();
            this.dxErrorProvider = new DevExpress.XtraEditors.DXErrorProvider.DXErrorProvider(this.components);
            this.toolTipController = new DevExpress.Utils.ToolTipController(this.components);
            this.groupControlFuncionarios = new DevExpress.XtraEditors.GroupControl();
            this.xtraTabControl = new DevExpress.XtraTab.XtraTabControl();
            this.xtraTabPageFuncionario = new DevExpress.XtraTab.XtraTabPage();
            this.lblSituacao = new DevExpress.XtraEditors.LabelControl();
            this.labelControl29 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl28 = new DevExpress.XtraEditors.LabelControl();
            this.datademissaoDateEdit = new DevExpress.XtraEditors.DateEdit();
            this.FuncionarioDTOBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dataadmissaoDateEdit = new DevExpress.XtraEditors.DateEdit();
            this.fotopictureEdit = new DevExpress.XtraEditors.PictureEdit();
            this.labelControl13 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl12 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl19 = new DevExpress.XtraEditors.LabelControl();
            this.datanascimentoDateEdit = new DevExpress.XtraEditors.DateEdit();
            this.labelControl16 = new DevExpress.XtraEditors.LabelControl();
            this.emailTextEdit = new DevExpress.XtraEditors.TextEdit();
            this.sexocomboBoxEdit = new DevExpress.XtraEditors.ComboBoxEdit();
            this.celularTextEdit = new DevExpress.XtraEditors.TextEdit();
            this.dddcelularTextEdit = new DevExpress.XtraEditors.TextEdit();
            this.labelControl15 = new DevExpress.XtraEditors.LabelControl();
            this.telefoneTextEdit = new DevExpress.XtraEditors.TextEdit();
            this.dddtelefoneTextEdit = new DevExpress.XtraEditors.TextEdit();
            this.labelControl14 = new DevExpress.XtraEditors.LabelControl();
            this.UFTextEdit = new DevExpress.XtraEditors.TextEdit();
            this.municipioTextEdit = new DevExpress.XtraEditors.TextEdit();
            this.labelControl11 = new DevExpress.XtraEditors.LabelControl();
            this.codigoibgeButtonEdit = new DevExpress.XtraEditors.ButtonEdit();
            this.labelControl10 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl9 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl8 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl7 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl6 = new DevExpress.XtraEditors.LabelControl();
            this.bairroTextEdit = new DevExpress.XtraEditors.TextEdit();
            this.complementoTextEdit = new DevExpress.XtraEditors.TextEdit();
            this.numeroTextEdit = new DevExpress.XtraEditors.TextEdit();
            this.enderecoTextEdit = new DevExpress.XtraEditors.TextEdit();
            this.cepTextEdit = new DevExpress.XtraEditors.ButtonEdit();
            this.labelControl4 = new DevExpress.XtraEditors.LabelControl();
            this.nomecompletoTextEdit = new DevExpress.XtraEditors.TextEdit();
            this.idTextEdit = new DevExpress.XtraEditors.TextEdit();
            this.lblCodigo = new DevExpress.XtraEditors.LabelControl();
            this.xtraTabPageDocumentos = new DevExpress.XtraTab.XtraTabPage();
            this.labelControl74 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl73 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl72 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl71 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl70 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl69 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl68 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl67 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl66 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl65 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl64 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl63 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl62 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl61 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl59 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl58 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl57 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl56 = new DevExpress.XtraEditors.LabelControl();
            this.UFReservistaLookUpEdit = new DevExpress.XtraEditors.LookUpEdit();
            this.UFDTOBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.rescategoriaTextEdit = new DevExpress.XtraEditors.TextEdit();
            this.reservistaTextEdit = new DevExpress.XtraEditors.TextEdit();
            this.cnhvencimentoDateEdit = new DevExpress.XtraEditors.DateEdit();
            this.cnhcategoriaTextEdit = new DevExpress.XtraEditors.TextEdit();
            this.cnhTextEdit = new DevExpress.XtraEditors.TextEdit();
            this.cpfTextEdit = new DevExpress.XtraEditors.TextEdit();
            this.titulosecaoTextEdit = new DevExpress.XtraEditors.TextEdit();
            this.titulozonaTextEdit = new DevExpress.XtraEditors.TextEdit();
            this.tituloTextEdit = new DevExpress.XtraEditors.TextEdit();
            this.UFRGLookUpEdit = new DevExpress.XtraEditors.LookUpEdit();
            this.rgorgaoTextEdit = new DevExpress.XtraEditors.TextEdit();
            this.rgemissaoDateEdit = new DevExpress.XtraEditors.DateEdit();
            this.rgTextEdit = new DevExpress.XtraEditors.TextEdit();
            this.ctpsemissaoDateEdit = new DevExpress.XtraEditors.DateEdit();
            this.UFCTPSLookUpEdit = new DevExpress.XtraEditors.LookUpEdit();
            this.ctpsserieTextEdit = new DevExpress.XtraEditors.TextEdit();
            this.ctpsTextEdit = new DevExpress.XtraEditors.TextEdit();
            this.xtraTabPageSalario = new DevExpress.XtraTab.XtraTabPage();
            this.gpcBancoDeposito = new DevExpress.XtraEditors.GroupControl();
            this.labelControl55 = new DevExpress.XtraEditors.LabelControl();
            this.bancosalarioLookUpEdit = new DevExpress.XtraEditors.LookUpEdit();
            this.BancoDTOBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tipocontacomboBoxEdit = new DevExpress.XtraEditors.ComboBoxEdit();
            this.labelControl36 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl41 = new DevExpress.XtraEditors.LabelControl();
            this.salcontaTextEdit = new DevExpress.XtraEditors.TextEdit();
            this.labelControl40 = new DevExpress.XtraEditors.LabelControl();
            this.salcontadv1TextEdit = new DevExpress.XtraEditors.TextEdit();
            this.salagenciadvTextEdit = new DevExpress.XtraEditors.TextEdit();
            this.salcontadv2TextEdit = new DevExpress.XtraEditors.TextEdit();
            this.salagenciaTextEdit = new DevExpress.XtraEditors.TextEdit();
            this.labelControl37 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl39 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl38 = new DevExpress.XtraEditors.LabelControl();
            this.salarioGridControl = new DevExpress.XtraGrid.GridControl();
            this.SalarioBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.gridViewSalario = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.colData = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colDissidio = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colDepartamento = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colSetor = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colSecao = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colFuncao = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colHoras = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colSalario = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemTextEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemTextEdit();
            this.btnAlterarSalario = new DevExpress.XtraEditors.SimpleButton();
            this.btnExcluirSalario = new DevExpress.XtraEditors.SimpleButton();
            this.btnVisualizarSalario = new DevExpress.XtraEditors.SimpleButton();
            this.btnInserirSalario = new DevExpress.XtraEditors.SimpleButton();
            this.MunicipioDTOBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.DepartamentoDTOBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.SetorDTOBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.SecaoDTOBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.SemanaBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.barManager = new DevExpress.XtraBars.BarManager(this.components);
            this.bar2 = new DevExpress.XtraBars.Bar();
            this.btnSalvar = new DevExpress.XtraBars.BarButtonItem();
            this.btnCancelar = new DevExpress.XtraBars.BarButtonItem();
            this.btnPrimeiro = new DevExpress.XtraBars.BarButtonItem();
            this.btnAnterior = new DevExpress.XtraBars.BarButtonItem();
            this.btnProximo = new DevExpress.XtraBars.BarButtonItem();
            this.btnUltimo = new DevExpress.XtraBars.BarButtonItem();
            this.barDockControlTop = new DevExpress.XtraBars.BarDockControl();
            this.barDockControlBottom = new DevExpress.XtraBars.BarDockControl();
            this.barDockControlLeft = new DevExpress.XtraBars.BarDockControl();
            this.barDockControlRight = new DevExpress.XtraBars.BarDockControl();
            sexoLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dxErrorProvider)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.groupControlFuncionarios)).BeginInit();
            this.groupControlFuncionarios.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.xtraTabControl)).BeginInit();
            this.xtraTabControl.SuspendLayout();
            this.xtraTabPageFuncionario.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.datademissaoDateEdit.Properties.CalendarTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.datademissaoDateEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.FuncionarioDTOBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataadmissaoDateEdit.Properties.CalendarTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataadmissaoDateEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fotopictureEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.datanascimentoDateEdit.Properties.CalendarTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.datanascimentoDateEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emailTextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sexocomboBoxEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.celularTextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dddcelularTextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.telefoneTextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dddtelefoneTextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.UFTextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.municipioTextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.codigoibgeButtonEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bairroTextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.complementoTextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numeroTextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.enderecoTextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cepTextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nomecompletoTextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.idTextEdit.Properties)).BeginInit();
            this.xtraTabPageDocumentos.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.UFReservistaLookUpEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.UFDTOBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rescategoriaTextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.reservistaTextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cnhvencimentoDateEdit.Properties.CalendarTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cnhvencimentoDateEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cnhcategoriaTextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cnhTextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cpfTextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.titulosecaoTextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.titulozonaTextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tituloTextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.UFRGLookUpEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rgorgaoTextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rgemissaoDateEdit.Properties.CalendarTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rgemissaoDateEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rgTextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ctpsemissaoDateEdit.Properties.CalendarTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ctpsemissaoDateEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.UFCTPSLookUpEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ctpsserieTextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ctpsTextEdit.Properties)).BeginInit();
            this.xtraTabPageSalario.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gpcBancoDeposito)).BeginInit();
            this.gpcBancoDeposito.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bancosalarioLookUpEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BancoDTOBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tipocontacomboBoxEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.salcontaTextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.salcontadv1TextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.salagenciadvTextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.salcontadv2TextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.salagenciaTextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.salarioGridControl)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SalarioBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewSalario)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.MunicipioDTOBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DepartamentoDTOBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SetorDTOBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SecaoDTOBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SemanaBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.barManager)).BeginInit();
            this.SuspendLayout();
            // 
            // sexoLabel
            // 
            sexoLabel.AutoSize = true;
            sexoLabel.Location = new System.Drawing.Point(511, 123);
            sexoLabel.Name = "sexoLabel";
            sexoLabel.Size = new System.Drawing.Size(35, 13);
            sexoLabel.TabIndex = 57;
            sexoLabel.Text = "Sexo:";
            // 
            // dxErrorProvider
            // 
            this.dxErrorProvider.ContainerControl = this;
            // 
            // toolTipController
            // 
            this.toolTipController.AllowHtmlText = true;
            this.toolTipController.IconSize = DevExpress.Utils.ToolTipIconSize.Large;
            this.toolTipController.InitialDelay = 1;
            this.toolTipController.Rounded = true;
            this.toolTipController.ShowBeak = true;
            this.toolTipController.ToolTipType = DevExpress.Utils.ToolTipType.SuperTip;
            // 
            // groupControlFuncionarios
            // 
            this.groupControlFuncionarios.AppearanceCaption.Options.UseTextOptions = true;
            this.groupControlFuncionarios.AppearanceCaption.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.groupControlFuncionarios.CaptionLocation = DevExpress.Utils.Locations.Left;
            this.groupControlFuncionarios.Controls.Add(this.xtraTabControl);
            this.groupControlFuncionarios.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupControlFuncionarios.Location = new System.Drawing.Point(0, 24);
            this.groupControlFuncionarios.Name = "groupControlFuncionarios";
            this.groupControlFuncionarios.Size = new System.Drawing.Size(1154, 572);
            this.groupControlFuncionarios.TabIndex = 4;
            this.groupControlFuncionarios.Text = "Funcionários";
            // 
            // xtraTabControl
            // 
            this.xtraTabControl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.xtraTabControl.Location = new System.Drawing.Point(21, 2);
            this.xtraTabControl.Name = "xtraTabControl";
            this.xtraTabControl.SelectedTabPage = this.xtraTabPageFuncionario;
            this.xtraTabControl.Size = new System.Drawing.Size(1131, 568);
            this.xtraTabControl.TabIndex = 0;
            this.xtraTabControl.TabPages.AddRange(new DevExpress.XtraTab.XtraTabPage[] {
            this.xtraTabPageFuncionario,
            this.xtraTabPageDocumentos,
            this.xtraTabPageSalario});
            // 
            // xtraTabPageFuncionario
            // 
            this.xtraTabPageFuncionario.Controls.Add(this.lblSituacao);
            this.xtraTabPageFuncionario.Controls.Add(this.labelControl29);
            this.xtraTabPageFuncionario.Controls.Add(this.labelControl28);
            this.xtraTabPageFuncionario.Controls.Add(this.datademissaoDateEdit);
            this.xtraTabPageFuncionario.Controls.Add(this.dataadmissaoDateEdit);
            this.xtraTabPageFuncionario.Controls.Add(this.fotopictureEdit);
            this.xtraTabPageFuncionario.Controls.Add(this.labelControl13);
            this.xtraTabPageFuncionario.Controls.Add(this.labelControl12);
            this.xtraTabPageFuncionario.Controls.Add(sexoLabel);
            this.xtraTabPageFuncionario.Controls.Add(this.labelControl19);
            this.xtraTabPageFuncionario.Controls.Add(this.datanascimentoDateEdit);
            this.xtraTabPageFuncionario.Controls.Add(this.labelControl16);
            this.xtraTabPageFuncionario.Controls.Add(this.emailTextEdit);
            this.xtraTabPageFuncionario.Controls.Add(this.sexocomboBoxEdit);
            this.xtraTabPageFuncionario.Controls.Add(this.celularTextEdit);
            this.xtraTabPageFuncionario.Controls.Add(this.dddcelularTextEdit);
            this.xtraTabPageFuncionario.Controls.Add(this.labelControl15);
            this.xtraTabPageFuncionario.Controls.Add(this.telefoneTextEdit);
            this.xtraTabPageFuncionario.Controls.Add(this.dddtelefoneTextEdit);
            this.xtraTabPageFuncionario.Controls.Add(this.labelControl14);
            this.xtraTabPageFuncionario.Controls.Add(this.UFTextEdit);
            this.xtraTabPageFuncionario.Controls.Add(this.municipioTextEdit);
            this.xtraTabPageFuncionario.Controls.Add(this.labelControl11);
            this.xtraTabPageFuncionario.Controls.Add(this.codigoibgeButtonEdit);
            this.xtraTabPageFuncionario.Controls.Add(this.labelControl10);
            this.xtraTabPageFuncionario.Controls.Add(this.labelControl9);
            this.xtraTabPageFuncionario.Controls.Add(this.labelControl8);
            this.xtraTabPageFuncionario.Controls.Add(this.labelControl7);
            this.xtraTabPageFuncionario.Controls.Add(this.labelControl6);
            this.xtraTabPageFuncionario.Controls.Add(this.bairroTextEdit);
            this.xtraTabPageFuncionario.Controls.Add(this.complementoTextEdit);
            this.xtraTabPageFuncionario.Controls.Add(this.numeroTextEdit);
            this.xtraTabPageFuncionario.Controls.Add(this.enderecoTextEdit);
            this.xtraTabPageFuncionario.Controls.Add(this.cepTextEdit);
            this.xtraTabPageFuncionario.Controls.Add(this.labelControl4);
            this.xtraTabPageFuncionario.Controls.Add(this.nomecompletoTextEdit);
            this.xtraTabPageFuncionario.Controls.Add(this.idTextEdit);
            this.xtraTabPageFuncionario.Controls.Add(this.lblCodigo);
            this.xtraTabPageFuncionario.Name = "xtraTabPageFuncionario";
            this.xtraTabPageFuncionario.Size = new System.Drawing.Size(1125, 540);
            this.xtraTabPageFuncionario.Text = "Básico";
            // 
            // lblSituacao
            // 
            this.lblSituacao.Appearance.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSituacao.Appearance.ForeColor = System.Drawing.Color.Red;
            this.lblSituacao.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.lblSituacao.Location = new System.Drawing.Point(114, 32);
            this.lblSituacao.Name = "lblSituacao";
            this.lblSituacao.Size = new System.Drawing.Size(523, 18);
            this.lblSituacao.TabIndex = 65;
            this.lblSituacao.Text = "* Funcionário Demitido *";
            this.lblSituacao.Visible = false;
            // 
            // labelControl29
            // 
            this.labelControl29.Location = new System.Drawing.Point(217, 167);
            this.labelControl29.Name = "labelControl29";
            this.labelControl29.Size = new System.Drawing.Size(74, 13);
            this.labelControl29.TabIndex = 64;
            this.labelControl29.Text = "Data demissão:";
            this.labelControl29.ToolTip = "Data de demissão";
            // 
            // labelControl28
            // 
            this.labelControl28.Location = new System.Drawing.Point(20, 167);
            this.labelControl28.Name = "labelControl28";
            this.labelControl28.Size = new System.Drawing.Size(74, 13);
            this.labelControl28.TabIndex = 63;
            this.labelControl28.Text = "Data admissão:";
            this.labelControl28.ToolTip = "Data de admissão";
            // 
            // datademissaoDateEdit
            // 
            this.datademissaoDateEdit.CausesValidation = false;
            this.datademissaoDateEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.FuncionarioDTOBindingSource, "Contrato.Datademissao", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.datademissaoDateEdit.EditValue = null;
            this.datademissaoDateEdit.EnterMoveNextControl = true;
            this.datademissaoDateEdit.Location = new System.Drawing.Point(297, 164);
            this.datademissaoDateEdit.Name = "datademissaoDateEdit";
            this.datademissaoDateEdit.Properties.Appearance.Options.UseTextOptions = true;
            this.datademissaoDateEdit.Properties.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.datademissaoDateEdit.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.datademissaoDateEdit.Properties.CalendarTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            this.datademissaoDateEdit.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.DateTimeAdvancingCaret;
            this.datademissaoDateEdit.Size = new System.Drawing.Size(100, 20);
            this.datademissaoDateEdit.TabIndex = 19;
            this.datademissaoDateEdit.ToolTip = "Data de demissão";
            // 
            // FuncionarioDTOBindingSource
            // 
            this.FuncionarioDTOBindingSource.DataSource = typeof(MechTech.Entities.FuncionarioDTO);
            // 
            // dataadmissaoDateEdit
            // 
            this.dataadmissaoDateEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.FuncionarioDTOBindingSource, "Contrato.Dataadmissao", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.dataadmissaoDateEdit.EditValue = null;
            this.dataadmissaoDateEdit.EnterMoveNextControl = true;
            this.dataadmissaoDateEdit.Location = new System.Drawing.Point(114, 164);
            this.dataadmissaoDateEdit.Name = "dataadmissaoDateEdit";
            this.dataadmissaoDateEdit.Properties.Appearance.Options.UseTextOptions = true;
            this.dataadmissaoDateEdit.Properties.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.dataadmissaoDateEdit.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.dataadmissaoDateEdit.Properties.CalendarTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            this.dataadmissaoDateEdit.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.DateTimeAdvancingCaret;
            this.dataadmissaoDateEdit.Size = new System.Drawing.Size(100, 20);
            this.dataadmissaoDateEdit.TabIndex = 18;
            this.dataadmissaoDateEdit.ToolTip = "Data de admissão";
            // 
            // fotopictureEdit
            // 
            this.fotopictureEdit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.fotopictureEdit.Location = new System.Drawing.Point(754, 57);
            this.fotopictureEdit.Name = "fotopictureEdit";
            this.fotopictureEdit.Properties.NullText = "Sem foto";
            this.fotopictureEdit.Properties.SizeMode = DevExpress.XtraEditors.Controls.PictureSizeMode.Stretch;
            this.fotopictureEdit.Size = new System.Drawing.Size(90, 96);
            this.fotopictureEdit.TabIndex = 60;
            this.fotopictureEdit.ToolTip = "Clique aqui para selecionar uma foto";
            this.fotopictureEdit.ToolTipIconType = DevExpress.Utils.ToolTipIconType.Information;
            this.fotopictureEdit.ToolTipTitle = "Foto";
            this.fotopictureEdit.Click += new System.EventHandler(this.fotopictureEdit_Click);
            // 
            // labelControl13
            // 
            this.labelControl13.Location = new System.Drawing.Point(311, 57);
            this.labelControl13.Name = "labelControl13";
            this.labelControl13.Size = new System.Drawing.Size(17, 13);
            this.labelControl13.TabIndex = 59;
            this.labelControl13.Text = "UF:";
            // 
            // labelControl12
            // 
            this.labelControl12.Location = new System.Drawing.Point(511, 57);
            this.labelControl12.Name = "labelControl12";
            this.labelControl12.Size = new System.Drawing.Size(47, 13);
            this.labelControl12.TabIndex = 58;
            this.labelControl12.Text = "Município:";
            // 
            // labelControl19
            // 
            this.labelControl19.Location = new System.Drawing.Point(511, 145);
            this.labelControl19.Name = "labelControl19";
            this.labelControl19.Size = new System.Drawing.Size(84, 13);
            this.labelControl19.TabIndex = 55;
            this.labelControl19.Text = "Data nascimento:";
            // 
            // datanascimentoDateEdit
            // 
            this.datanascimentoDateEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.FuncionarioDTOBindingSource, "Datanascimento", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.datanascimentoDateEdit.EditValue = null;
            this.datanascimentoDateEdit.EnterMoveNextControl = true;
            this.datanascimentoDateEdit.Location = new System.Drawing.Point(597, 142);
            this.datanascimentoDateEdit.Name = "datanascimentoDateEdit";
            this.datanascimentoDateEdit.Properties.Appearance.Options.UseTextOptions = true;
            this.datanascimentoDateEdit.Properties.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.datanascimentoDateEdit.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.datanascimentoDateEdit.Properties.CalendarTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            this.datanascimentoDateEdit.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.DateTimeAdvancingCaret;
            this.datanascimentoDateEdit.Size = new System.Drawing.Size(151, 20);
            this.datanascimentoDateEdit.TabIndex = 17;
            this.datanascimentoDateEdit.ToolTip = "Data de nascimento";
            // 
            // labelControl16
            // 
            this.labelControl16.Location = new System.Drawing.Point(20, 145);
            this.labelControl16.Name = "labelControl16";
            this.labelControl16.Size = new System.Drawing.Size(28, 13);
            this.labelControl16.TabIndex = 53;
            this.labelControl16.Text = "Email:";
            // 
            // emailTextEdit
            // 
            this.emailTextEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.FuncionarioDTOBindingSource, "Email", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.emailTextEdit.EnterMoveNextControl = true;
            this.emailTextEdit.Location = new System.Drawing.Point(114, 142);
            this.emailTextEdit.Name = "emailTextEdit";
            this.emailTextEdit.Properties.MaxLength = 40;
            this.emailTextEdit.Size = new System.Drawing.Size(391, 20);
            this.emailTextEdit.TabIndex = 16;
            this.emailTextEdit.ToolTip = "Endereço de email";
            // 
            // sexocomboBoxEdit
            // 
            this.sexocomboBoxEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.FuncionarioDTOBindingSource, "Sexo", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.sexocomboBoxEdit.EditValue = "";
            this.sexocomboBoxEdit.EnterMoveNextControl = true;
            this.sexocomboBoxEdit.Location = new System.Drawing.Point(597, 121);
            this.sexocomboBoxEdit.Name = "sexocomboBoxEdit";
            this.sexocomboBoxEdit.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.sexocomboBoxEdit.Properties.Items.AddRange(new object[] {
            "Masculino",
            "Feminino"});
            this.sexocomboBoxEdit.Properties.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.DisableTextEditor;
            this.sexocomboBoxEdit.Size = new System.Drawing.Size(151, 20);
            this.sexocomboBoxEdit.TabIndex = 15;
            this.sexocomboBoxEdit.ToolTip = "Sexo (M)asculino/(F)eminino";
            // 
            // celularTextEdit
            // 
            this.celularTextEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.FuncionarioDTOBindingSource, "Celular", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.celularTextEdit.EnterMoveNextControl = true;
            this.celularTextEdit.Location = new System.Drawing.Point(384, 121);
            this.celularTextEdit.Name = "celularTextEdit";
            this.celularTextEdit.Properties.MaxLength = 9;
            this.celularTextEdit.Size = new System.Drawing.Size(121, 20);
            this.celularTextEdit.TabIndex = 14;
            this.celularTextEdit.ToolTip = "Número do telefone celular";
            // 
            // dddcelularTextEdit
            // 
            this.dddcelularTextEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.FuncionarioDTOBindingSource, "Dddcelular", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.dddcelularTextEdit.EnterMoveNextControl = true;
            this.dddcelularTextEdit.Location = new System.Drawing.Point(334, 121);
            this.dddcelularTextEdit.Name = "dddcelularTextEdit";
            this.dddcelularTextEdit.Properties.Appearance.Options.UseTextOptions = true;
            this.dddcelularTextEdit.Properties.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.dddcelularTextEdit.Properties.MaxLength = 2;
            this.dddcelularTextEdit.Size = new System.Drawing.Size(44, 20);
            this.dddcelularTextEdit.TabIndex = 13;
            this.dddcelularTextEdit.ToolTip = "DDD do celular";
            // 
            // labelControl15
            // 
            this.labelControl15.Location = new System.Drawing.Point(278, 124);
            this.labelControl15.Name = "labelControl15";
            this.labelControl15.Size = new System.Drawing.Size(37, 13);
            this.labelControl15.TabIndex = 52;
            this.labelControl15.Text = "Celular:";
            // 
            // telefoneTextEdit
            // 
            this.telefoneTextEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.FuncionarioDTOBindingSource, "Telefone", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.telefoneTextEdit.EnterMoveNextControl = true;
            this.telefoneTextEdit.Location = new System.Drawing.Point(155, 121);
            this.telefoneTextEdit.Name = "telefoneTextEdit";
            this.telefoneTextEdit.Properties.MaxLength = 9;
            this.telefoneTextEdit.Size = new System.Drawing.Size(119, 20);
            this.telefoneTextEdit.TabIndex = 12;
            this.telefoneTextEdit.ToolTip = "Número do telefone residencial";
            // 
            // dddtelefoneTextEdit
            // 
            this.dddtelefoneTextEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.FuncionarioDTOBindingSource, "Dddtelefone", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.dddtelefoneTextEdit.EnterMoveNextControl = true;
            this.dddtelefoneTextEdit.Location = new System.Drawing.Point(114, 121);
            this.dddtelefoneTextEdit.Name = "dddtelefoneTextEdit";
            this.dddtelefoneTextEdit.Properties.Appearance.Options.UseTextOptions = true;
            this.dddtelefoneTextEdit.Properties.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.dddtelefoneTextEdit.Properties.MaxLength = 2;
            this.dddtelefoneTextEdit.Size = new System.Drawing.Size(35, 20);
            this.dddtelefoneTextEdit.TabIndex = 11;
            this.dddtelefoneTextEdit.ToolTip = "DDD do telefone residencial";
            // 
            // labelControl14
            // 
            this.labelControl14.Location = new System.Drawing.Point(20, 123);
            this.labelControl14.Name = "labelControl14";
            this.labelControl14.Size = new System.Drawing.Size(46, 13);
            this.labelControl14.TabIndex = 51;
            this.labelControl14.Text = "Telefone:";
            // 
            // UFTextEdit
            // 
            this.UFTextEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.FuncionarioDTOBindingSource, "Municipio.UF.Codigo", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.UFTextEdit.EnterMoveNextControl = true;
            this.UFTextEdit.Location = new System.Drawing.Point(334, 55);
            this.UFTextEdit.Name = "UFTextEdit";
            this.UFTextEdit.Size = new System.Drawing.Size(35, 20);
            this.UFTextEdit.TabIndex = 4;
            // 
            // municipioTextEdit
            // 
            this.municipioTextEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.FuncionarioDTOBindingSource, "Municipio.Nome", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.municipioTextEdit.EnterMoveNextControl = true;
            this.municipioTextEdit.Location = new System.Drawing.Point(597, 55);
            this.municipioTextEdit.Name = "municipioTextEdit";
            this.municipioTextEdit.Properties.ReadOnly = true;
            this.municipioTextEdit.Size = new System.Drawing.Size(151, 20);
            this.municipioTextEdit.TabIndex = 6;
            this.municipioTextEdit.TabStop = false;
            // 
            // labelControl11
            // 
            this.labelControl11.Location = new System.Drawing.Point(375, 57);
            this.labelControl11.Name = "labelControl11";
            this.labelControl11.Size = new System.Drawing.Size(54, 13);
            this.labelControl11.TabIndex = 50;
            this.labelControl11.Text = "Cód. Mun.:";
            this.labelControl11.ToolTip = "Código do Município";
            // 
            // codigoibgeButtonEdit
            // 
            this.codigoibgeButtonEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.FuncionarioDTOBindingSource, "Municipio.Codigoibge", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.codigoibgeButtonEdit.EnterMoveNextControl = true;
            this.codigoibgeButtonEdit.Location = new System.Drawing.Point(434, 53);
            this.codigoibgeButtonEdit.Name = "codigoibgeButtonEdit";
            this.codigoibgeButtonEdit.Properties.Appearance.Options.UseTextOptions = true;
            this.codigoibgeButtonEdit.Properties.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.codigoibgeButtonEdit.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Glyph, "", -1, true, true, false, DevExpress.XtraEditors.ImageLocation.MiddleCenter, ((System.Drawing.Image)(resources.GetObject("codigoibgeButtonEdit.Properties.Buttons"))), new DevExpress.Utils.KeyShortcut(System.Windows.Forms.Keys.None), serializableAppearanceObject1, "", null, null, false)});
            this.codigoibgeButtonEdit.Properties.Mask.EditMask = "d";
            this.codigoibgeButtonEdit.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.codigoibgeButtonEdit.Size = new System.Drawing.Size(71, 22);
            this.codigoibgeButtonEdit.TabIndex = 5;
            this.codigoibgeButtonEdit.ButtonClick += new DevExpress.XtraEditors.Controls.ButtonPressedEventHandler(this.codigoibgeButtonEdit_ButtonClick);
            this.codigoibgeButtonEdit.EditValueChanged += new System.EventHandler(this.codigoibgeButtonEdit_EditValueChanged);
            this.codigoibgeButtonEdit.Validated += new System.EventHandler(this.codigoibgeButtonEdit_Validated);
            // 
            // labelControl10
            // 
            this.labelControl10.Location = new System.Drawing.Point(20, 57);
            this.labelControl10.Name = "labelControl10";
            this.labelControl10.Size = new System.Drawing.Size(23, 13);
            this.labelControl10.TabIndex = 49;
            this.labelControl10.Text = "Cep:";
            // 
            // labelControl9
            // 
            this.labelControl9.Location = new System.Drawing.Point(20, 101);
            this.labelControl9.Name = "labelControl9";
            this.labelControl9.Size = new System.Drawing.Size(32, 13);
            this.labelControl9.TabIndex = 48;
            this.labelControl9.Text = "Bairro:";
            // 
            // labelControl8
            // 
            this.labelControl8.Location = new System.Drawing.Point(511, 101);
            this.labelControl8.Name = "labelControl8";
            this.labelControl8.Size = new System.Drawing.Size(69, 13);
            this.labelControl8.TabIndex = 45;
            this.labelControl8.Text = "Complemento:";
            // 
            // labelControl7
            // 
            this.labelControl7.Location = new System.Drawing.Point(511, 79);
            this.labelControl7.Name = "labelControl7";
            this.labelControl7.Size = new System.Drawing.Size(16, 13);
            this.labelControl7.TabIndex = 44;
            this.labelControl7.Text = "Nº:";
            this.labelControl7.ToolTip = "Número";
            // 
            // labelControl6
            // 
            this.labelControl6.Location = new System.Drawing.Point(20, 79);
            this.labelControl6.Name = "labelControl6";
            this.labelControl6.Size = new System.Drawing.Size(49, 13);
            this.labelControl6.TabIndex = 41;
            this.labelControl6.Text = "Endereço:";
            // 
            // bairroTextEdit
            // 
            this.bairroTextEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.FuncionarioDTOBindingSource, "Bairro", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.bairroTextEdit.EnterMoveNextControl = true;
            this.bairroTextEdit.Location = new System.Drawing.Point(114, 99);
            this.bairroTextEdit.Name = "bairroTextEdit";
            this.bairroTextEdit.Properties.MaxLength = 20;
            this.bairroTextEdit.Size = new System.Drawing.Size(391, 20);
            this.bairroTextEdit.TabIndex = 9;
            this.bairroTextEdit.ToolTip = "Bairro";
            // 
            // complementoTextEdit
            // 
            this.complementoTextEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.FuncionarioDTOBindingSource, "Complemento", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.complementoTextEdit.EnterMoveNextControl = true;
            this.complementoTextEdit.Location = new System.Drawing.Point(597, 99);
            this.complementoTextEdit.Name = "complementoTextEdit";
            this.complementoTextEdit.Properties.MaxLength = 20;
            this.complementoTextEdit.Size = new System.Drawing.Size(151, 20);
            this.complementoTextEdit.TabIndex = 10;
            this.complementoTextEdit.ToolTip = "Complemento";
            // 
            // numeroTextEdit
            // 
            this.numeroTextEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.FuncionarioDTOBindingSource, "Numero", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.numeroTextEdit.EnterMoveNextControl = true;
            this.numeroTextEdit.Location = new System.Drawing.Point(597, 77);
            this.numeroTextEdit.Name = "numeroTextEdit";
            this.numeroTextEdit.Properties.MaxLength = 6;
            this.numeroTextEdit.Size = new System.Drawing.Size(151, 20);
            this.numeroTextEdit.TabIndex = 8;
            this.numeroTextEdit.ToolTip = "Número";
            // 
            // enderecoTextEdit
            // 
            this.enderecoTextEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.FuncionarioDTOBindingSource, "Endereco", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.enderecoTextEdit.EnterMoveNextControl = true;
            this.enderecoTextEdit.Location = new System.Drawing.Point(114, 77);
            this.enderecoTextEdit.Name = "enderecoTextEdit";
            this.enderecoTextEdit.Properties.MaxLength = 40;
            this.enderecoTextEdit.Size = new System.Drawing.Size(391, 20);
            this.enderecoTextEdit.TabIndex = 7;
            this.enderecoTextEdit.ToolTip = "Nome do logradouro";
            // 
            // cepTextEdit
            // 
            this.cepTextEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.FuncionarioDTOBindingSource, "Cep", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.cepTextEdit.EnterMoveNextControl = true;
            this.cepTextEdit.Location = new System.Drawing.Point(114, 53);
            this.cepTextEdit.Name = "cepTextEdit";
            this.cepTextEdit.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Glyph, "", -1, true, true, false, DevExpress.XtraEditors.ImageLocation.MiddleCenter, ((System.Drawing.Image)(resources.GetObject("cepTextEdit.Properties.Buttons"))), new DevExpress.Utils.KeyShortcut(System.Windows.Forms.Keys.None), serializableAppearanceObject2, "", null, null, false)});
            this.cepTextEdit.Properties.Mask.EditMask = "99.999-999";
            this.cepTextEdit.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Simple;
            this.cepTextEdit.Properties.Mask.SaveLiteral = false;
            this.cepTextEdit.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.cepTextEdit.Properties.MaxLength = 8;
            this.cepTextEdit.Size = new System.Drawing.Size(191, 22);
            this.cepTextEdit.TabIndex = 3;
            this.cepTextEdit.ToolTip = "Código de endereçamento postal fornecido pelos CORREIOS";
            this.cepTextEdit.ButtonClick += new DevExpress.XtraEditors.Controls.ButtonPressedEventHandler(this.cepTextEdit_ButtonClick);
            this.cepTextEdit.Validated += new System.EventHandler(this.cepTextEdit_Validated);
            // 
            // labelControl4
            // 
            this.labelControl4.Location = new System.Drawing.Point(165, 13);
            this.labelControl4.Name = "labelControl4";
            this.labelControl4.Size = new System.Drawing.Size(77, 13);
            this.labelControl4.TabIndex = 15;
            this.labelControl4.Text = "Nome completo:";
            // 
            // nomecompletoTextEdit
            // 
            this.nomecompletoTextEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.FuncionarioDTOBindingSource, "Nomecompleto", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.nomecompletoTextEdit.EnterMoveNextControl = true;
            this.nomecompletoTextEdit.Location = new System.Drawing.Point(248, 10);
            this.nomecompletoTextEdit.Name = "nomecompletoTextEdit";
            this.nomecompletoTextEdit.Properties.Mask.EditMask = "[a-zA-Z]+";
            this.nomecompletoTextEdit.Properties.MaxLength = 70;
            this.nomecompletoTextEdit.Size = new System.Drawing.Size(460, 20);
            this.nomecompletoTextEdit.TabIndex = 2;
            this.nomecompletoTextEdit.ToolTip = "Nome completo, sem abreviações";
            // 
            // idTextEdit
            // 
            this.idTextEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.FuncionarioDTOBindingSource, "Id", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.idTextEdit.Enabled = false;
            this.idTextEdit.Location = new System.Drawing.Point(48, 10);
            this.idTextEdit.Name = "idTextEdit";
            this.idTextEdit.Size = new System.Drawing.Size(112, 20);
            this.idTextEdit.TabIndex = 1;
            this.idTextEdit.TabStop = false;
            // 
            // lblCodigo
            // 
            this.lblCodigo.Location = new System.Drawing.Point(10, 13);
            this.lblCodigo.Name = "lblCodigo";
            this.lblCodigo.Size = new System.Drawing.Size(37, 13);
            this.lblCodigo.TabIndex = 1;
            this.lblCodigo.Text = "Código:";
            // 
            // xtraTabPageDocumentos
            // 
            this.xtraTabPageDocumentos.Controls.Add(this.labelControl74);
            this.xtraTabPageDocumentos.Controls.Add(this.labelControl73);
            this.xtraTabPageDocumentos.Controls.Add(this.labelControl72);
            this.xtraTabPageDocumentos.Controls.Add(this.labelControl71);
            this.xtraTabPageDocumentos.Controls.Add(this.labelControl70);
            this.xtraTabPageDocumentos.Controls.Add(this.labelControl69);
            this.xtraTabPageDocumentos.Controls.Add(this.labelControl68);
            this.xtraTabPageDocumentos.Controls.Add(this.labelControl67);
            this.xtraTabPageDocumentos.Controls.Add(this.labelControl66);
            this.xtraTabPageDocumentos.Controls.Add(this.labelControl65);
            this.xtraTabPageDocumentos.Controls.Add(this.labelControl64);
            this.xtraTabPageDocumentos.Controls.Add(this.labelControl63);
            this.xtraTabPageDocumentos.Controls.Add(this.labelControl62);
            this.xtraTabPageDocumentos.Controls.Add(this.labelControl61);
            this.xtraTabPageDocumentos.Controls.Add(this.labelControl59);
            this.xtraTabPageDocumentos.Controls.Add(this.labelControl58);
            this.xtraTabPageDocumentos.Controls.Add(this.labelControl57);
            this.xtraTabPageDocumentos.Controls.Add(this.labelControl56);
            this.xtraTabPageDocumentos.Controls.Add(this.UFReservistaLookUpEdit);
            this.xtraTabPageDocumentos.Controls.Add(this.rescategoriaTextEdit);
            this.xtraTabPageDocumentos.Controls.Add(this.reservistaTextEdit);
            this.xtraTabPageDocumentos.Controls.Add(this.cnhvencimentoDateEdit);
            this.xtraTabPageDocumentos.Controls.Add(this.cnhcategoriaTextEdit);
            this.xtraTabPageDocumentos.Controls.Add(this.cnhTextEdit);
            this.xtraTabPageDocumentos.Controls.Add(this.cpfTextEdit);
            this.xtraTabPageDocumentos.Controls.Add(this.titulosecaoTextEdit);
            this.xtraTabPageDocumentos.Controls.Add(this.titulozonaTextEdit);
            this.xtraTabPageDocumentos.Controls.Add(this.tituloTextEdit);
            this.xtraTabPageDocumentos.Controls.Add(this.UFRGLookUpEdit);
            this.xtraTabPageDocumentos.Controls.Add(this.rgorgaoTextEdit);
            this.xtraTabPageDocumentos.Controls.Add(this.rgemissaoDateEdit);
            this.xtraTabPageDocumentos.Controls.Add(this.rgTextEdit);
            this.xtraTabPageDocumentos.Controls.Add(this.ctpsemissaoDateEdit);
            this.xtraTabPageDocumentos.Controls.Add(this.UFCTPSLookUpEdit);
            this.xtraTabPageDocumentos.Controls.Add(this.ctpsserieTextEdit);
            this.xtraTabPageDocumentos.Controls.Add(this.ctpsTextEdit);
            this.xtraTabPageDocumentos.Name = "xtraTabPageDocumentos";
            this.xtraTabPageDocumentos.Size = new System.Drawing.Size(1125, 540);
            this.xtraTabPageDocumentos.Text = "Documentos";
            // 
            // labelControl74
            // 
            this.labelControl74.Location = new System.Drawing.Point(352, 94);
            this.labelControl74.Name = "labelControl74";
            this.labelControl74.Size = new System.Drawing.Size(17, 13);
            this.labelControl74.TabIndex = 92;
            this.labelControl74.Text = "UF:";
            // 
            // labelControl73
            // 
            this.labelControl73.Location = new System.Drawing.Point(183, 94);
            this.labelControl73.Name = "labelControl73";
            this.labelControl73.Size = new System.Drawing.Size(51, 13);
            this.labelControl73.TabIndex = 91;
            this.labelControl73.Text = "Categoria:";
            // 
            // labelControl72
            // 
            this.labelControl72.Location = new System.Drawing.Point(10, 94);
            this.labelControl72.Name = "labelControl72";
            this.labelControl72.Size = new System.Drawing.Size(55, 13);
            this.labelControl72.TabIndex = 90;
            this.labelControl72.Text = "Reservista:";
            // 
            // labelControl71
            // 
            this.labelControl71.Location = new System.Drawing.Point(352, 72);
            this.labelControl71.Name = "labelControl71";
            this.labelControl71.Size = new System.Drawing.Size(41, 13);
            this.labelControl71.TabIndex = 89;
            this.labelControl71.Text = "Vencto.:";
            this.labelControl71.ToolTip = "Data de vencimento";
            // 
            // labelControl70
            // 
            this.labelControl70.Location = new System.Drawing.Point(183, 72);
            this.labelControl70.Name = "labelControl70";
            this.labelControl70.Size = new System.Drawing.Size(51, 13);
            this.labelControl70.TabIndex = 88;
            this.labelControl70.Text = "Categoria:";
            // 
            // labelControl69
            // 
            this.labelControl69.Location = new System.Drawing.Point(10, 72);
            this.labelControl69.Name = "labelControl69";
            this.labelControl69.Size = new System.Drawing.Size(25, 13);
            this.labelControl69.TabIndex = 87;
            this.labelControl69.Text = "CNH:";
            // 
            // labelControl68
            // 
            this.labelControl68.Location = new System.Drawing.Point(500, 50);
            this.labelControl68.Name = "labelControl68";
            this.labelControl68.Size = new System.Drawing.Size(33, 13);
            this.labelControl68.TabIndex = 86;
            this.labelControl68.Text = "Seção:";
            // 
            // labelControl67
            // 
            this.labelControl67.Location = new System.Drawing.Point(352, 50);
            this.labelControl67.Name = "labelControl67";
            this.labelControl67.Size = new System.Drawing.Size(28, 13);
            this.labelControl67.TabIndex = 85;
            this.labelControl67.Text = "Zona:";
            // 
            // labelControl66
            // 
            this.labelControl66.Location = new System.Drawing.Point(183, 50);
            this.labelControl66.Name = "labelControl66";
            this.labelControl66.Size = new System.Drawing.Size(53, 13);
            this.labelControl66.TabIndex = 84;
            this.labelControl66.Text = "Tít. Eleitor:";
            this.labelControl66.ToolTip = "Título Eleitoral";
            // 
            // labelControl65
            // 
            this.labelControl65.Location = new System.Drawing.Point(10, 50);
            this.labelControl65.Name = "labelControl65";
            this.labelControl65.Size = new System.Drawing.Size(23, 13);
            this.labelControl65.TabIndex = 83;
            this.labelControl65.Text = "CPF:";
            // 
            // labelControl64
            // 
            this.labelControl64.Location = new System.Drawing.Point(500, 28);
            this.labelControl64.Name = "labelControl64";
            this.labelControl64.Size = new System.Drawing.Size(17, 13);
            this.labelControl64.TabIndex = 82;
            this.labelControl64.Text = "UF:";
            // 
            // labelControl63
            // 
            this.labelControl63.Location = new System.Drawing.Point(352, 28);
            this.labelControl63.Name = "labelControl63";
            this.labelControl63.Size = new System.Drawing.Size(34, 13);
            this.labelControl63.TabIndex = 81;
            this.labelControl63.Text = "Órgão:";
            // 
            // labelControl62
            // 
            this.labelControl62.Location = new System.Drawing.Point(183, 28);
            this.labelControl62.Name = "labelControl62";
            this.labelControl62.Size = new System.Drawing.Size(42, 13);
            this.labelControl62.TabIndex = 80;
            this.labelControl62.Text = "Emissão:";
            // 
            // labelControl61
            // 
            this.labelControl61.Location = new System.Drawing.Point(10, 28);
            this.labelControl61.Name = "labelControl61";
            this.labelControl61.Size = new System.Drawing.Size(18, 13);
            this.labelControl61.TabIndex = 79;
            this.labelControl61.Text = "RG:";
            // 
            // labelControl59
            // 
            this.labelControl59.Location = new System.Drawing.Point(500, 6);
            this.labelControl59.Name = "labelControl59";
            this.labelControl59.Size = new System.Drawing.Size(42, 13);
            this.labelControl59.TabIndex = 78;
            this.labelControl59.Text = "Emissão:";
            // 
            // labelControl58
            // 
            this.labelControl58.Location = new System.Drawing.Point(352, 6);
            this.labelControl58.Name = "labelControl58";
            this.labelControl58.Size = new System.Drawing.Size(17, 13);
            this.labelControl58.TabIndex = 77;
            this.labelControl58.Text = "UF:";
            // 
            // labelControl57
            // 
            this.labelControl57.Location = new System.Drawing.Point(183, 6);
            this.labelControl57.Name = "labelControl57";
            this.labelControl57.Size = new System.Drawing.Size(28, 13);
            this.labelControl57.TabIndex = 76;
            this.labelControl57.Text = "Série:";
            // 
            // labelControl56
            // 
            this.labelControl56.Location = new System.Drawing.Point(10, 6);
            this.labelControl56.Name = "labelControl56";
            this.labelControl56.Size = new System.Drawing.Size(29, 13);
            this.labelControl56.TabIndex = 75;
            this.labelControl56.Text = "CTPS:";
            // 
            // UFReservistaLookUpEdit
            // 
            this.UFReservistaLookUpEdit.CausesValidation = false;
            this.UFReservistaLookUpEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.FuncionarioDTOBindingSource, "Documento.UFreservista.Id", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.UFReservistaLookUpEdit.EnterMoveNextControl = true;
            this.UFReservistaLookUpEdit.Location = new System.Drawing.Point(398, 91);
            this.UFReservistaLookUpEdit.Name = "UFReservistaLookUpEdit";
            this.UFReservistaLookUpEdit.Properties.AllowNullInput = DevExpress.Utils.DefaultBoolean.True;
            this.UFReservistaLookUpEdit.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.UFReservistaLookUpEdit.Properties.Columns.AddRange(new DevExpress.XtraEditors.Controls.LookUpColumnInfo[] {
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("Codigo", "Sigla", 10, DevExpress.Utils.FormatType.None, "", true, DevExpress.Utils.HorzAlignment.Center),
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("Descricao", 30, "Descrição")});
            this.UFReservistaLookUpEdit.Properties.DataSource = this.UFDTOBindingSource;
            this.UFReservistaLookUpEdit.Properties.DisplayMember = "Codigo";
            this.UFReservistaLookUpEdit.Properties.NullText = "";
            this.UFReservistaLookUpEdit.Properties.ValueMember = "Id";
            this.UFReservistaLookUpEdit.Size = new System.Drawing.Size(90, 20);
            this.UFReservistaLookUpEdit.TabIndex = 18;
            this.UFReservistaLookUpEdit.EditValueChanged += new System.EventHandler(this.UFReservistaLookUpEdit_EditValueChanged);
            // 
            // UFDTOBindingSource
            // 
            this.UFDTOBindingSource.DataSource = typeof(MechTech.Entities.UFDTO);
            // 
            // rescategoriaTextEdit
            // 
            this.rescategoriaTextEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.FuncionarioDTOBindingSource, "Documento.Rescategoria", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.rescategoriaTextEdit.EnterMoveNextControl = true;
            this.rescategoriaTextEdit.Location = new System.Drawing.Point(240, 91);
            this.rescategoriaTextEdit.Name = "rescategoriaTextEdit";
            this.rescategoriaTextEdit.Properties.MaxLength = 10;
            this.rescategoriaTextEdit.Size = new System.Drawing.Size(100, 20);
            this.rescategoriaTextEdit.TabIndex = 17;
            this.rescategoriaTextEdit.ToolTip = "Categoria da Reservista";
            // 
            // reservistaTextEdit
            // 
            this.reservistaTextEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.FuncionarioDTOBindingSource, "Documento.Reservista", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.reservistaTextEdit.EnterMoveNextControl = true;
            this.reservistaTextEdit.Location = new System.Drawing.Point(71, 91);
            this.reservistaTextEdit.Name = "reservistaTextEdit";
            this.reservistaTextEdit.Properties.MaxLength = 20;
            this.reservistaTextEdit.Size = new System.Drawing.Size(100, 20);
            this.reservistaTextEdit.TabIndex = 16;
            this.reservistaTextEdit.ToolTip = "Número da reservista";
            // 
            // cnhvencimentoDateEdit
            // 
            this.cnhvencimentoDateEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.FuncionarioDTOBindingSource, "Documento.Cnhvencimento", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.cnhvencimentoDateEdit.EditValue = null;
            this.cnhvencimentoDateEdit.EnterMoveNextControl = true;
            this.cnhvencimentoDateEdit.Location = new System.Drawing.Point(398, 69);
            this.cnhvencimentoDateEdit.Name = "cnhvencimentoDateEdit";
            this.cnhvencimentoDateEdit.Properties.Appearance.Options.UseTextOptions = true;
            this.cnhvencimentoDateEdit.Properties.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.cnhvencimentoDateEdit.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.cnhvencimentoDateEdit.Properties.CalendarTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            this.cnhvencimentoDateEdit.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.DateTimeAdvancingCaret;
            this.cnhvencimentoDateEdit.Size = new System.Drawing.Size(90, 20);
            this.cnhvencimentoDateEdit.TabIndex = 15;
            this.cnhvencimentoDateEdit.ToolTip = "Data de vencimento da CNH";
            // 
            // cnhcategoriaTextEdit
            // 
            this.cnhcategoriaTextEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.FuncionarioDTOBindingSource, "Documento.Cnhcategoria", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.cnhcategoriaTextEdit.EnterMoveNextControl = true;
            this.cnhcategoriaTextEdit.Location = new System.Drawing.Point(240, 69);
            this.cnhcategoriaTextEdit.Name = "cnhcategoriaTextEdit";
            this.cnhcategoriaTextEdit.Properties.MaxLength = 2;
            this.cnhcategoriaTextEdit.Size = new System.Drawing.Size(100, 20);
            this.cnhcategoriaTextEdit.TabIndex = 14;
            this.cnhcategoriaTextEdit.ToolTip = "Categoria da CNH";
            // 
            // cnhTextEdit
            // 
            this.cnhTextEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.FuncionarioDTOBindingSource, "Documento.Cnh", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.cnhTextEdit.EnterMoveNextControl = true;
            this.cnhTextEdit.Location = new System.Drawing.Point(71, 69);
            this.cnhTextEdit.Name = "cnhTextEdit";
            this.cnhTextEdit.Properties.MaxLength = 15;
            this.cnhTextEdit.Size = new System.Drawing.Size(100, 20);
            this.cnhTextEdit.TabIndex = 13;
            this.cnhTextEdit.ToolTip = "Número do registro da CNH";
            // 
            // cpfTextEdit
            // 
            this.cpfTextEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.FuncionarioDTOBindingSource, "Documento.Cpf", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.cpfTextEdit.EnterMoveNextControl = true;
            this.cpfTextEdit.Location = new System.Drawing.Point(71, 47);
            this.cpfTextEdit.Name = "cpfTextEdit";
            this.cpfTextEdit.Properties.Mask.EditMask = "999.999.999-99";
            this.cpfTextEdit.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Simple;
            this.cpfTextEdit.Properties.Mask.SaveLiteral = false;
            this.cpfTextEdit.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.cpfTextEdit.Properties.MaxLength = 11;
            this.cpfTextEdit.Size = new System.Drawing.Size(100, 20);
            this.cpfTextEdit.TabIndex = 9;
            this.cpfTextEdit.ToolTip = "Número do CPF";
            // 
            // titulosecaoTextEdit
            // 
            this.titulosecaoTextEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.FuncionarioDTOBindingSource, "Documento.Titulosecao", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.titulosecaoTextEdit.EnterMoveNextControl = true;
            this.titulosecaoTextEdit.Location = new System.Drawing.Point(549, 47);
            this.titulosecaoTextEdit.Name = "titulosecaoTextEdit";
            this.titulosecaoTextEdit.Properties.MaxLength = 4;
            this.titulosecaoTextEdit.Size = new System.Drawing.Size(95, 20);
            this.titulosecaoTextEdit.TabIndex = 12;
            this.titulosecaoTextEdit.ToolTip = "Número da seção do Título Eleitoral";
            // 
            // titulozonaTextEdit
            // 
            this.titulozonaTextEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.FuncionarioDTOBindingSource, "Documento.Titulozona", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.titulozonaTextEdit.EnterMoveNextControl = true;
            this.titulozonaTextEdit.Location = new System.Drawing.Point(398, 47);
            this.titulozonaTextEdit.Name = "titulozonaTextEdit";
            this.titulozonaTextEdit.Properties.MaxLength = 4;
            this.titulozonaTextEdit.Size = new System.Drawing.Size(90, 20);
            this.titulozonaTextEdit.TabIndex = 11;
            this.titulozonaTextEdit.ToolTip = "Número da zona do Título Eleitoral";
            // 
            // tituloTextEdit
            // 
            this.tituloTextEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.FuncionarioDTOBindingSource, "Documento.Titulo", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.tituloTextEdit.EnterMoveNextControl = true;
            this.tituloTextEdit.Location = new System.Drawing.Point(240, 47);
            this.tituloTextEdit.Name = "tituloTextEdit";
            this.tituloTextEdit.Properties.MaxLength = 20;
            this.tituloTextEdit.Size = new System.Drawing.Size(100, 20);
            this.tituloTextEdit.TabIndex = 10;
            this.tituloTextEdit.ToolTip = "Número do Título Eleitoral";
            // 
            // UFRGLookUpEdit
            // 
            this.UFRGLookUpEdit.CausesValidation = false;
            this.UFRGLookUpEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.FuncionarioDTOBindingSource, "Documento.UFRG.Id", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.UFRGLookUpEdit.EnterMoveNextControl = true;
            this.UFRGLookUpEdit.Location = new System.Drawing.Point(549, 25);
            this.UFRGLookUpEdit.Name = "UFRGLookUpEdit";
            this.UFRGLookUpEdit.Properties.AllowNullInput = DevExpress.Utils.DefaultBoolean.True;
            this.UFRGLookUpEdit.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.UFRGLookUpEdit.Properties.Columns.AddRange(new DevExpress.XtraEditors.Controls.LookUpColumnInfo[] {
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("Codigo", "Sigla", 10, DevExpress.Utils.FormatType.None, "", true, DevExpress.Utils.HorzAlignment.Center),
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("Descricao", 30, "Descrição")});
            this.UFRGLookUpEdit.Properties.DataSource = this.UFDTOBindingSource;
            this.UFRGLookUpEdit.Properties.DisplayMember = "Codigo";
            this.UFRGLookUpEdit.Properties.NullText = "";
            this.UFRGLookUpEdit.Properties.ValueMember = "Id";
            this.UFRGLookUpEdit.Size = new System.Drawing.Size(95, 20);
            this.UFRGLookUpEdit.TabIndex = 8;
            this.UFRGLookUpEdit.EditValueChanged += new System.EventHandler(this.UFRGLookUpEdit_EditValueChanged);
            // 
            // rgorgaoTextEdit
            // 
            this.rgorgaoTextEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.FuncionarioDTOBindingSource, "Documento.Rgorgao", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.rgorgaoTextEdit.EnterMoveNextControl = true;
            this.rgorgaoTextEdit.Location = new System.Drawing.Point(398, 25);
            this.rgorgaoTextEdit.Name = "rgorgaoTextEdit";
            this.rgorgaoTextEdit.Properties.MaxLength = 3;
            this.rgorgaoTextEdit.Size = new System.Drawing.Size(90, 20);
            this.rgorgaoTextEdit.TabIndex = 7;
            this.rgorgaoTextEdit.ToolTip = "Órgão que expediu o RG";
            // 
            // rgemissaoDateEdit
            // 
            this.rgemissaoDateEdit.CausesValidation = false;
            this.rgemissaoDateEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.FuncionarioDTOBindingSource, "Documento.Rgemissao", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.rgemissaoDateEdit.EditValue = null;
            this.rgemissaoDateEdit.EnterMoveNextControl = true;
            this.rgemissaoDateEdit.Location = new System.Drawing.Point(240, 25);
            this.rgemissaoDateEdit.Name = "rgemissaoDateEdit";
            this.rgemissaoDateEdit.Properties.AllowNullInput = DevExpress.Utils.DefaultBoolean.True;
            this.rgemissaoDateEdit.Properties.Appearance.Options.UseTextOptions = true;
            this.rgemissaoDateEdit.Properties.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.rgemissaoDateEdit.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.rgemissaoDateEdit.Properties.CalendarTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            this.rgemissaoDateEdit.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.DateTimeAdvancingCaret;
            this.rgemissaoDateEdit.Size = new System.Drawing.Size(100, 20);
            this.rgemissaoDateEdit.TabIndex = 6;
            this.rgemissaoDateEdit.ToolTip = "Data de emissão do RG";
            // 
            // rgTextEdit
            // 
            this.rgTextEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.FuncionarioDTOBindingSource, "Documento.Rg", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.rgTextEdit.EnterMoveNextControl = true;
            this.rgTextEdit.Location = new System.Drawing.Point(71, 25);
            this.rgTextEdit.Name = "rgTextEdit";
            this.rgTextEdit.Properties.MaxLength = 15;
            this.rgTextEdit.Size = new System.Drawing.Size(100, 20);
            this.rgTextEdit.TabIndex = 5;
            this.rgTextEdit.ToolTip = "Número do RG";
            // 
            // ctpsemissaoDateEdit
            // 
            this.ctpsemissaoDateEdit.CausesValidation = false;
            this.ctpsemissaoDateEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.FuncionarioDTOBindingSource, "Documento.Ctpsemissao", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.ctpsemissaoDateEdit.EditValue = null;
            this.ctpsemissaoDateEdit.EnterMoveNextControl = true;
            this.ctpsemissaoDateEdit.Location = new System.Drawing.Point(549, 3);
            this.ctpsemissaoDateEdit.Name = "ctpsemissaoDateEdit";
            this.ctpsemissaoDateEdit.Properties.Appearance.Options.UseTextOptions = true;
            this.ctpsemissaoDateEdit.Properties.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.ctpsemissaoDateEdit.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.ctpsemissaoDateEdit.Properties.CalendarTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            this.ctpsemissaoDateEdit.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.DateTimeAdvancingCaret;
            this.ctpsemissaoDateEdit.Size = new System.Drawing.Size(95, 20);
            this.ctpsemissaoDateEdit.TabIndex = 4;
            this.ctpsemissaoDateEdit.ToolTip = "Data de emissão da carteira";
            // 
            // UFCTPSLookUpEdit
            // 
            this.UFCTPSLookUpEdit.CausesValidation = false;
            this.UFCTPSLookUpEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.FuncionarioDTOBindingSource, "Documento.UFCTPS.Id", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.UFCTPSLookUpEdit.EnterMoveNextControl = true;
            this.UFCTPSLookUpEdit.Location = new System.Drawing.Point(398, 3);
            this.UFCTPSLookUpEdit.Name = "UFCTPSLookUpEdit";
            this.UFCTPSLookUpEdit.Properties.AllowNullInput = DevExpress.Utils.DefaultBoolean.True;
            this.UFCTPSLookUpEdit.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.UFCTPSLookUpEdit.Properties.Columns.AddRange(new DevExpress.XtraEditors.Controls.LookUpColumnInfo[] {
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("Codigo", "Sigla", 10, DevExpress.Utils.FormatType.None, "", true, DevExpress.Utils.HorzAlignment.Center),
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("Descricao", 30, "Descrição")});
            this.UFCTPSLookUpEdit.Properties.DataSource = this.UFDTOBindingSource;
            this.UFCTPSLookUpEdit.Properties.DisplayMember = "Codigo";
            this.UFCTPSLookUpEdit.Properties.NullText = "";
            this.UFCTPSLookUpEdit.Properties.ValueMember = "Id";
            this.UFCTPSLookUpEdit.Size = new System.Drawing.Size(90, 20);
            this.UFCTPSLookUpEdit.TabIndex = 3;
            this.UFCTPSLookUpEdit.EditValueChanged += new System.EventHandler(this.UFCTPSLookUpEdit_EditValueChanged);
            // 
            // ctpsserieTextEdit
            // 
            this.ctpsserieTextEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.FuncionarioDTOBindingSource, "Documento.Ctpsserie", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.ctpsserieTextEdit.EnterMoveNextControl = true;
            this.ctpsserieTextEdit.Location = new System.Drawing.Point(240, 3);
            this.ctpsserieTextEdit.Name = "ctpsserieTextEdit";
            this.ctpsserieTextEdit.Properties.MaxLength = 4;
            this.ctpsserieTextEdit.Size = new System.Drawing.Size(100, 20);
            this.ctpsserieTextEdit.TabIndex = 2;
            this.ctpsserieTextEdit.ToolTip = "Série da carteira";
            // 
            // ctpsTextEdit
            // 
            this.ctpsTextEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.FuncionarioDTOBindingSource, "Documento.Ctps", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.ctpsTextEdit.EnterMoveNextControl = true;
            this.ctpsTextEdit.Location = new System.Drawing.Point(71, 3);
            this.ctpsTextEdit.Name = "ctpsTextEdit";
            this.ctpsTextEdit.Properties.MaxLength = 8;
            this.ctpsTextEdit.Size = new System.Drawing.Size(100, 20);
            this.ctpsTextEdit.TabIndex = 1;
            this.ctpsTextEdit.ToolTip = "Número da carteira";
            // 
            // xtraTabPageSalario
            // 
            this.xtraTabPageSalario.Controls.Add(this.gpcBancoDeposito);
            this.xtraTabPageSalario.Controls.Add(this.salarioGridControl);
            this.xtraTabPageSalario.Controls.Add(this.btnAlterarSalario);
            this.xtraTabPageSalario.Controls.Add(this.btnExcluirSalario);
            this.xtraTabPageSalario.Controls.Add(this.btnVisualizarSalario);
            this.xtraTabPageSalario.Controls.Add(this.btnInserirSalario);
            this.xtraTabPageSalario.Name = "xtraTabPageSalario";
            this.xtraTabPageSalario.Size = new System.Drawing.Size(1125, 540);
            this.xtraTabPageSalario.Text = "Salário";
            // 
            // gpcBancoDeposito
            // 
            this.gpcBancoDeposito.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.gpcBancoDeposito.Controls.Add(this.labelControl55);
            this.gpcBancoDeposito.Controls.Add(this.bancosalarioLookUpEdit);
            this.gpcBancoDeposito.Controls.Add(this.tipocontacomboBoxEdit);
            this.gpcBancoDeposito.Controls.Add(this.labelControl36);
            this.gpcBancoDeposito.Controls.Add(this.labelControl41);
            this.gpcBancoDeposito.Controls.Add(this.salcontaTextEdit);
            this.gpcBancoDeposito.Controls.Add(this.labelControl40);
            this.gpcBancoDeposito.Controls.Add(this.salcontadv1TextEdit);
            this.gpcBancoDeposito.Controls.Add(this.salagenciadvTextEdit);
            this.gpcBancoDeposito.Controls.Add(this.salcontadv2TextEdit);
            this.gpcBancoDeposito.Controls.Add(this.salagenciaTextEdit);
            this.gpcBancoDeposito.Controls.Add(this.labelControl37);
            this.gpcBancoDeposito.Controls.Add(this.labelControl39);
            this.gpcBancoDeposito.Controls.Add(this.labelControl38);
            this.gpcBancoDeposito.Location = new System.Drawing.Point(3, 244);
            this.gpcBancoDeposito.Name = "gpcBancoDeposito";
            this.gpcBancoDeposito.Size = new System.Drawing.Size(406, 72);
            this.gpcBancoDeposito.TabIndex = 34;
            this.gpcBancoDeposito.Text = "Banco para depósito";
            // 
            // labelControl55
            // 
            this.labelControl55.Location = new System.Drawing.Point(5, 50);
            this.labelControl55.Name = "labelControl55";
            this.labelControl55.Size = new System.Drawing.Size(24, 13);
            this.labelControl55.TabIndex = 19;
            this.labelControl55.Text = "Tipo:";
            // 
            // bancosalarioLookUpEdit
            // 
            this.bancosalarioLookUpEdit.CausesValidation = false;
            this.bancosalarioLookUpEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.FuncionarioDTOBindingSource, "Bancosalario.Id", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.bancosalarioLookUpEdit.EnterMoveNextControl = true;
            this.bancosalarioLookUpEdit.Location = new System.Drawing.Point(44, 25);
            this.bancosalarioLookUpEdit.Name = "bancosalarioLookUpEdit";
            this.bancosalarioLookUpEdit.Properties.AllowNullInput = DevExpress.Utils.DefaultBoolean.True;
            this.bancosalarioLookUpEdit.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.bancosalarioLookUpEdit.Properties.Columns.AddRange(new DevExpress.XtraEditors.Controls.LookUpColumnInfo[] {
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("Codigo", "Código", 10, DevExpress.Utils.FormatType.None, "", true, DevExpress.Utils.HorzAlignment.Center),
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("Nome", 55, "Nome")});
            this.bancosalarioLookUpEdit.Properties.DataSource = this.BancoDTOBindingSource;
            this.bancosalarioLookUpEdit.Properties.DisplayMember = "Codigo";
            this.bancosalarioLookUpEdit.Properties.NullText = "";
            this.bancosalarioLookUpEdit.Properties.PopupWidth = 400;
            this.bancosalarioLookUpEdit.Properties.ValueMember = "Id";
            this.bancosalarioLookUpEdit.Size = new System.Drawing.Size(75, 20);
            this.bancosalarioLookUpEdit.TabIndex = 5;
            this.bancosalarioLookUpEdit.EditValueChanged += new System.EventHandler(this.bancosalarioLookUpEdit_EditValueChanged);
            // 
            // BancoDTOBindingSource
            // 
            this.BancoDTOBindingSource.DataSource = typeof(MechTech.Entities.BancoDTO);
            // 
            // tipocontacomboBoxEdit
            // 
            this.tipocontacomboBoxEdit.CausesValidation = false;
            this.tipocontacomboBoxEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.FuncionarioDTOBindingSource, "Salcontatp", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.tipocontacomboBoxEdit.EditValue = "";
            this.tipocontacomboBoxEdit.EnterMoveNextControl = true;
            this.tipocontacomboBoxEdit.Location = new System.Drawing.Point(44, 47);
            this.tipocontacomboBoxEdit.Name = "tipocontacomboBoxEdit";
            this.tipocontacomboBoxEdit.Properties.AllowNullInput = DevExpress.Utils.DefaultBoolean.True;
            this.tipocontacomboBoxEdit.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.tipocontacomboBoxEdit.Properties.Items.AddRange(new object[] {
            "Corrente",
            "Salário",
            "Poupança"});
            this.tipocontacomboBoxEdit.Properties.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.DisableTextEditor;
            this.tipocontacomboBoxEdit.Size = new System.Drawing.Size(75, 20);
            this.tipocontacomboBoxEdit.TabIndex = 8;
            this.tipocontacomboBoxEdit.ToolTip = "Tipo de conta (Corrente/Salário)";
            this.tipocontacomboBoxEdit.EditValueChanged += new System.EventHandler(this.tipocontacomboBoxEdit_EditValueChanged);
            // 
            // labelControl36
            // 
            this.labelControl36.Location = new System.Drawing.Point(5, 28);
            this.labelControl36.Name = "labelControl36";
            this.labelControl36.Size = new System.Drawing.Size(33, 13);
            this.labelControl36.TabIndex = 4;
            this.labelControl36.Text = "Banco:";
            // 
            // labelControl41
            // 
            this.labelControl41.Location = new System.Drawing.Point(270, 28);
            this.labelControl41.Name = "labelControl41";
            this.labelControl41.Size = new System.Drawing.Size(17, 13);
            this.labelControl41.TabIndex = 16;
            this.labelControl41.Text = "DV:";
            this.labelControl41.ToolTip = "Dígito verificador";
            // 
            // salcontaTextEdit
            // 
            this.salcontaTextEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.FuncionarioDTOBindingSource, "Salconta", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.salcontaTextEdit.EnterMoveNextControl = true;
            this.salcontaTextEdit.Location = new System.Drawing.Point(173, 47);
            this.salcontaTextEdit.Name = "salcontaTextEdit";
            this.salcontaTextEdit.Properties.MaxLength = 15;
            this.salcontaTextEdit.Size = new System.Drawing.Size(91, 20);
            this.salcontaTextEdit.TabIndex = 9;
            this.salcontaTextEdit.ToolTip = "Conta para depósito do salário";
            // 
            // labelControl40
            // 
            this.labelControl40.Location = new System.Drawing.Point(125, 28);
            this.labelControl40.Name = "labelControl40";
            this.labelControl40.Size = new System.Drawing.Size(42, 13);
            this.labelControl40.TabIndex = 15;
            this.labelControl40.Text = "Agência:";
            // 
            // salcontadv1TextEdit
            // 
            this.salcontadv1TextEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.FuncionarioDTOBindingSource, "Salcontadv1", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.salcontadv1TextEdit.EditValue = "";
            this.salcontadv1TextEdit.EnterMoveNextControl = true;
            this.salcontadv1TextEdit.Location = new System.Drawing.Point(299, 47);
            this.salcontadv1TextEdit.Name = "salcontadv1TextEdit";
            this.salcontadv1TextEdit.Properties.MaxLength = 1;
            this.salcontadv1TextEdit.Size = new System.Drawing.Size(30, 20);
            this.salcontadv1TextEdit.TabIndex = 10;
            this.salcontadv1TextEdit.ToolTip = "Dígito da conta - Salário";
            // 
            // salagenciadvTextEdit
            // 
            this.salagenciadvTextEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.FuncionarioDTOBindingSource, "Salagenciadv", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.salagenciadvTextEdit.EnterMoveNextControl = true;
            this.salagenciadvTextEdit.Location = new System.Drawing.Point(299, 25);
            this.salagenciadvTextEdit.Name = "salagenciadvTextEdit";
            this.salagenciadvTextEdit.Properties.MaxLength = 1;
            this.salagenciadvTextEdit.Size = new System.Drawing.Size(30, 20);
            this.salagenciadvTextEdit.TabIndex = 7;
            this.salagenciadvTextEdit.ToolTip = "Dígito verificador da agência - Salário";
            // 
            // salcontadv2TextEdit
            // 
            this.salcontadv2TextEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.FuncionarioDTOBindingSource, "Salcontadv2", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.salcontadv2TextEdit.EnterMoveNextControl = true;
            this.salcontadv2TextEdit.Location = new System.Drawing.Point(363, 47);
            this.salcontadv2TextEdit.Name = "salcontadv2TextEdit";
            this.salcontadv2TextEdit.Properties.MaxLength = 2;
            this.salcontadv2TextEdit.Size = new System.Drawing.Size(35, 20);
            this.salcontadv2TextEdit.TabIndex = 11;
            this.salcontadv2TextEdit.ToolTip = "Dígito adicional da conta - Salário";
            // 
            // salagenciaTextEdit
            // 
            this.salagenciaTextEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.FuncionarioDTOBindingSource, "Salagencia", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.salagenciaTextEdit.EnterMoveNextControl = true;
            this.salagenciaTextEdit.Location = new System.Drawing.Point(173, 25);
            this.salagenciaTextEdit.Name = "salagenciaTextEdit";
            this.salagenciaTextEdit.Properties.MaxLength = 10;
            this.salagenciaTextEdit.Size = new System.Drawing.Size(91, 20);
            this.salagenciaTextEdit.TabIndex = 6;
            this.salagenciaTextEdit.ToolTip = "Número da agência - Salário";
            // 
            // labelControl37
            // 
            this.labelControl37.Location = new System.Drawing.Point(125, 50);
            this.labelControl37.Name = "labelControl37";
            this.labelControl37.Size = new System.Drawing.Size(33, 13);
            this.labelControl37.TabIndex = 10;
            this.labelControl37.Text = "Conta:";
            // 
            // labelControl39
            // 
            this.labelControl39.Location = new System.Drawing.Point(335, 50);
            this.labelControl39.Name = "labelControl39";
            this.labelControl39.Size = new System.Drawing.Size(23, 13);
            this.labelControl39.TabIndex = 1;
            this.labelControl39.Text = "DV2:";
            this.labelControl39.ToolTip = "Dígito verificador adicional";
            // 
            // labelControl38
            // 
            this.labelControl38.Location = new System.Drawing.Point(270, 50);
            this.labelControl38.Name = "labelControl38";
            this.labelControl38.Size = new System.Drawing.Size(23, 13);
            this.labelControl38.TabIndex = 0;
            this.labelControl38.Text = "DV1:";
            this.labelControl38.ToolTip = "Dígito verificador";
            // 
            // salarioGridControl
            // 
            this.salarioGridControl.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.salarioGridControl.DataSource = this.SalarioBindingSource;
            this.salarioGridControl.Location = new System.Drawing.Point(3, 32);
            this.salarioGridControl.MainView = this.gridViewSalario;
            this.salarioGridControl.Name = "salarioGridControl";
            this.salarioGridControl.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemTextEdit1});
            this.salarioGridControl.Size = new System.Drawing.Size(1114, 206);
            this.salarioGridControl.TabIndex = 33;
            this.salarioGridControl.TabStop = false;
            this.salarioGridControl.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridViewSalario});
            this.salarioGridControl.DoubleClick += new System.EventHandler(this.salarioGridControl_DoubleClick);
            // 
            // SalarioBindingSource
            // 
            this.SalarioBindingSource.DataMember = "Salario";
            this.SalarioBindingSource.DataSource = this.FuncionarioDTOBindingSource;
            // 
            // gridViewSalario
            // 
            this.gridViewSalario.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.colData,
            this.colDissidio,
            this.colDepartamento,
            this.colSetor,
            this.colSecao,
            this.colFuncao,
            this.colHoras,
            this.colSalario});
            this.gridViewSalario.GridControl = this.salarioGridControl;
            this.gridViewSalario.Name = "gridViewSalario";
            this.gridViewSalario.OptionsBehavior.Editable = false;
            this.gridViewSalario.OptionsCustomization.AllowColumnMoving = false;
            this.gridViewSalario.OptionsCustomization.AllowColumnResizing = false;
            this.gridViewSalario.OptionsCustomization.AllowFilter = false;
            this.gridViewSalario.OptionsCustomization.AllowGroup = false;
            this.gridViewSalario.OptionsCustomization.AllowSort = false;
            this.gridViewSalario.OptionsMenu.EnableColumnMenu = false;
            this.gridViewSalario.OptionsMenu.EnableFooterMenu = false;
            this.gridViewSalario.OptionsMenu.EnableGroupPanelMenu = false;
            this.gridViewSalario.OptionsNavigation.EnterMoveNextColumn = true;
            this.gridViewSalario.OptionsView.ShowGroupPanel = false;
            this.gridViewSalario.RowStyle += new DevExpress.XtraGrid.Views.Grid.RowStyleEventHandler(this.gridViewSalario_RowStyle);
            this.gridViewSalario.CustomUnboundColumnData += new DevExpress.XtraGrid.Views.Base.CustomColumnDataEventHandler(this.gridViewSalario_CustomUnboundColumnData);
            this.gridViewSalario.RowCountChanged += new System.EventHandler(this.gridViewSalario_RowCountChanged);
            // 
            // colData
            // 
            this.colData.AppearanceCell.Options.UseTextOptions = true;
            this.colData.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colData.AppearanceHeader.Options.UseTextOptions = true;
            this.colData.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colData.Caption = "Data";
            this.colData.FieldName = "Data";
            this.colData.Name = "colData";
            this.colData.OptionsColumn.FixedWidth = true;
            this.colData.Visible = true;
            this.colData.VisibleIndex = 0;
            this.colData.Width = 65;
            // 
            // colDissidio
            // 
            this.colDissidio.AppearanceCell.Options.UseTextOptions = true;
            this.colDissidio.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colDissidio.AppearanceHeader.Options.UseTextOptions = true;
            this.colDissidio.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colDissidio.Caption = "Dissídio";
            this.colDissidio.FieldName = "DataReajuste";
            this.colDissidio.Name = "colDissidio";
            this.colDissidio.OptionsColumn.FixedWidth = true;
            this.colDissidio.Visible = true;
            this.colDissidio.VisibleIndex = 1;
            this.colDissidio.Width = 65;
            // 
            // colDepartamento
            // 
            this.colDepartamento.AppearanceCell.Options.UseTextOptions = true;
            this.colDepartamento.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.colDepartamento.AppearanceHeader.Options.UseTextOptions = true;
            this.colDepartamento.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colDepartamento.Caption = "Depto.";
            this.colDepartamento.FieldName = "Departamento.Codigo";
            this.colDepartamento.Name = "colDepartamento";
            this.colDepartamento.OptionsColumn.FixedWidth = true;
            this.colDepartamento.UnboundType = DevExpress.Data.UnboundColumnType.String;
            this.colDepartamento.Visible = true;
            this.colDepartamento.VisibleIndex = 2;
            this.colDepartamento.Width = 50;
            // 
            // colSetor
            // 
            this.colSetor.AppearanceCell.Options.UseTextOptions = true;
            this.colSetor.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.colSetor.AppearanceHeader.Options.UseTextOptions = true;
            this.colSetor.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colSetor.Caption = "Setor";
            this.colSetor.FieldName = "Setor.Codigo";
            this.colSetor.Name = "colSetor";
            this.colSetor.OptionsColumn.FixedWidth = true;
            this.colSetor.UnboundType = DevExpress.Data.UnboundColumnType.String;
            this.colSetor.Width = 50;
            // 
            // colSecao
            // 
            this.colSecao.AppearanceCell.Options.UseTextOptions = true;
            this.colSecao.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.colSecao.AppearanceHeader.Options.UseTextOptions = true;
            this.colSecao.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colSecao.Caption = "Seção";
            this.colSecao.FieldName = "Secao.Codigo";
            this.colSecao.Name = "colSecao";
            this.colSecao.OptionsColumn.FixedWidth = true;
            this.colSecao.UnboundType = DevExpress.Data.UnboundColumnType.String;
            this.colSecao.Width = 50;
            // 
            // colFuncao
            // 
            this.colFuncao.AppearanceHeader.Options.UseTextOptions = true;
            this.colFuncao.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colFuncao.Caption = "Cargo";
            this.colFuncao.FieldName = "Funcao.Nome";
            this.colFuncao.Name = "colFuncao";
            this.colFuncao.UnboundType = DevExpress.Data.UnboundColumnType.String;
            this.colFuncao.Visible = true;
            this.colFuncao.VisibleIndex = 3;
            this.colFuncao.Width = 114;
            // 
            // colHoras
            // 
            this.colHoras.AppearanceCell.Options.UseTextOptions = true;
            this.colHoras.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.colHoras.AppearanceHeader.Options.UseTextOptions = true;
            this.colHoras.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colHoras.Caption = "Horas/Mês";
            this.colHoras.FieldName = "Funcao.Horas";
            this.colHoras.Name = "colHoras";
            this.colHoras.OptionsColumn.FixedWidth = true;
            this.colHoras.UnboundType = DevExpress.Data.UnboundColumnType.String;
            this.colHoras.Visible = true;
            this.colHoras.VisibleIndex = 4;
            this.colHoras.Width = 65;
            // 
            // colSalario
            // 
            this.colSalario.AppearanceCell.Options.UseTextOptions = true;
            this.colSalario.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.colSalario.AppearanceHeader.Options.UseTextOptions = true;
            this.colSalario.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colSalario.Caption = "Salário";
            this.colSalario.FieldName = "Salario.Salario";
            this.colSalario.Name = "colSalario";
            this.colSalario.OptionsColumn.FixedWidth = true;
            this.colSalario.UnboundType = DevExpress.Data.UnboundColumnType.String;
            this.colSalario.Visible = true;
            this.colSalario.VisibleIndex = 5;
            this.colSalario.Width = 100;
            // 
            // repositoryItemTextEdit1
            // 
            this.repositoryItemTextEdit1.AutoHeight = false;
            this.repositoryItemTextEdit1.Mask.EditMask = "c2";
            this.repositoryItemTextEdit1.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.repositoryItemTextEdit1.Name = "repositoryItemTextEdit1";
            // 
            // btnAlterarSalario
            // 
            this.btnAlterarSalario.Enabled = false;
            this.btnAlterarSalario.Image = ((System.Drawing.Image)(resources.GetObject("btnAlterarSalario.Image")));
            this.btnAlterarSalario.ImageIndex = 2;
            this.btnAlterarSalario.Location = new System.Drawing.Point(84, 3);
            this.btnAlterarSalario.Name = "btnAlterarSalario";
            this.btnAlterarSalario.Size = new System.Drawing.Size(75, 23);
            this.btnAlterarSalario.TabIndex = 2;
            this.btnAlterarSalario.TabStop = false;
            this.btnAlterarSalario.Text = "&Alterar";
            this.btnAlterarSalario.ToolTip = "Alterar dependente";
            this.btnAlterarSalario.Click += new System.EventHandler(this.btnAlterarSalario_Click);
            // 
            // btnExcluirSalario
            // 
            this.btnExcluirSalario.Enabled = false;
            this.btnExcluirSalario.Image = ((System.Drawing.Image)(resources.GetObject("btnExcluirSalario.Image")));
            this.btnExcluirSalario.ImageIndex = 4;
            this.btnExcluirSalario.Location = new System.Drawing.Point(165, 3);
            this.btnExcluirSalario.Name = "btnExcluirSalario";
            this.btnExcluirSalario.Size = new System.Drawing.Size(75, 23);
            this.btnExcluirSalario.TabIndex = 3;
            this.btnExcluirSalario.TabStop = false;
            this.btnExcluirSalario.Text = "&Excluir";
            this.btnExcluirSalario.ToolTip = "Excluir salário";
            this.btnExcluirSalario.Click += new System.EventHandler(this.btnExcluirSalario_Click);
            // 
            // btnVisualizarSalario
            // 
            this.btnVisualizarSalario.Enabled = false;
            this.btnVisualizarSalario.Image = ((System.Drawing.Image)(resources.GetObject("btnVisualizarSalario.Image")));
            this.btnVisualizarSalario.ImageIndex = 0;
            this.btnVisualizarSalario.Location = new System.Drawing.Point(246, 3);
            this.btnVisualizarSalario.Name = "btnVisualizarSalario";
            this.btnVisualizarSalario.Size = new System.Drawing.Size(75, 23);
            this.btnVisualizarSalario.TabIndex = 4;
            this.btnVisualizarSalario.TabStop = false;
            this.btnVisualizarSalario.Text = "&Visualizar";
            this.btnVisualizarSalario.ToolTip = "Visualizar salário";
            this.btnVisualizarSalario.Click += new System.EventHandler(this.btnVisualizarSalario_Click);
            // 
            // btnInserirSalario
            // 
            this.btnInserirSalario.Image = ((System.Drawing.Image)(resources.GetObject("btnInserirSalario.Image")));
            this.btnInserirSalario.ImageIndex = 6;
            this.btnInserirSalario.Location = new System.Drawing.Point(3, 3);
            this.btnInserirSalario.Name = "btnInserirSalario";
            this.btnInserirSalario.Size = new System.Drawing.Size(75, 23);
            this.btnInserirSalario.TabIndex = 1;
            this.btnInserirSalario.TabStop = false;
            this.btnInserirSalario.Text = "&Novo";
            this.btnInserirSalario.ToolTip = "Novo salário";
            this.btnInserirSalario.Click += new System.EventHandler(this.btnInserirSalario_Click);
            // 
            // MunicipioDTOBindingSource
            // 
            this.MunicipioDTOBindingSource.DataSource = typeof(MechTech.Entities.MunicipioDTO);
            // 
            // DepartamentoDTOBindingSource
            // 
            this.DepartamentoDTOBindingSource.DataSource = typeof(MechTech.Entities.DepartamentoDTO);
            // 
            // SetorDTOBindingSource
            // 
            this.SetorDTOBindingSource.DataSource = typeof(MechTech.Entities.SetorDTO);
            // 
            // SecaoDTOBindingSource
            // 
            this.SecaoDTOBindingSource.DataSource = typeof(MechTech.Entities.SecaoDTO);
            // 
            // barManager
            // 
            this.barManager.Bars.AddRange(new DevExpress.XtraBars.Bar[] {
            this.bar2});
            this.barManager.DockControls.Add(this.barDockControlTop);
            this.barManager.DockControls.Add(this.barDockControlBottom);
            this.barManager.DockControls.Add(this.barDockControlLeft);
            this.barManager.DockControls.Add(this.barDockControlRight);
            this.barManager.Form = this;
            this.barManager.Items.AddRange(new DevExpress.XtraBars.BarItem[] {
            this.btnSalvar,
            this.btnCancelar,
            this.btnPrimeiro,
            this.btnAnterior,
            this.btnProximo,
            this.btnUltimo});
            this.barManager.MainMenu = this.bar2;
            this.barManager.MaxItemId = 6;
            // 
            // bar2
            // 
            this.bar2.BarName = "Main menu";
            this.bar2.DockCol = 0;
            this.bar2.DockRow = 0;
            this.bar2.DockStyle = DevExpress.XtraBars.BarDockStyle.Top;
            this.bar2.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(DevExpress.XtraBars.BarLinkUserDefines.PaintStyle, this.btnSalvar, DevExpress.XtraBars.BarItemPaintStyle.CaptionGlyph),
            new DevExpress.XtraBars.LinkPersistInfo(DevExpress.XtraBars.BarLinkUserDefines.PaintStyle, this.btnCancelar, DevExpress.XtraBars.BarItemPaintStyle.CaptionGlyph),
            new DevExpress.XtraBars.LinkPersistInfo(DevExpress.XtraBars.BarLinkUserDefines.PaintStyle, this.btnPrimeiro, DevExpress.XtraBars.BarItemPaintStyle.CaptionGlyph),
            new DevExpress.XtraBars.LinkPersistInfo(DevExpress.XtraBars.BarLinkUserDefines.PaintStyle, this.btnAnterior, DevExpress.XtraBars.BarItemPaintStyle.CaptionGlyph),
            new DevExpress.XtraBars.LinkPersistInfo(DevExpress.XtraBars.BarLinkUserDefines.PaintStyle, this.btnProximo, DevExpress.XtraBars.BarItemPaintStyle.CaptionGlyph),
            new DevExpress.XtraBars.LinkPersistInfo(DevExpress.XtraBars.BarLinkUserDefines.PaintStyle, this.btnUltimo, DevExpress.XtraBars.BarItemPaintStyle.CaptionGlyph)});
            this.bar2.OptionsBar.AllowQuickCustomization = false;
            this.bar2.OptionsBar.DrawBorder = false;
            this.bar2.OptionsBar.UseWholeRow = true;
            this.bar2.Text = "Menu principal";
            // 
            // btnSalvar
            // 
            this.btnSalvar.Caption = "&Salvar";
            this.btnSalvar.Glyph = ((System.Drawing.Image)(resources.GetObject("btnSalvar.Glyph")));
            this.btnSalvar.Id = 0;
            this.btnSalvar.LargeGlyph = ((System.Drawing.Image)(resources.GetObject("btnSalvar.LargeGlyph")));
            this.btnSalvar.Name = "btnSalvar";
            this.btnSalvar.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnSalvar_ItemClick);
            // 
            // btnCancelar
            // 
            this.btnCancelar.Caption = "&Cancelar";
            this.btnCancelar.Glyph = ((System.Drawing.Image)(resources.GetObject("btnCancelar.Glyph")));
            this.btnCancelar.Id = 1;
            this.btnCancelar.LargeGlyph = ((System.Drawing.Image)(resources.GetObject("btnCancelar.LargeGlyph")));
            this.btnCancelar.Name = "btnCancelar";
            this.btnCancelar.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnCancelar_ItemClick);
            // 
            // btnPrimeiro
            // 
            this.btnPrimeiro.Caption = "&Primeiro";
            this.btnPrimeiro.Glyph = ((System.Drawing.Image)(resources.GetObject("btnPrimeiro.Glyph")));
            this.btnPrimeiro.Id = 2;
            this.btnPrimeiro.LargeGlyph = ((System.Drawing.Image)(resources.GetObject("btnPrimeiro.LargeGlyph")));
            this.btnPrimeiro.Name = "btnPrimeiro";
            this.btnPrimeiro.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnPrimeiro_ItemClick);
            // 
            // btnAnterior
            // 
            this.btnAnterior.Caption = "&Anterior";
            this.btnAnterior.Glyph = ((System.Drawing.Image)(resources.GetObject("btnAnterior.Glyph")));
            this.btnAnterior.Id = 3;
            this.btnAnterior.LargeGlyph = ((System.Drawing.Image)(resources.GetObject("btnAnterior.LargeGlyph")));
            this.btnAnterior.Name = "btnAnterior";
            this.btnAnterior.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnAnterior_ItemClick);
            // 
            // btnProximo
            // 
            this.btnProximo.Caption = "P&róximo";
            this.btnProximo.Glyph = ((System.Drawing.Image)(resources.GetObject("btnProximo.Glyph")));
            this.btnProximo.Id = 4;
            this.btnProximo.LargeGlyph = ((System.Drawing.Image)(resources.GetObject("btnProximo.LargeGlyph")));
            this.btnProximo.Name = "btnProximo";
            this.btnProximo.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnProximo_ItemClick);
            // 
            // btnUltimo
            // 
            this.btnUltimo.Caption = "&Último";
            this.btnUltimo.Glyph = ((System.Drawing.Image)(resources.GetObject("btnUltimo.Glyph")));
            this.btnUltimo.Id = 5;
            this.btnUltimo.LargeGlyph = ((System.Drawing.Image)(resources.GetObject("btnUltimo.LargeGlyph")));
            this.btnUltimo.Name = "btnUltimo";
            this.btnUltimo.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnUltimo_ItemClick);
            // 
            // barDockControlTop
            // 
            this.barDockControlTop.CausesValidation = false;
            this.barDockControlTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.barDockControlTop.Location = new System.Drawing.Point(0, 0);
            this.barDockControlTop.Size = new System.Drawing.Size(1154, 24);
            // 
            // barDockControlBottom
            // 
            this.barDockControlBottom.CausesValidation = false;
            this.barDockControlBottom.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.barDockControlBottom.Location = new System.Drawing.Point(0, 596);
            this.barDockControlBottom.Size = new System.Drawing.Size(1154, 0);
            // 
            // barDockControlLeft
            // 
            this.barDockControlLeft.CausesValidation = false;
            this.barDockControlLeft.Dock = System.Windows.Forms.DockStyle.Left;
            this.barDockControlLeft.Location = new System.Drawing.Point(0, 24);
            this.barDockControlLeft.Size = new System.Drawing.Size(0, 572);
            // 
            // barDockControlRight
            // 
            this.barDockControlRight.CausesValidation = false;
            this.barDockControlRight.Dock = System.Windows.Forms.DockStyle.Right;
            this.barDockControlRight.Location = new System.Drawing.Point(1154, 24);
            this.barDockControlRight.Size = new System.Drawing.Size(0, 572);
            // 
            // frmUpdateFuncionario
            // 
            this.Appearance.Options.UseFont = true;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1154, 596);
            this.Controls.Add(this.groupControlFuncionarios);
            this.Controls.Add(this.barDockControlLeft);
            this.Controls.Add(this.barDockControlRight);
            this.Controls.Add(this.barDockControlBottom);
            this.Controls.Add(this.barDockControlTop);
            this.Name = "frmUpdateFuncionario";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.frmUpdateFuncionario_FormClosed);
            this.Load += new System.EventHandler(this.frmUpdateFuncionario_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dxErrorProvider)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.groupControlFuncionarios)).EndInit();
            this.groupControlFuncionarios.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.xtraTabControl)).EndInit();
            this.xtraTabControl.ResumeLayout(false);
            this.xtraTabPageFuncionario.ResumeLayout(false);
            this.xtraTabPageFuncionario.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.datademissaoDateEdit.Properties.CalendarTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.datademissaoDateEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.FuncionarioDTOBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataadmissaoDateEdit.Properties.CalendarTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataadmissaoDateEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fotopictureEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.datanascimentoDateEdit.Properties.CalendarTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.datanascimentoDateEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emailTextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sexocomboBoxEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.celularTextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dddcelularTextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.telefoneTextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dddtelefoneTextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.UFTextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.municipioTextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.codigoibgeButtonEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bairroTextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.complementoTextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numeroTextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.enderecoTextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cepTextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nomecompletoTextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.idTextEdit.Properties)).EndInit();
            this.xtraTabPageDocumentos.ResumeLayout(false);
            this.xtraTabPageDocumentos.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.UFReservistaLookUpEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.UFDTOBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rescategoriaTextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.reservistaTextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cnhvencimentoDateEdit.Properties.CalendarTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cnhvencimentoDateEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cnhcategoriaTextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cnhTextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cpfTextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.titulosecaoTextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.titulozonaTextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tituloTextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.UFRGLookUpEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rgorgaoTextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rgemissaoDateEdit.Properties.CalendarTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rgemissaoDateEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rgTextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ctpsemissaoDateEdit.Properties.CalendarTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ctpsemissaoDateEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.UFCTPSLookUpEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ctpsserieTextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ctpsTextEdit.Properties)).EndInit();
            this.xtraTabPageSalario.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gpcBancoDeposito)).EndInit();
            this.gpcBancoDeposito.ResumeLayout(false);
            this.gpcBancoDeposito.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bancosalarioLookUpEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BancoDTOBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tipocontacomboBoxEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.salcontaTextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.salcontadv1TextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.salagenciadvTextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.salcontadv2TextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.salagenciaTextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.salarioGridControl)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SalarioBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewSalario)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.MunicipioDTOBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DepartamentoDTOBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SetorDTOBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SecaoDTOBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SemanaBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.barManager)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private DevExpress.XtraEditors.DXErrorProvider.DXErrorProvider dxErrorProvider;
        private DevExpress.Utils.ToolTipController toolTipController;
        private DevExpress.XtraEditors.GroupControl groupControlFuncionarios;
        private DevExpress.XtraTab.XtraTabControl xtraTabControl;
        private DevExpress.XtraTab.XtraTabPage xtraTabPageFuncionario;
        private DevExpress.XtraEditors.LabelControl labelControl12;
        private DevExpress.XtraEditors.LabelControl labelControl19;
        private DevExpress.XtraEditors.DateEdit datanascimentoDateEdit;
        private DevExpress.XtraEditors.LabelControl labelControl16;
        private DevExpress.XtraEditors.TextEdit emailTextEdit;
        private DevExpress.XtraEditors.ComboBoxEdit sexocomboBoxEdit;
        private DevExpress.XtraEditors.TextEdit celularTextEdit;
        private DevExpress.XtraEditors.TextEdit dddcelularTextEdit;
        private DevExpress.XtraEditors.LabelControl labelControl15;
        private DevExpress.XtraEditors.TextEdit telefoneTextEdit;
        private DevExpress.XtraEditors.TextEdit dddtelefoneTextEdit;
        private DevExpress.XtraEditors.LabelControl labelControl14;
        private DevExpress.XtraEditors.TextEdit UFTextEdit;
        private DevExpress.XtraEditors.TextEdit municipioTextEdit;
        private DevExpress.XtraEditors.LabelControl labelControl11;
        private DevExpress.XtraEditors.ButtonEdit codigoibgeButtonEdit;
        private DevExpress.XtraEditors.LabelControl labelControl10;
        private DevExpress.XtraEditors.LabelControl labelControl9;
        private DevExpress.XtraEditors.LabelControl labelControl8;
        private DevExpress.XtraEditors.LabelControl labelControl7;
        private DevExpress.XtraEditors.LabelControl labelControl6;
        private DevExpress.XtraEditors.TextEdit bairroTextEdit;
        private DevExpress.XtraEditors.TextEdit complementoTextEdit;
        private DevExpress.XtraEditors.TextEdit numeroTextEdit;
        private DevExpress.XtraEditors.TextEdit enderecoTextEdit;
        private DevExpress.XtraEditors.ButtonEdit cepTextEdit;
        private DevExpress.XtraEditors.LabelControl labelControl4;
        private DevExpress.XtraEditors.TextEdit nomecompletoTextEdit;
        private DevExpress.XtraEditors.TextEdit idTextEdit;
        private DevExpress.XtraEditors.LabelControl lblCodigo;
        private DevExpress.XtraTab.XtraTabPage xtraTabPageDocumentos;
        private DevExpress.XtraEditors.LabelControl labelControl74;
        private DevExpress.XtraEditors.LabelControl labelControl73;
        private DevExpress.XtraEditors.LabelControl labelControl72;
        private DevExpress.XtraEditors.LabelControl labelControl71;
        private DevExpress.XtraEditors.LabelControl labelControl70;
        private DevExpress.XtraEditors.LabelControl labelControl69;
        private DevExpress.XtraEditors.LabelControl labelControl68;
        private DevExpress.XtraEditors.LabelControl labelControl67;
        private DevExpress.XtraEditors.LabelControl labelControl66;
        private DevExpress.XtraEditors.LabelControl labelControl65;
        private DevExpress.XtraEditors.LabelControl labelControl64;
        private DevExpress.XtraEditors.LabelControl labelControl63;
        private DevExpress.XtraEditors.LabelControl labelControl62;
        private DevExpress.XtraEditors.LabelControl labelControl61;
        private DevExpress.XtraEditors.LabelControl labelControl59;
        private DevExpress.XtraEditors.LabelControl labelControl58;
        private DevExpress.XtraEditors.LabelControl labelControl57;
        private DevExpress.XtraEditors.LabelControl labelControl56;
        private DevExpress.XtraEditors.LookUpEdit UFReservistaLookUpEdit;
        private DevExpress.XtraEditors.TextEdit rescategoriaTextEdit;
        private DevExpress.XtraEditors.TextEdit reservistaTextEdit;
        private DevExpress.XtraEditors.DateEdit cnhvencimentoDateEdit;
        private DevExpress.XtraEditors.TextEdit cnhcategoriaTextEdit;
        private DevExpress.XtraEditors.TextEdit cnhTextEdit;
        private DevExpress.XtraEditors.TextEdit cpfTextEdit;
        private DevExpress.XtraEditors.TextEdit titulosecaoTextEdit;
        private DevExpress.XtraEditors.TextEdit titulozonaTextEdit;
        private DevExpress.XtraEditors.TextEdit tituloTextEdit;
        private DevExpress.XtraEditors.LookUpEdit UFRGLookUpEdit;
        private DevExpress.XtraEditors.TextEdit rgorgaoTextEdit;
        private DevExpress.XtraEditors.DateEdit rgemissaoDateEdit;
        private DevExpress.XtraEditors.TextEdit rgTextEdit;
        private DevExpress.XtraEditors.DateEdit ctpsemissaoDateEdit;
        private DevExpress.XtraEditors.LookUpEdit UFCTPSLookUpEdit;
        private DevExpress.XtraEditors.TextEdit ctpsserieTextEdit;
        private DevExpress.XtraEditors.TextEdit ctpsTextEdit;
        private System.Windows.Forms.BindingSource FuncionarioDTOBindingSource;
        private System.Windows.Forms.BindingSource MunicipioDTOBindingSource;
        private System.Windows.Forms.BindingSource UFDTOBindingSource;
        private System.Windows.Forms.BindingSource DepartamentoDTOBindingSource;
        private System.Windows.Forms.BindingSource SetorDTOBindingSource;
        private System.Windows.Forms.BindingSource SecaoDTOBindingSource;
        private DevExpress.XtraEditors.LabelControl labelControl13;
        private DevExpress.XtraEditors.PictureEdit fotopictureEdit;
        private DevExpress.XtraTab.XtraTabPage xtraTabPageSalario;
        private DevExpress.XtraGrid.GridControl salarioGridControl;
        private DevExpress.XtraGrid.Views.Grid.GridView gridViewSalario;
        private DevExpress.XtraGrid.Columns.GridColumn colData;
        private DevExpress.XtraGrid.Columns.GridColumn colDissidio;
        private DevExpress.XtraGrid.Columns.GridColumn colDepartamento;
        private DevExpress.XtraGrid.Columns.GridColumn colSetor;
        private DevExpress.XtraGrid.Columns.GridColumn colSecao;
        private DevExpress.XtraGrid.Columns.GridColumn colFuncao;
        private DevExpress.XtraGrid.Columns.GridColumn colHoras;
        private DevExpress.XtraGrid.Columns.GridColumn colSalario;
        private DevExpress.XtraEditors.Repository.RepositoryItemTextEdit repositoryItemTextEdit1;
        private DevExpress.XtraEditors.SimpleButton btnAlterarSalario;
        private DevExpress.XtraEditors.SimpleButton btnExcluirSalario;
        private DevExpress.XtraEditors.SimpleButton btnVisualizarSalario;
        private DevExpress.XtraEditors.SimpleButton btnInserirSalario;
        private System.Windows.Forms.BindingSource SalarioBindingSource;
        private System.Windows.Forms.BindingSource BancoDTOBindingSource;
        private DevExpress.XtraEditors.GroupControl gpcBancoDeposito;
        private DevExpress.XtraEditors.LabelControl labelControl55;
        private DevExpress.XtraEditors.LookUpEdit bancosalarioLookUpEdit;
        private DevExpress.XtraEditors.ComboBoxEdit tipocontacomboBoxEdit;
        private DevExpress.XtraEditors.LabelControl labelControl36;
        private DevExpress.XtraEditors.LabelControl labelControl41;
        private DevExpress.XtraEditors.TextEdit salcontaTextEdit;
        private DevExpress.XtraEditors.LabelControl labelControl40;
        private DevExpress.XtraEditors.TextEdit salcontadv1TextEdit;
        private DevExpress.XtraEditors.TextEdit salagenciadvTextEdit;
        private DevExpress.XtraEditors.TextEdit salcontadv2TextEdit;
        private DevExpress.XtraEditors.TextEdit salagenciaTextEdit;
        private DevExpress.XtraEditors.LabelControl labelControl37;
        private DevExpress.XtraEditors.LabelControl labelControl39;
        private DevExpress.XtraEditors.LabelControl labelControl38;
        private System.Windows.Forms.BindingSource SemanaBindingSource;
        private DevExpress.XtraBars.BarDockControl barDockControlLeft;
        private DevExpress.XtraBars.BarDockControl barDockControlRight;
        private DevExpress.XtraBars.BarDockControl barDockControlBottom;
        private DevExpress.XtraBars.BarDockControl barDockControlTop;
        private DevExpress.XtraBars.BarManager barManager;
        private DevExpress.XtraBars.Bar bar2;
        private DevExpress.XtraBars.BarButtonItem btnSalvar;
        private DevExpress.XtraBars.BarButtonItem btnCancelar;
        private DevExpress.XtraBars.BarButtonItem btnPrimeiro;
        private DevExpress.XtraBars.BarButtonItem btnAnterior;
        private DevExpress.XtraBars.BarButtonItem btnProximo;
        private DevExpress.XtraBars.BarButtonItem btnUltimo;
        private DevExpress.XtraEditors.LabelControl labelControl29;
        private DevExpress.XtraEditors.LabelControl labelControl28;
        private DevExpress.XtraEditors.DateEdit datademissaoDateEdit;
        private DevExpress.XtraEditors.DateEdit dataadmissaoDateEdit;
        private DevExpress.XtraEditors.LabelControl lblSituacao;
    }
}