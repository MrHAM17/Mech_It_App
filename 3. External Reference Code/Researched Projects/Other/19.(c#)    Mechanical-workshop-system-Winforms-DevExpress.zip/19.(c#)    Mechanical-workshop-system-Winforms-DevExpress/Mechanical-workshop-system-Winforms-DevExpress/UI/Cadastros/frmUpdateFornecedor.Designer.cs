﻿namespace MechTech.UI.Cadastros
{
    partial class frmUpdateFornecedor
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmUpdateFornecedor));
            DevExpress.Utils.SerializableAppearanceObject serializableAppearanceObject3 = new DevExpress.Utils.SerializableAppearanceObject();
            DevExpress.Utils.SerializableAppearanceObject serializableAppearanceObject1 = new DevExpress.Utils.SerializableAppearanceObject();
            this.groupControlFornecedores = new DevExpress.XtraEditors.GroupControl();
            this.xtraTabControl = new DevExpress.XtraTab.XtraTabControl();
            this.xtraTabPage1 = new DevExpress.XtraTab.XtraTabPage();
            this.emailTextEdit = new DevExpress.XtraEditors.TextEdit();
            this.FonecedorDTOBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.barManager = new DevExpress.XtraBars.BarManager(this.components);
            this.bar2 = new DevExpress.XtraBars.Bar();
            this.btnSalvar = new DevExpress.XtraBars.BarButtonItem();
            this.btnCancelar = new DevExpress.XtraBars.BarButtonItem();
            this.btnPrimeiro = new DevExpress.XtraBars.BarButtonItem();
            this.btnAnterior = new DevExpress.XtraBars.BarButtonItem();
            this.btnProximo = new DevExpress.XtraBars.BarButtonItem();
            this.btnUltimo = new DevExpress.XtraBars.BarButtonItem();
            this.bar3 = new DevExpress.XtraBars.Bar();
            this.barDockControlTop = new DevExpress.XtraBars.BarDockControl();
            this.barDockControlBottom = new DevExpress.XtraBars.BarDockControl();
            this.barDockControlLeft = new DevExpress.XtraBars.BarDockControl();
            this.barDockControlRight = new DevExpress.XtraBars.BarDockControl();
            this.labelControl3 = new DevExpress.XtraEditors.LabelControl();
            this.SitetextEdit = new DevExpress.XtraEditors.TextEdit();
            this.txtRamoAtividade = new DevExpress.XtraEditors.TextEdit();
            this.labelControl18 = new DevExpress.XtraEditors.LabelControl();
            this.lblSite = new DevExpress.XtraEditors.LabelControl();
            this.codigoibgeButtonEdit = new DevExpress.XtraEditors.ButtonEdit();
            this.groupControl1 = new DevExpress.XtraEditors.GroupControl();
            this.txtRamalContato = new DevExpress.XtraEditors.TextEdit();
            this.txtCelContato = new DevExpress.XtraEditors.TextEdit();
            this.txtTelContato = new DevExpress.XtraEditors.TextEdit();
            this.txtDDDCelContato = new DevExpress.XtraEditors.TextEdit();
            this.txtEmailContato = new DevExpress.XtraEditors.TextEdit();
            this.txtDDDTelContato = new DevExpress.XtraEditors.TextEdit();
            this.txtNomeContato = new DevExpress.XtraEditors.TextEdit();
            this.labelControl23 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl22 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl21 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl20 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl19 = new DevExpress.XtraEditors.LabelControl();
            this.cepTextEdit = new DevExpress.XtraEditors.ButtonEdit();
            this.labelControl17 = new DevExpress.XtraEditors.LabelControl();
            this.registroTextEdit = new DevExpress.XtraEditors.TextEdit();
            this.labelControl13 = new DevExpress.XtraEditors.LabelControl();
            this.cnpjTextEdit = new DevExpress.XtraEditors.TextEdit();
            this.labelControl10 = new DevExpress.XtraEditors.LabelControl();
            this.municipioTextEdit = new DevExpress.XtraEditors.TextEdit();
            this.faxTextEdit = new DevExpress.XtraEditors.TextEdit();
            this.imunicipalTextEdit = new DevExpress.XtraEditors.TextEdit();
            this.telefoneTextEdit = new DevExpress.XtraEditors.TextEdit();
            this.labelControl16 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl15 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl14 = new DevExpress.XtraEditors.LabelControl();
            this.iestadualTextEdit = new DevExpress.XtraEditors.TextEdit();
            this.labelControl12 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl11 = new DevExpress.XtraEditors.LabelControl();
            this.dddfaxTextEdit = new DevExpress.XtraEditors.TextEdit();
            this.dddtelefoneTextEdit = new DevExpress.XtraEditors.TextEdit();
            this.UFTextEdit = new DevExpress.XtraEditors.TextEdit();
            this.labelControl9 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl8 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl7 = new DevExpress.XtraEditors.LabelControl();
            this.bairroTextEdit = new DevExpress.XtraEditors.TextEdit();
            this.labelControl6 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl5 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl4 = new DevExpress.XtraEditors.LabelControl();
            this.complementoTextEdit = new DevExpress.XtraEditors.TextEdit();
            this.numeroTextEdit = new DevExpress.XtraEditors.TextEdit();
            this.enderecoTextEdit = new DevExpress.XtraEditors.TextEdit();
            this.nomefantasiaTextEdit = new DevExpress.XtraEditors.TextEdit();
            this.razaosocialTextEdit = new DevExpress.XtraEditors.TextEdit();
            this.idTextEdit = new DevExpress.XtraEditors.TextEdit();
            this.labelControl2 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl1 = new DevExpress.XtraEditors.LabelControl();
            this.lblCodigo = new DevExpress.XtraEditors.LabelControl();
            this.MunicipioDTOBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dxErrorProvider = new DevExpress.XtraEditors.DXErrorProvider.DXErrorProvider(this.components);
            this.toolTipController = new DevExpress.Utils.ToolTipController(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.groupControlFornecedores)).BeginInit();
            this.groupControlFornecedores.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.xtraTabControl)).BeginInit();
            this.xtraTabControl.SuspendLayout();
            this.xtraTabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.emailTextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.FonecedorDTOBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.barManager)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SitetextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtRamoAtividade.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.codigoibgeButtonEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl1)).BeginInit();
            this.groupControl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtRamalContato.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtCelContato.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtTelContato.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtDDDCelContato.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtEmailContato.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtDDDTelContato.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtNomeContato.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cepTextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.registroTextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cnpjTextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.municipioTextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.faxTextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.imunicipalTextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.telefoneTextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.iestadualTextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dddfaxTextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dddtelefoneTextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.UFTextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bairroTextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.complementoTextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numeroTextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.enderecoTextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nomefantasiaTextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.razaosocialTextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.idTextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.MunicipioDTOBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dxErrorProvider)).BeginInit();
            this.SuspendLayout();
            // 
            // groupControlFornecedores
            // 
            this.groupControlFornecedores.AppearanceCaption.Options.UseTextOptions = true;
            this.groupControlFornecedores.AppearanceCaption.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.groupControlFornecedores.CaptionLocation = DevExpress.Utils.Locations.Left;
            this.groupControlFornecedores.Controls.Add(this.xtraTabControl);
            this.groupControlFornecedores.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupControlFornecedores.Location = new System.Drawing.Point(0, 24);
            this.groupControlFornecedores.Name = "groupControlFornecedores";
            this.groupControlFornecedores.Size = new System.Drawing.Size(861, 527);
            this.groupControlFornecedores.TabIndex = 0;
            this.groupControlFornecedores.Text = "Fornecedores";
            // 
            // xtraTabControl
            // 
            this.xtraTabControl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.xtraTabControl.Location = new System.Drawing.Point(21, 2);
            this.xtraTabControl.Name = "xtraTabControl";
            this.xtraTabControl.SelectedTabPage = this.xtraTabPage1;
            this.xtraTabControl.Size = new System.Drawing.Size(838, 523);
            this.xtraTabControl.TabIndex = 0;
            this.xtraTabControl.TabPages.AddRange(new DevExpress.XtraTab.XtraTabPage[] {
            this.xtraTabPage1});
            // 
            // xtraTabPage1
            // 
            this.xtraTabPage1.Controls.Add(this.emailTextEdit);
            this.xtraTabPage1.Controls.Add(this.labelControl3);
            this.xtraTabPage1.Controls.Add(this.SitetextEdit);
            this.xtraTabPage1.Controls.Add(this.txtRamoAtividade);
            this.xtraTabPage1.Controls.Add(this.labelControl18);
            this.xtraTabPage1.Controls.Add(this.lblSite);
            this.xtraTabPage1.Controls.Add(this.codigoibgeButtonEdit);
            this.xtraTabPage1.Controls.Add(this.groupControl1);
            this.xtraTabPage1.Controls.Add(this.cepTextEdit);
            this.xtraTabPage1.Controls.Add(this.labelControl17);
            this.xtraTabPage1.Controls.Add(this.registroTextEdit);
            this.xtraTabPage1.Controls.Add(this.labelControl13);
            this.xtraTabPage1.Controls.Add(this.cnpjTextEdit);
            this.xtraTabPage1.Controls.Add(this.labelControl10);
            this.xtraTabPage1.Controls.Add(this.municipioTextEdit);
            this.xtraTabPage1.Controls.Add(this.faxTextEdit);
            this.xtraTabPage1.Controls.Add(this.imunicipalTextEdit);
            this.xtraTabPage1.Controls.Add(this.telefoneTextEdit);
            this.xtraTabPage1.Controls.Add(this.labelControl16);
            this.xtraTabPage1.Controls.Add(this.labelControl15);
            this.xtraTabPage1.Controls.Add(this.labelControl14);
            this.xtraTabPage1.Controls.Add(this.iestadualTextEdit);
            this.xtraTabPage1.Controls.Add(this.labelControl12);
            this.xtraTabPage1.Controls.Add(this.labelControl11);
            this.xtraTabPage1.Controls.Add(this.dddfaxTextEdit);
            this.xtraTabPage1.Controls.Add(this.dddtelefoneTextEdit);
            this.xtraTabPage1.Controls.Add(this.UFTextEdit);
            this.xtraTabPage1.Controls.Add(this.labelControl9);
            this.xtraTabPage1.Controls.Add(this.labelControl8);
            this.xtraTabPage1.Controls.Add(this.labelControl7);
            this.xtraTabPage1.Controls.Add(this.bairroTextEdit);
            this.xtraTabPage1.Controls.Add(this.labelControl6);
            this.xtraTabPage1.Controls.Add(this.labelControl5);
            this.xtraTabPage1.Controls.Add(this.labelControl4);
            this.xtraTabPage1.Controls.Add(this.complementoTextEdit);
            this.xtraTabPage1.Controls.Add(this.numeroTextEdit);
            this.xtraTabPage1.Controls.Add(this.enderecoTextEdit);
            this.xtraTabPage1.Controls.Add(this.nomefantasiaTextEdit);
            this.xtraTabPage1.Controls.Add(this.razaosocialTextEdit);
            this.xtraTabPage1.Controls.Add(this.idTextEdit);
            this.xtraTabPage1.Controls.Add(this.labelControl2);
            this.xtraTabPage1.Controls.Add(this.labelControl1);
            this.xtraTabPage1.Controls.Add(this.lblCodigo);
            this.xtraTabPage1.Name = "xtraTabPage1";
            this.xtraTabPage1.Size = new System.Drawing.Size(832, 495);
            this.xtraTabPage1.Text = "Básico";
            // 
            // emailTextEdit
            // 
            this.emailTextEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.FonecedorDTOBindingSource, "Email", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.emailTextEdit.EnterMoveNextControl = true;
            this.emailTextEdit.Location = new System.Drawing.Point(48, 204);
            this.emailTextEdit.MenuManager = this.barManager;
            this.emailTextEdit.Name = "emailTextEdit";
            this.emailTextEdit.Size = new System.Drawing.Size(441, 20);
            this.emailTextEdit.TabIndex = 22;
            // 
            // FonecedorDTOBindingSource
            // 
            this.FonecedorDTOBindingSource.DataSource = typeof(MechTech.Entities.FornecedorDTO);
            // 
            // barManager
            // 
            this.barManager.Bars.AddRange(new DevExpress.XtraBars.Bar[] {
            this.bar2,
            this.bar3});
            this.barManager.DockControls.Add(this.barDockControlTop);
            this.barManager.DockControls.Add(this.barDockControlBottom);
            this.barManager.DockControls.Add(this.barDockControlLeft);
            this.barManager.DockControls.Add(this.barDockControlRight);
            this.barManager.Form = this;
            this.barManager.Items.AddRange(new DevExpress.XtraBars.BarItem[] {
            this.btnSalvar,
            this.btnCancelar,
            this.btnPrimeiro,
            this.btnAnterior,
            this.btnProximo,
            this.btnUltimo});
            this.barManager.MainMenu = this.bar2;
            this.barManager.MaxItemId = 6;
            this.barManager.StatusBar = this.bar3;
            // 
            // bar2
            // 
            this.bar2.BarName = "Main menu";
            this.bar2.DockCol = 0;
            this.bar2.DockRow = 0;
            this.bar2.DockStyle = DevExpress.XtraBars.BarDockStyle.Top;
            this.bar2.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(DevExpress.XtraBars.BarLinkUserDefines.PaintStyle, this.btnSalvar, DevExpress.XtraBars.BarItemPaintStyle.CaptionGlyph),
            new DevExpress.XtraBars.LinkPersistInfo(DevExpress.XtraBars.BarLinkUserDefines.PaintStyle, this.btnCancelar, DevExpress.XtraBars.BarItemPaintStyle.CaptionGlyph),
            new DevExpress.XtraBars.LinkPersistInfo(DevExpress.XtraBars.BarLinkUserDefines.PaintStyle, this.btnPrimeiro, DevExpress.XtraBars.BarItemPaintStyle.CaptionGlyph),
            new DevExpress.XtraBars.LinkPersistInfo(DevExpress.XtraBars.BarLinkUserDefines.PaintStyle, this.btnAnterior, DevExpress.XtraBars.BarItemPaintStyle.CaptionGlyph),
            new DevExpress.XtraBars.LinkPersistInfo(DevExpress.XtraBars.BarLinkUserDefines.PaintStyle, this.btnProximo, DevExpress.XtraBars.BarItemPaintStyle.CaptionGlyph),
            new DevExpress.XtraBars.LinkPersistInfo(DevExpress.XtraBars.BarLinkUserDefines.PaintStyle, this.btnUltimo, DevExpress.XtraBars.BarItemPaintStyle.CaptionGlyph)});
            this.bar2.OptionsBar.AllowQuickCustomization = false;
            this.bar2.OptionsBar.DrawBorder = false;
            this.bar2.OptionsBar.UseWholeRow = true;
            this.bar2.Text = "Menu principal";
            // 
            // btnSalvar
            // 
            this.btnSalvar.Caption = "&Salvar";
            this.btnSalvar.Glyph = ((System.Drawing.Image)(resources.GetObject("btnSalvar.Glyph")));
            this.btnSalvar.Id = 0;
            this.btnSalvar.LargeGlyph = ((System.Drawing.Image)(resources.GetObject("btnSalvar.LargeGlyph")));
            this.btnSalvar.Name = "btnSalvar";
            this.btnSalvar.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnSalvar_ItemClick);
            // 
            // btnCancelar
            // 
            this.btnCancelar.Caption = "&Cancelar";
            this.btnCancelar.Glyph = ((System.Drawing.Image)(resources.GetObject("btnCancelar.Glyph")));
            this.btnCancelar.Id = 1;
            this.btnCancelar.LargeGlyph = ((System.Drawing.Image)(resources.GetObject("btnCancelar.LargeGlyph")));
            this.btnCancelar.Name = "btnCancelar";
            this.btnCancelar.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnCancelar_ItemClick);
            // 
            // btnPrimeiro
            // 
            this.btnPrimeiro.Caption = "&Primeiro";
            this.btnPrimeiro.Glyph = ((System.Drawing.Image)(resources.GetObject("btnPrimeiro.Glyph")));
            this.btnPrimeiro.Id = 2;
            this.btnPrimeiro.LargeGlyph = ((System.Drawing.Image)(resources.GetObject("btnPrimeiro.LargeGlyph")));
            this.btnPrimeiro.Name = "btnPrimeiro";
            this.btnPrimeiro.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnPrimeiro_ItemClick);
            // 
            // btnAnterior
            // 
            this.btnAnterior.Caption = "&Anterior";
            this.btnAnterior.Glyph = ((System.Drawing.Image)(resources.GetObject("btnAnterior.Glyph")));
            this.btnAnterior.Id = 3;
            this.btnAnterior.LargeGlyph = ((System.Drawing.Image)(resources.GetObject("btnAnterior.LargeGlyph")));
            this.btnAnterior.Name = "btnAnterior";
            this.btnAnterior.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnAnterior_ItemClick);
            // 
            // btnProximo
            // 
            this.btnProximo.Caption = "P&róximo";
            this.btnProximo.Glyph = ((System.Drawing.Image)(resources.GetObject("btnProximo.Glyph")));
            this.btnProximo.Id = 4;
            this.btnProximo.LargeGlyph = ((System.Drawing.Image)(resources.GetObject("btnProximo.LargeGlyph")));
            this.btnProximo.Name = "btnProximo";
            this.btnProximo.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnProximo_ItemClick);
            // 
            // btnUltimo
            // 
            this.btnUltimo.Caption = "&Último";
            this.btnUltimo.Glyph = ((System.Drawing.Image)(resources.GetObject("btnUltimo.Glyph")));
            this.btnUltimo.Id = 5;
            this.btnUltimo.LargeGlyph = ((System.Drawing.Image)(resources.GetObject("btnUltimo.LargeGlyph")));
            this.btnUltimo.Name = "btnUltimo";
            this.btnUltimo.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnUltimo_ItemClick);
            // 
            // bar3
            // 
            this.bar3.BarName = "Status bar";
            this.bar3.CanDockStyle = DevExpress.XtraBars.BarCanDockStyle.Bottom;
            this.bar3.DockCol = 0;
            this.bar3.DockRow = 0;
            this.bar3.DockStyle = DevExpress.XtraBars.BarDockStyle.Bottom;
            this.bar3.OptionsBar.AllowQuickCustomization = false;
            this.bar3.OptionsBar.DrawDragBorder = false;
            this.bar3.OptionsBar.UseWholeRow = true;
            this.bar3.Text = "Status bar";
            // 
            // barDockControlTop
            // 
            this.barDockControlTop.CausesValidation = false;
            this.barDockControlTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.barDockControlTop.Location = new System.Drawing.Point(0, 0);
            this.barDockControlTop.Size = new System.Drawing.Size(861, 24);
            // 
            // barDockControlBottom
            // 
            this.barDockControlBottom.CausesValidation = false;
            this.barDockControlBottom.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.barDockControlBottom.Location = new System.Drawing.Point(0, 551);
            this.barDockControlBottom.Size = new System.Drawing.Size(861, 23);
            // 
            // barDockControlLeft
            // 
            this.barDockControlLeft.CausesValidation = false;
            this.barDockControlLeft.Dock = System.Windows.Forms.DockStyle.Left;
            this.barDockControlLeft.Location = new System.Drawing.Point(0, 24);
            this.barDockControlLeft.Size = new System.Drawing.Size(0, 527);
            // 
            // barDockControlRight
            // 
            this.barDockControlRight.CausesValidation = false;
            this.barDockControlRight.Dock = System.Windows.Forms.DockStyle.Right;
            this.barDockControlRight.Location = new System.Drawing.Point(861, 24);
            this.barDockControlRight.Size = new System.Drawing.Size(0, 527);
            // 
            // labelControl3
            // 
            this.labelControl3.Location = new System.Drawing.Point(12, 207);
            this.labelControl3.Name = "labelControl3";
            this.labelControl3.Size = new System.Drawing.Size(28, 13);
            this.labelControl3.TabIndex = 92;
            this.labelControl3.Text = "Email:";
            // 
            // SitetextEdit
            // 
            this.SitetextEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.FonecedorDTOBindingSource, "Url", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.SitetextEdit.EnterMoveNextControl = true;
            this.SitetextEdit.Location = new System.Drawing.Point(579, 178);
            this.SitetextEdit.MenuManager = this.barManager;
            this.SitetextEdit.Name = "SitetextEdit";
            this.SitetextEdit.Size = new System.Drawing.Size(246, 20);
            this.SitetextEdit.TabIndex = 21;
            // 
            // txtRamoAtividade
            // 
            this.txtRamoAtividade.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.FonecedorDTOBindingSource, "RamoAtividade", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.txtRamoAtividade.EnterMoveNextControl = true;
            this.txtRamoAtividade.Location = new System.Drawing.Point(579, 150);
            this.txtRamoAtividade.Name = "txtRamoAtividade";
            this.txtRamoAtividade.Properties.MaxLength = 50;
            this.txtRamoAtividade.Size = new System.Drawing.Size(246, 20);
            this.txtRamoAtividade.TabIndex = 19;
            // 
            // labelControl18
            // 
            this.labelControl18.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl18.Location = new System.Drawing.Point(495, 153);
            this.labelControl18.Name = "labelControl18";
            this.labelControl18.Size = new System.Drawing.Size(79, 13);
            this.labelControl18.TabIndex = 89;
            this.labelControl18.Text = "Ramo Atividade:";
            // 
            // lblSite
            // 
            this.lblSite.Location = new System.Drawing.Point(495, 185);
            this.lblSite.Name = "lblSite";
            this.lblSite.Size = new System.Drawing.Size(22, 13);
            this.lblSite.TabIndex = 91;
            this.lblSite.Text = "Site:";
            // 
            // codigoibgeButtonEdit
            // 
            this.codigoibgeButtonEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.FonecedorDTOBindingSource, "Municipio.Codigoibge", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.codigoibgeButtonEdit.EnterMoveNextControl = true;
            this.codigoibgeButtonEdit.Location = new System.Drawing.Point(385, 38);
            this.codigoibgeButtonEdit.Name = "codigoibgeButtonEdit";
            this.codigoibgeButtonEdit.Properties.Appearance.Options.UseTextOptions = true;
            this.codigoibgeButtonEdit.Properties.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.codigoibgeButtonEdit.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Glyph, "", -1, true, true, false, DevExpress.XtraEditors.ImageLocation.MiddleCenter, ((System.Drawing.Image)(resources.GetObject("codigoibgeButtonEdit.Properties.Buttons"))), new DevExpress.Utils.KeyShortcut(System.Windows.Forms.Keys.None), serializableAppearanceObject3, "", null, null, true)});
            this.codigoibgeButtonEdit.Properties.Mask.EditMask = "d";
            this.codigoibgeButtonEdit.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.codigoibgeButtonEdit.Size = new System.Drawing.Size(104, 22);
            this.codigoibgeButtonEdit.TabIndex = 6;
            this.codigoibgeButtonEdit.ButtonClick += new DevExpress.XtraEditors.Controls.ButtonPressedEventHandler(this.codigoibgeButtonEdit_ButtonClick);
            this.codigoibgeButtonEdit.EditValueChanged += new System.EventHandler(this.codigoibgeButtonEdit_EditValueChanged);
            this.codigoibgeButtonEdit.Validated += new System.EventHandler(this.codigoibgeButtonEdit_Validated);
            // 
            // groupControl1
            // 
            this.groupControl1.Controls.Add(this.txtRamalContato);
            this.groupControl1.Controls.Add(this.txtCelContato);
            this.groupControl1.Controls.Add(this.txtTelContato);
            this.groupControl1.Controls.Add(this.txtDDDCelContato);
            this.groupControl1.Controls.Add(this.txtEmailContato);
            this.groupControl1.Controls.Add(this.txtDDDTelContato);
            this.groupControl1.Controls.Add(this.txtNomeContato);
            this.groupControl1.Controls.Add(this.labelControl23);
            this.groupControl1.Controls.Add(this.labelControl22);
            this.groupControl1.Controls.Add(this.labelControl21);
            this.groupControl1.Controls.Add(this.labelControl20);
            this.groupControl1.Controls.Add(this.labelControl19);
            this.groupControl1.Location = new System.Drawing.Point(10, 240);
            this.groupControl1.Name = "groupControl1";
            this.groupControl1.Size = new System.Drawing.Size(700, 87);
            this.groupControl1.TabIndex = 23;
            this.groupControl1.Text = "Contatos";
            // 
            // txtRamalContato
            // 
            this.txtRamalContato.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.FonecedorDTOBindingSource, "RamalContato", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.txtRamalContato.EnterMoveNextControl = true;
            this.txtRamalContato.Location = new System.Drawing.Point(413, 52);
            this.txtRamalContato.Name = "txtRamalContato";
            this.txtRamalContato.Properties.MaxLength = 9;
            this.txtRamalContato.Size = new System.Drawing.Size(90, 20);
            this.txtRamalContato.TabIndex = 30;
            // 
            // txtCelContato
            // 
            this.txtCelContato.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.FonecedorDTOBindingSource, "CelContato", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.txtCelContato.EnterMoveNextControl = true;
            this.txtCelContato.Location = new System.Drawing.Point(278, 52);
            this.txtCelContato.Name = "txtCelContato";
            this.txtCelContato.Properties.Mask.EditMask = "(999)0000-0000";
            this.txtCelContato.Properties.MaxLength = 9;
            this.txtCelContato.Size = new System.Drawing.Size(90, 20);
            this.txtCelContato.TabIndex = 29;
            // 
            // txtTelContato
            // 
            this.txtTelContato.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.FonecedorDTOBindingSource, "TelContato", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.txtTelContato.EnterMoveNextControl = true;
            this.txtTelContato.Location = new System.Drawing.Point(98, 52);
            this.txtTelContato.Name = "txtTelContato";
            this.txtTelContato.Properties.Mask.EditMask = "(999)0000-0000";
            this.txtTelContato.Properties.MaxLength = 9;
            this.txtTelContato.Size = new System.Drawing.Size(90, 20);
            this.txtTelContato.TabIndex = 27;
            // 
            // txtDDDCelContato
            // 
            this.txtDDDCelContato.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.FonecedorDTOBindingSource, "DDDCelContato", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.txtDDDCelContato.EnterMoveNextControl = true;
            this.txtDDDCelContato.Location = new System.Drawing.Point(237, 52);
            this.txtDDDCelContato.Name = "txtDDDCelContato";
            this.txtDDDCelContato.Properties.Appearance.Options.UseTextOptions = true;
            this.txtDDDCelContato.Properties.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.txtDDDCelContato.Properties.MaxLength = 2;
            this.txtDDDCelContato.Size = new System.Drawing.Size(38, 20);
            this.txtDDDCelContato.TabIndex = 28;
            this.txtDDDCelContato.ToolTip = "DDD do telefone principal";
            // 
            // txtEmailContato
            // 
            this.txtEmailContato.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.FonecedorDTOBindingSource, "EmailContato", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.txtEmailContato.EnterMoveNextControl = true;
            this.txtEmailContato.Location = new System.Drawing.Point(381, 24);
            this.txtEmailContato.Name = "txtEmailContato";
            this.txtEmailContato.Properties.MaxLength = 50;
            this.txtEmailContato.Size = new System.Drawing.Size(314, 20);
            this.txtEmailContato.TabIndex = 25;
            this.txtEmailContato.ToolTip = "Número da Inscrição Municipal";
            // 
            // txtDDDTelContato
            // 
            this.txtDDDTelContato.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.FonecedorDTOBindingSource, "DDDTelContato", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.txtDDDTelContato.EnterMoveNextControl = true;
            this.txtDDDTelContato.Location = new System.Drawing.Point(57, 52);
            this.txtDDDTelContato.Name = "txtDDDTelContato";
            this.txtDDDTelContato.Properties.Appearance.Options.UseTextOptions = true;
            this.txtDDDTelContato.Properties.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.txtDDDTelContato.Properties.MaxLength = 2;
            this.txtDDDTelContato.Size = new System.Drawing.Size(38, 20);
            this.txtDDDTelContato.TabIndex = 26;
            this.txtDDDTelContato.ToolTip = "DDD do telefone principal";
            // 
            // txtNomeContato
            // 
            this.txtNomeContato.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.FonecedorDTOBindingSource, "NomeContato", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.txtNomeContato.EnterMoveNextControl = true;
            this.txtNomeContato.Location = new System.Drawing.Point(57, 24);
            this.txtNomeContato.Name = "txtNomeContato";
            this.txtNomeContato.Properties.MaxLength = 50;
            this.txtNomeContato.Size = new System.Drawing.Size(286, 20);
            this.txtNomeContato.TabIndex = 24;
            this.txtNomeContato.ToolTip = "Número da Inscrição Municipal";
            // 
            // labelControl23
            // 
            this.labelControl23.Location = new System.Drawing.Point(374, 55);
            this.labelControl23.Name = "labelControl23";
            this.labelControl23.Size = new System.Drawing.Size(33, 13);
            this.labelControl23.TabIndex = 94;
            this.labelControl23.Text = "Ramal:";
            // 
            // labelControl22
            // 
            this.labelControl22.Location = new System.Drawing.Point(194, 55);
            this.labelControl22.Name = "labelControl22";
            this.labelControl22.Size = new System.Drawing.Size(37, 13);
            this.labelControl22.TabIndex = 94;
            this.labelControl22.Text = "Celular:";
            // 
            // labelControl21
            // 
            this.labelControl21.Location = new System.Drawing.Point(5, 55);
            this.labelControl21.Name = "labelControl21";
            this.labelControl21.Size = new System.Drawing.Size(46, 13);
            this.labelControl21.TabIndex = 94;
            this.labelControl21.Text = "Telefone:";
            // 
            // labelControl20
            // 
            this.labelControl20.Location = new System.Drawing.Point(347, 27);
            this.labelControl20.Name = "labelControl20";
            this.labelControl20.Size = new System.Drawing.Size(28, 13);
            this.labelControl20.TabIndex = 94;
            this.labelControl20.Text = "Email:";
            // 
            // labelControl19
            // 
            this.labelControl19.Location = new System.Drawing.Point(5, 27);
            this.labelControl19.Name = "labelControl19";
            this.labelControl19.Size = new System.Drawing.Size(31, 13);
            this.labelControl19.TabIndex = 93;
            this.labelControl19.Text = "Nome:";
            // 
            // cepTextEdit
            // 
            this.cepTextEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.FonecedorDTOBindingSource, "Cep", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.cepTextEdit.EnterMoveNextControl = true;
            this.cepTextEdit.Location = new System.Drawing.Point(89, 37);
            this.cepTextEdit.Name = "cepTextEdit";
            this.cepTextEdit.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Glyph, "", -1, true, true, false, DevExpress.XtraEditors.ImageLocation.MiddleCenter, ((System.Drawing.Image)(resources.GetObject("cepTextEdit.Properties.Buttons"))), new DevExpress.Utils.KeyShortcut(System.Windows.Forms.Keys.None), serializableAppearanceObject1, "", null, null, false)});
            this.cepTextEdit.Properties.Mask.EditMask = "99.999-999";
            this.cepTextEdit.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Simple;
            this.cepTextEdit.Properties.Mask.SaveLiteral = false;
            this.cepTextEdit.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.cepTextEdit.Properties.MaxLength = 8;
            this.cepTextEdit.Size = new System.Drawing.Size(131, 22);
            this.cepTextEdit.TabIndex = 4;
            this.cepTextEdit.ToolTip = "Código de endereçamento postal fornecido pelos CORREIOS";
            this.cepTextEdit.ButtonClick += new DevExpress.XtraEditors.Controls.ButtonPressedEventHandler(this.cepTextEdit_ButtonClick);
            this.cepTextEdit.Validated += new System.EventHandler(this.cepTextEdit_Validated);
            // 
            // labelControl17
            // 
            this.labelControl17.Location = new System.Drawing.Point(10, 181);
            this.labelControl17.Name = "labelControl17";
            this.labelControl17.Size = new System.Drawing.Size(251, 13);
            this.labelControl17.TabIndex = 88;
            this.labelControl17.Text = "Número do registro no orgão regulador competente:";
            this.labelControl17.ToolTip = "Número do registro no orgão regulador";
            // 
            // registroTextEdit
            // 
            this.registroTextEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.FonecedorDTOBindingSource, "Registro", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.registroTextEdit.EnterMoveNextControl = true;
            this.registroTextEdit.Location = new System.Drawing.Point(267, 178);
            this.registroTextEdit.Name = "registroTextEdit";
            this.registroTextEdit.Properties.MaxLength = 10;
            this.registroTextEdit.Size = new System.Drawing.Size(222, 20);
            this.registroTextEdit.TabIndex = 20;
            this.registroTextEdit.ToolTip = "Número da Inscrição Municipal";
            // 
            // labelControl13
            // 
            this.labelControl13.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl13.Location = new System.Drawing.Point(498, 125);
            this.labelControl13.Name = "labelControl13";
            this.labelControl13.Size = new System.Drawing.Size(29, 13);
            this.labelControl13.TabIndex = 84;
            this.labelControl13.Text = "CNPJ:";
            // 
            // cnpjTextEdit
            // 
            this.cnpjTextEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.FonecedorDTOBindingSource, "Cnpj", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.cnpjTextEdit.EnterMoveNextControl = true;
            this.cnpjTextEdit.Location = new System.Drawing.Point(579, 122);
            this.cnpjTextEdit.Name = "cnpjTextEdit";
            this.cnpjTextEdit.Properties.Mask.EditMask = "99.999.999/9999-99";
            this.cnpjTextEdit.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Simple;
            this.cnpjTextEdit.Properties.Mask.SaveLiteral = false;
            this.cnpjTextEdit.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.cnpjTextEdit.Properties.MaxLength = 14;
            this.cnpjTextEdit.Size = new System.Drawing.Size(131, 20);
            this.cnpjTextEdit.TabIndex = 16;
            // 
            // labelControl10
            // 
            this.labelControl10.Location = new System.Drawing.Point(226, 41);
            this.labelControl10.Name = "labelControl10";
            this.labelControl10.Size = new System.Drawing.Size(17, 13);
            this.labelControl10.TabIndex = 81;
            this.labelControl10.Text = "UF:";
            this.labelControl10.ToolTip = "Unidade Federativa (Estados)";
            // 
            // municipioTextEdit
            // 
            this.municipioTextEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.FonecedorDTOBindingSource, "Municipio.Nome", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.municipioTextEdit.EnterMoveNextControl = true;
            this.municipioTextEdit.Location = new System.Drawing.Point(579, 39);
            this.municipioTextEdit.Name = "municipioTextEdit";
            this.municipioTextEdit.Properties.ReadOnly = true;
            this.municipioTextEdit.Size = new System.Drawing.Size(131, 20);
            this.municipioTextEdit.TabIndex = 7;
            this.municipioTextEdit.TabStop = false;
            // 
            // faxTextEdit
            // 
            this.faxTextEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.FonecedorDTOBindingSource, "Fax", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.faxTextEdit.EnterMoveNextControl = true;
            this.faxTextEdit.Location = new System.Drawing.Point(325, 122);
            this.faxTextEdit.Name = "faxTextEdit";
            this.faxTextEdit.Properties.MaxLength = 9;
            this.faxTextEdit.Size = new System.Drawing.Size(164, 20);
            this.faxTextEdit.TabIndex = 15;
            // 
            // imunicipalTextEdit
            // 
            this.imunicipalTextEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.FonecedorDTOBindingSource, "Imunicipal", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.imunicipalTextEdit.EnterMoveNextControl = true;
            this.imunicipalTextEdit.Location = new System.Drawing.Point(284, 150);
            this.imunicipalTextEdit.Name = "imunicipalTextEdit";
            this.imunicipalTextEdit.Properties.MaxLength = 10;
            this.imunicipalTextEdit.Size = new System.Drawing.Size(205, 20);
            this.imunicipalTextEdit.TabIndex = 18;
            this.imunicipalTextEdit.ToolTip = "Número da Inscrição Municipal";
            // 
            // telefoneTextEdit
            // 
            this.telefoneTextEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.FonecedorDTOBindingSource, "Telefone", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.telefoneTextEdit.EnterMoveNextControl = true;
            this.telefoneTextEdit.Location = new System.Drawing.Point(130, 122);
            this.telefoneTextEdit.Name = "telefoneTextEdit";
            this.telefoneTextEdit.Properties.Mask.EditMask = "(999)0000-0000";
            this.telefoneTextEdit.Properties.MaxLength = 9;
            this.telefoneTextEdit.Size = new System.Drawing.Size(90, 20);
            this.telefoneTextEdit.TabIndex = 13;
            // 
            // labelControl16
            // 
            this.labelControl16.Location = new System.Drawing.Point(498, 41);
            this.labelControl16.Name = "labelControl16";
            this.labelControl16.Size = new System.Drawing.Size(47, 13);
            this.labelControl16.TabIndex = 87;
            this.labelControl16.Text = "Município:";
            // 
            // labelControl15
            // 
            this.labelControl15.Location = new System.Drawing.Point(226, 153);
            this.labelControl15.Name = "labelControl15";
            this.labelControl15.Size = new System.Drawing.Size(55, 13);
            this.labelControl15.TabIndex = 86;
            this.labelControl15.Text = "Insc. Mun.:";
            this.labelControl15.ToolTip = "Inscrição Municipal";
            // 
            // labelControl14
            // 
            this.labelControl14.Location = new System.Drawing.Point(10, 153);
            this.labelControl14.Name = "labelControl14";
            this.labelControl14.Size = new System.Drawing.Size(72, 13);
            this.labelControl14.TabIndex = 85;
            this.labelControl14.Text = "Insc. Estadual:";
            this.labelControl14.ToolTip = "Inscrição Estadual";
            // 
            // iestadualTextEdit
            // 
            this.iestadualTextEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.FonecedorDTOBindingSource, "Iestadual", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.iestadualTextEdit.EnterMoveNextControl = true;
            this.iestadualTextEdit.Location = new System.Drawing.Point(88, 150);
            this.iestadualTextEdit.Name = "iestadualTextEdit";
            this.iestadualTextEdit.Properties.MaxLength = 20;
            this.iestadualTextEdit.Size = new System.Drawing.Size(131, 20);
            this.iestadualTextEdit.TabIndex = 17;
            this.iestadualTextEdit.ToolTip = "Número da Inscrição Estadual";
            // 
            // labelControl12
            // 
            this.labelControl12.Location = new System.Drawing.Point(226, 125);
            this.labelControl12.Name = "labelControl12";
            this.labelControl12.Size = new System.Drawing.Size(22, 13);
            this.labelControl12.TabIndex = 83;
            this.labelControl12.Text = "Fax:";
            // 
            // labelControl11
            // 
            this.labelControl11.Location = new System.Drawing.Point(10, 125);
            this.labelControl11.Name = "labelControl11";
            this.labelControl11.Size = new System.Drawing.Size(46, 13);
            this.labelControl11.TabIndex = 82;
            this.labelControl11.Text = "Telefone:";
            // 
            // dddfaxTextEdit
            // 
            this.dddfaxTextEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.FonecedorDTOBindingSource, "Dddfax", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.dddfaxTextEdit.EnterMoveNextControl = true;
            this.dddfaxTextEdit.Location = new System.Drawing.Point(284, 122);
            this.dddfaxTextEdit.Name = "dddfaxTextEdit";
            this.dddfaxTextEdit.Properties.Appearance.Options.UseTextOptions = true;
            this.dddfaxTextEdit.Properties.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.dddfaxTextEdit.Properties.MaxLength = 2;
            this.dddfaxTextEdit.Size = new System.Drawing.Size(35, 20);
            this.dddfaxTextEdit.TabIndex = 14;
            this.dddfaxTextEdit.ToolTip = "DDD do FAX";
            // 
            // dddtelefoneTextEdit
            // 
            this.dddtelefoneTextEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.FonecedorDTOBindingSource, "Dddtelefone", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.dddtelefoneTextEdit.EnterMoveNextControl = true;
            this.dddtelefoneTextEdit.Location = new System.Drawing.Point(89, 122);
            this.dddtelefoneTextEdit.Name = "dddtelefoneTextEdit";
            this.dddtelefoneTextEdit.Properties.Appearance.Options.UseTextOptions = true;
            this.dddtelefoneTextEdit.Properties.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.dddtelefoneTextEdit.Properties.MaxLength = 2;
            this.dddtelefoneTextEdit.Size = new System.Drawing.Size(38, 20);
            this.dddtelefoneTextEdit.TabIndex = 12;
            this.dddtelefoneTextEdit.ToolTip = "DDD do telefone principal";
            // 
            // UFTextEdit
            // 
            this.UFTextEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.FonecedorDTOBindingSource, "Municipio.UF.Codigo", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.UFTextEdit.EnterMoveNextControl = true;
            this.UFTextEdit.Location = new System.Drawing.Point(284, 37);
            this.UFTextEdit.Name = "UFTextEdit";
            this.UFTextEdit.Size = new System.Drawing.Size(35, 20);
            this.UFTextEdit.TabIndex = 5;
            // 
            // labelControl9
            // 
            this.labelControl9.Location = new System.Drawing.Point(325, 41);
            this.labelControl9.Name = "labelControl9";
            this.labelControl9.Size = new System.Drawing.Size(54, 13);
            this.labelControl9.TabIndex = 78;
            this.labelControl9.Text = "Cód. Mun.:";
            this.labelControl9.ToolTip = "Código do Município";
            // 
            // labelControl8
            // 
            this.labelControl8.Location = new System.Drawing.Point(10, 41);
            this.labelControl8.Name = "labelControl8";
            this.labelControl8.Size = new System.Drawing.Size(23, 13);
            this.labelControl8.TabIndex = 76;
            this.labelControl8.Text = "Cep:";
            // 
            // labelControl7
            // 
            this.labelControl7.Location = new System.Drawing.Point(10, 97);
            this.labelControl7.Name = "labelControl7";
            this.labelControl7.Size = new System.Drawing.Size(32, 13);
            this.labelControl7.TabIndex = 74;
            this.labelControl7.Text = "Bairro:";
            // 
            // bairroTextEdit
            // 
            this.bairroTextEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.FonecedorDTOBindingSource, "Bairro", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.bairroTextEdit.EnterMoveNextControl = true;
            this.bairroTextEdit.Location = new System.Drawing.Point(89, 94);
            this.bairroTextEdit.Name = "bairroTextEdit";
            this.bairroTextEdit.Properties.MaxLength = 20;
            this.bairroTextEdit.Size = new System.Drawing.Size(400, 20);
            this.bairroTextEdit.TabIndex = 10;
            this.bairroTextEdit.ToolTip = "Bairro";
            // 
            // labelControl6
            // 
            this.labelControl6.Location = new System.Drawing.Point(498, 97);
            this.labelControl6.Name = "labelControl6";
            this.labelControl6.Size = new System.Drawing.Size(69, 13);
            this.labelControl6.TabIndex = 69;
            this.labelControl6.Text = "Complemento:";
            // 
            // labelControl5
            // 
            this.labelControl5.Location = new System.Drawing.Point(498, 69);
            this.labelControl5.Name = "labelControl5";
            this.labelControl5.Size = new System.Drawing.Size(16, 13);
            this.labelControl5.TabIndex = 68;
            this.labelControl5.Text = "Nº:";
            this.labelControl5.ToolTip = "Número";
            // 
            // labelControl4
            // 
            this.labelControl4.Location = new System.Drawing.Point(10, 69);
            this.labelControl4.Name = "labelControl4";
            this.labelControl4.Size = new System.Drawing.Size(49, 13);
            this.labelControl4.TabIndex = 65;
            this.labelControl4.Text = "Endereço:";
            // 
            // complementoTextEdit
            // 
            this.complementoTextEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.FonecedorDTOBindingSource, "Complemento", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.complementoTextEdit.EnterMoveNextControl = true;
            this.complementoTextEdit.Location = new System.Drawing.Point(579, 94);
            this.complementoTextEdit.Name = "complementoTextEdit";
            this.complementoTextEdit.Properties.MaxLength = 20;
            this.complementoTextEdit.Size = new System.Drawing.Size(131, 20);
            this.complementoTextEdit.TabIndex = 11;
            this.complementoTextEdit.ToolTip = "Complemento";
            // 
            // numeroTextEdit
            // 
            this.numeroTextEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.FonecedorDTOBindingSource, "Numero", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.numeroTextEdit.EnterMoveNextControl = true;
            this.numeroTextEdit.Location = new System.Drawing.Point(579, 66);
            this.numeroTextEdit.Name = "numeroTextEdit";
            this.numeroTextEdit.Properties.MaxLength = 6;
            this.numeroTextEdit.Size = new System.Drawing.Size(131, 20);
            this.numeroTextEdit.TabIndex = 9;
            this.numeroTextEdit.ToolTip = "Número";
            // 
            // enderecoTextEdit
            // 
            this.enderecoTextEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.FonecedorDTOBindingSource, "Endereco", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.enderecoTextEdit.EnterMoveNextControl = true;
            this.enderecoTextEdit.Location = new System.Drawing.Point(89, 66);
            this.enderecoTextEdit.Name = "enderecoTextEdit";
            this.enderecoTextEdit.Properties.MaxLength = 50;
            this.enderecoTextEdit.Size = new System.Drawing.Size(400, 20);
            this.enderecoTextEdit.TabIndex = 8;
            this.enderecoTextEdit.ToolTip = "Nome do logradouro";
            // 
            // nomefantasiaTextEdit
            // 
            this.nomefantasiaTextEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.FonecedorDTOBindingSource, "Nomefantasia", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.nomefantasiaTextEdit.EnterMoveNextControl = true;
            this.nomefantasiaTextEdit.Location = new System.Drawing.Point(579, 10);
            this.nomefantasiaTextEdit.MenuManager = this.barManager;
            this.nomefantasiaTextEdit.Name = "nomefantasiaTextEdit";
            this.nomefantasiaTextEdit.Size = new System.Drawing.Size(246, 20);
            this.nomefantasiaTextEdit.TabIndex = 3;
            // 
            // razaosocialTextEdit
            // 
            this.razaosocialTextEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.FonecedorDTOBindingSource, "Razaosocial", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.razaosocialTextEdit.EnterMoveNextControl = true;
            this.razaosocialTextEdit.Location = new System.Drawing.Point(234, 10);
            this.razaosocialTextEdit.MenuManager = this.barManager;
            this.razaosocialTextEdit.Name = "razaosocialTextEdit";
            this.razaosocialTextEdit.Size = new System.Drawing.Size(255, 20);
            this.razaosocialTextEdit.TabIndex = 2;
            // 
            // idTextEdit
            // 
            this.idTextEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.FonecedorDTOBindingSource, "Id", true));
            this.idTextEdit.Enabled = false;
            this.idTextEdit.Location = new System.Drawing.Point(48, 10);
            this.idTextEdit.Name = "idTextEdit";
            this.idTextEdit.Size = new System.Drawing.Size(112, 20);
            this.idTextEdit.TabIndex = 1;
            this.idTextEdit.TabStop = false;
            // 
            // labelControl2
            // 
            this.labelControl2.Location = new System.Drawing.Point(498, 13);
            this.labelControl2.Name = "labelControl2";
            this.labelControl2.Size = new System.Drawing.Size(75, 13);
            this.labelControl2.TabIndex = 3;
            this.labelControl2.Text = "Nome Fantasia:";
            // 
            // labelControl1
            // 
            this.labelControl1.Location = new System.Drawing.Point(164, 13);
            this.labelControl1.Name = "labelControl1";
            this.labelControl1.Size = new System.Drawing.Size(64, 13);
            this.labelControl1.TabIndex = 2;
            this.labelControl1.Text = "Razão Social:";
            // 
            // lblCodigo
            // 
            this.lblCodigo.Location = new System.Drawing.Point(10, 13);
            this.lblCodigo.Name = "lblCodigo";
            this.lblCodigo.Size = new System.Drawing.Size(37, 13);
            this.lblCodigo.TabIndex = 1;
            this.lblCodigo.Text = "Código:";
            // 
            // MunicipioDTOBindingSource
            // 
            this.MunicipioDTOBindingSource.DataSource = typeof(MechTech.Entities.MunicipioDTO);
            // 
            // dxErrorProvider
            // 
            this.dxErrorProvider.ContainerControl = this;
            // 
            // toolTipController
            // 
            this.toolTipController.AllowHtmlText = true;
            this.toolTipController.IconSize = DevExpress.Utils.ToolTipIconSize.Large;
            this.toolTipController.InitialDelay = 1;
            this.toolTipController.Rounded = true;
            this.toolTipController.ShowBeak = true;
            this.toolTipController.ToolTipType = DevExpress.Utils.ToolTipType.SuperTip;
            // 
            // frmUpdateFornecedor
            // 
            this.Appearance.Options.UseFont = true;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(861, 574);
            this.Controls.Add(this.groupControlFornecedores);
            this.Controls.Add(this.barDockControlLeft);
            this.Controls.Add(this.barDockControlRight);
            this.Controls.Add(this.barDockControlBottom);
            this.Controls.Add(this.barDockControlTop);
            this.Name = "frmUpdateFornecedor";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.frmUpdateFornecedor_FormClosed);
            this.Load += new System.EventHandler(this.frmUpdateFornecedor_Load);
            ((System.ComponentModel.ISupportInitialize)(this.groupControlFornecedores)).EndInit();
            this.groupControlFornecedores.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.xtraTabControl)).EndInit();
            this.xtraTabControl.ResumeLayout(false);
            this.xtraTabPage1.ResumeLayout(false);
            this.xtraTabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.emailTextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.FonecedorDTOBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.barManager)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SitetextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtRamoAtividade.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.codigoibgeButtonEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl1)).EndInit();
            this.groupControl1.ResumeLayout(false);
            this.groupControl1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtRamalContato.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtCelContato.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtTelContato.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtDDDCelContato.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtEmailContato.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtDDDTelContato.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtNomeContato.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cepTextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.registroTextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cnpjTextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.municipioTextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.faxTextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.imunicipalTextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.telefoneTextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.iestadualTextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dddfaxTextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dddtelefoneTextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.UFTextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bairroTextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.complementoTextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numeroTextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.enderecoTextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nomefantasiaTextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.razaosocialTextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.idTextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.MunicipioDTOBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dxErrorProvider)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private DevExpress.XtraEditors.GroupControl groupControlFornecedores;
        private DevExpress.XtraBars.BarManager barManager;
        private DevExpress.XtraBars.Bar bar2;
        private DevExpress.XtraBars.BarButtonItem btnSalvar;
        private DevExpress.XtraBars.BarButtonItem btnCancelar;
        private DevExpress.XtraBars.BarButtonItem btnPrimeiro;
        private DevExpress.XtraBars.BarButtonItem btnAnterior;
        private DevExpress.XtraBars.BarButtonItem btnProximo;
        private DevExpress.XtraBars.BarButtonItem btnUltimo;
        private DevExpress.XtraBars.Bar bar3;
        private DevExpress.XtraBars.BarDockControl barDockControlTop;
        private DevExpress.XtraBars.BarDockControl barDockControlBottom;
        private DevExpress.XtraBars.BarDockControl barDockControlLeft;
        private DevExpress.XtraBars.BarDockControl barDockControlRight;
        private DevExpress.XtraTab.XtraTabControl xtraTabControl;
        private DevExpress.XtraTab.XtraTabPage xtraTabPage1;
        private DevExpress.XtraEditors.ButtonEdit cepTextEdit;
        private DevExpress.XtraEditors.LabelControl labelControl17;
        private DevExpress.XtraEditors.TextEdit registroTextEdit;
        private DevExpress.XtraEditors.LabelControl labelControl13;
        private DevExpress.XtraEditors.TextEdit cnpjTextEdit;
        private DevExpress.XtraEditors.LabelControl labelControl10;
        private DevExpress.XtraEditors.TextEdit municipioTextEdit;
        private DevExpress.XtraEditors.TextEdit faxTextEdit;
        private DevExpress.XtraEditors.TextEdit imunicipalTextEdit;
        private DevExpress.XtraEditors.TextEdit telefoneTextEdit;
        private DevExpress.XtraEditors.LabelControl labelControl16;
        private DevExpress.XtraEditors.LabelControl labelControl15;
        private DevExpress.XtraEditors.LabelControl labelControl14;
        private DevExpress.XtraEditors.TextEdit iestadualTextEdit;
        private DevExpress.XtraEditors.LabelControl labelControl12;
        private DevExpress.XtraEditors.LabelControl labelControl11;
        private DevExpress.XtraEditors.TextEdit dddfaxTextEdit;
        private DevExpress.XtraEditors.TextEdit dddtelefoneTextEdit;
        private DevExpress.XtraEditors.TextEdit UFTextEdit;
        private DevExpress.XtraEditors.LabelControl labelControl9;
        private DevExpress.XtraEditors.LabelControl labelControl8;
        private DevExpress.XtraEditors.LabelControl labelControl7;
        private DevExpress.XtraEditors.TextEdit bairroTextEdit;
        private DevExpress.XtraEditors.LabelControl labelControl6;
        private DevExpress.XtraEditors.LabelControl labelControl5;
        private DevExpress.XtraEditors.LabelControl labelControl4;
        private DevExpress.XtraEditors.TextEdit complementoTextEdit;
        private DevExpress.XtraEditors.TextEdit numeroTextEdit;
        private DevExpress.XtraEditors.TextEdit enderecoTextEdit;
        private DevExpress.XtraEditors.TextEdit nomefantasiaTextEdit;
        private DevExpress.XtraEditors.TextEdit razaosocialTextEdit;
        private DevExpress.XtraEditors.TextEdit idTextEdit;
        private DevExpress.XtraEditors.LabelControl labelControl2;
        private DevExpress.XtraEditors.LabelControl labelControl1;
        private DevExpress.XtraEditors.LabelControl lblCodigo;
        private DevExpress.XtraEditors.DXErrorProvider.DXErrorProvider dxErrorProvider;
        private System.Windows.Forms.BindingSource FonecedorDTOBindingSource;
        private System.Windows.Forms.BindingSource MunicipioDTOBindingSource;
        private DevExpress.XtraEditors.GroupControl groupControl1;
        private DevExpress.XtraEditors.TextEdit SitetextEdit;
        private DevExpress.XtraEditors.TextEdit emailTextEdit;
        private DevExpress.XtraEditors.LabelControl lblSite;
        private DevExpress.XtraEditors.LabelControl labelControl3;
        private DevExpress.XtraEditors.ButtonEdit codigoibgeButtonEdit;
        private DevExpress.Utils.ToolTipController toolTipController;
        private DevExpress.XtraEditors.TextEdit txtRamoAtividade;
        private DevExpress.XtraEditors.LabelControl labelControl18;
        private DevExpress.XtraEditors.TextEdit txtRamalContato;
        private DevExpress.XtraEditors.TextEdit txtCelContato;
        private DevExpress.XtraEditors.TextEdit txtTelContato;
        private DevExpress.XtraEditors.TextEdit txtDDDCelContato;
        private DevExpress.XtraEditors.TextEdit txtEmailContato;
        private DevExpress.XtraEditors.TextEdit txtDDDTelContato;
        private DevExpress.XtraEditors.TextEdit txtNomeContato;
        private DevExpress.XtraEditors.LabelControl labelControl23;
        private DevExpress.XtraEditors.LabelControl labelControl22;
        private DevExpress.XtraEditors.LabelControl labelControl21;
        private DevExpress.XtraEditors.LabelControl labelControl20;
        private DevExpress.XtraEditors.LabelControl labelControl19;
    }
}