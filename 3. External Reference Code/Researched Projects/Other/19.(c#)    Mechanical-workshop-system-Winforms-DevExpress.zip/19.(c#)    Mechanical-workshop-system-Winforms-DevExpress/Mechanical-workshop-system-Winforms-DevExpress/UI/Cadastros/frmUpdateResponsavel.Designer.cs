﻿namespace MechTech.UI.Cadastros
{
    partial class frmUpdateResponsavel
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmUpdateResponsavel));
            DevExpress.Utils.SerializableAppearanceObject serializableAppearanceObject1 = new DevExpress.Utils.SerializableAppearanceObject();
            DevExpress.Utils.SerializableAppearanceObject serializableAppearanceObject2 = new DevExpress.Utils.SerializableAppearanceObject();
            this.dxErrorProvider = new DevExpress.XtraEditors.DXErrorProvider.DXErrorProvider(this.components);
            this.barManager = new DevExpress.XtraBars.BarManager(this.components);
            this.bar2 = new DevExpress.XtraBars.Bar();
            this.btnSalvar = new DevExpress.XtraBars.BarButtonItem();
            this.btnCancelar = new DevExpress.XtraBars.BarButtonItem();
            this.barDockControlTop = new DevExpress.XtraBars.BarDockControl();
            this.barDockControlBottom = new DevExpress.XtraBars.BarDockControl();
            this.barDockControlLeft = new DevExpress.XtraBars.BarDockControl();
            this.barDockControlRight = new DevExpress.XtraBars.BarDockControl();
            this.ResponsavelDTOBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.UFDTOBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.grpPrincipal = new DevExpress.XtraEditors.GroupControl();
            this.xtraTabControl = new DevExpress.XtraTab.XtraTabControl();
            this.xtraTabPage1 = new DevExpress.XtraTab.XtraTabPage();
            this.xtraTabPage2 = new DevExpress.XtraTab.XtraTabPage();
            this.textEdit3 = new DevExpress.XtraEditors.TextEdit();
            this.textEdit2 = new DevExpress.XtraEditors.TextEdit();
            this.labelControl29 = new DevExpress.XtraEditors.LabelControl();
            this.cepTextEdit = new DevExpress.XtraEditors.ButtonEdit();
            this.DataNascimentoDateEdit = new DevExpress.XtraEditors.DateEdit();
            this.labelControl28 = new DevExpress.XtraEditors.LabelControl();
            this.URLTextEdit = new DevExpress.XtraEditors.TextEdit();
            this.contatoTextEdit = new DevExpress.XtraEditors.TextEdit();
            this.labelControl25 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl24 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl23 = new DevExpress.XtraEditors.LabelControl();
            this.emailTextEdit = new DevExpress.XtraEditors.TextEdit();
            this.faxTextEdit = new DevExpress.XtraEditors.TextEdit();
            this.labelControl12 = new DevExpress.XtraEditors.LabelControl();
            this.dddfaxTextEdit = new DevExpress.XtraEditors.TextEdit();
            this.telefoneTextEdit = new DevExpress.XtraEditors.TextEdit();
            this.labelControl11 = new DevExpress.XtraEditors.LabelControl();
            this.dddtelefoneTextEdit = new DevExpress.XtraEditors.TextEdit();
            this.labelControl10 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl9 = new DevExpress.XtraEditors.LabelControl();
            this.UFTextEdit = new DevExpress.XtraEditors.TextEdit();
            this.municipioTextEdit = new DevExpress.XtraEditors.TextEdit();
            this.codigoIBGEButtonEdit = new DevExpress.XtraEditors.ButtonEdit();
            this.labelControl8 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl7 = new DevExpress.XtraEditors.LabelControl();
            this.complementoTextEdit = new DevExpress.XtraEditors.TextEdit();
            this.labelControl6 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl5 = new DevExpress.XtraEditors.LabelControl();
            this.bairroTextEdit = new DevExpress.XtraEditors.TextEdit();
            this.labelControl4 = new DevExpress.XtraEditors.LabelControl();
            this.numeroTextEdit = new DevExpress.XtraEditors.TextEdit();
            this.labelControl3 = new DevExpress.XtraEditors.LabelControl();
            this.enderecoTextEdit = new DevExpress.XtraEditors.TextEdit();
            this.labelControl2 = new DevExpress.XtraEditors.LabelControl();
            this.nomeTextEdit = new DevExpress.XtraEditors.TextEdit();
            this.labelControl1 = new DevExpress.XtraEditors.LabelControl();
            this.idTextEdit = new DevExpress.XtraEditors.TextEdit();
            this.xtraTabPage3 = new DevExpress.XtraTab.XtraTabPage();
            this.UFNumeroRegistroLookUpEdit = new DevExpress.XtraEditors.LookUpEdit();
            this.labelControl21 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl20 = new DevExpress.XtraEditors.LabelControl();
            this.UFRGLookUpEdit = new DevExpress.XtraEditors.LookUpEdit();
            this.labelControl19 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl18 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl17 = new DevExpress.XtraEditors.LabelControl();
            this.ceiTextEdit = new DevExpress.XtraEditors.TextEdit();
            this.labelControl16 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl15 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl14 = new DevExpress.XtraEditors.LabelControl();
            this.cpfTextEdit = new DevExpress.XtraEditors.TextEdit();
            this.cnpjTextEdit = new DevExpress.XtraEditors.TextEdit();
            this.labelControl13 = new DevExpress.XtraEditors.LabelControl();
            this.rgemissorTextEdit = new DevExpress.XtraEditors.TextEdit();
            this.rgTextEdit = new DevExpress.XtraEditors.TextEdit();
            this.numeroregistroTextEdit = new DevExpress.XtraEditors.TextEdit();
            this.nitTextEdit = new DevExpress.XtraEditors.TextEdit();
            this.FimAtividadeDateEdit = new DevExpress.XtraEditors.DateEdit();
            this.labelControl22 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl27 = new DevExpress.XtraEditors.LabelControl();
            this.cargoTextEdit = new DevExpress.XtraEditors.TextEdit();
            this.InicioAtividadeDateEdit = new DevExpress.XtraEditors.DateEdit();
            this.labelControl26 = new DevExpress.XtraEditors.LabelControl();
            this.responsaCheckEdit = new DevExpress.XtraEditors.CheckEdit();
            this.contadorCheckEdit = new DevExpress.XtraEditors.CheckEdit();
            ((System.ComponentModel.ISupportInitialize)(this.dxErrorProvider)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.barManager)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ResponsavelDTOBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.UFDTOBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.grpPrincipal)).BeginInit();
            this.grpPrincipal.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.xtraTabControl)).BeginInit();
            this.xtraTabControl.SuspendLayout();
            this.xtraTabPage1.SuspendLayout();
            this.xtraTabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit3.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit2.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cepTextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DataNascimentoDateEdit.Properties.CalendarTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DataNascimentoDateEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.URLTextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.contatoTextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emailTextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.faxTextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dddfaxTextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.telefoneTextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dddtelefoneTextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.UFTextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.municipioTextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.codigoIBGEButtonEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.complementoTextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bairroTextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numeroTextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.enderecoTextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nomeTextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.idTextEdit.Properties)).BeginInit();
            this.xtraTabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.UFNumeroRegistroLookUpEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.UFRGLookUpEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ceiTextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cpfTextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cnpjTextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rgemissorTextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rgTextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numeroregistroTextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nitTextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.FimAtividadeDateEdit.Properties.CalendarTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.FimAtividadeDateEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cargoTextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.InicioAtividadeDateEdit.Properties.CalendarTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.InicioAtividadeDateEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.responsaCheckEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.contadorCheckEdit.Properties)).BeginInit();
            this.SuspendLayout();
            // 
            // dxErrorProvider
            // 
            this.dxErrorProvider.ContainerControl = this;
            // 
            // barManager
            // 
            this.barManager.Bars.AddRange(new DevExpress.XtraBars.Bar[] {
            this.bar2});
            this.barManager.DockControls.Add(this.barDockControlTop);
            this.barManager.DockControls.Add(this.barDockControlBottom);
            this.barManager.DockControls.Add(this.barDockControlLeft);
            this.barManager.DockControls.Add(this.barDockControlRight);
            this.barManager.Form = this;
            this.barManager.Items.AddRange(new DevExpress.XtraBars.BarItem[] {
            this.btnSalvar,
            this.btnCancelar});
            this.barManager.MainMenu = this.bar2;
            this.barManager.MaxItemId = 6;
            // 
            // bar2
            // 
            this.bar2.BarName = "Main menu";
            this.bar2.DockCol = 0;
            this.bar2.DockRow = 0;
            this.bar2.DockStyle = DevExpress.XtraBars.BarDockStyle.Top;
            this.bar2.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(DevExpress.XtraBars.BarLinkUserDefines.PaintStyle, this.btnSalvar, DevExpress.XtraBars.BarItemPaintStyle.CaptionGlyph),
            new DevExpress.XtraBars.LinkPersistInfo(DevExpress.XtraBars.BarLinkUserDefines.PaintStyle, this.btnCancelar, DevExpress.XtraBars.BarItemPaintStyle.CaptionGlyph)});
            this.bar2.OptionsBar.AllowQuickCustomization = false;
            this.bar2.OptionsBar.DrawBorder = false;
            this.bar2.OptionsBar.UseWholeRow = true;
            this.bar2.Text = "Menu principal";
            // 
            // btnSalvar
            // 
            this.btnSalvar.Caption = "&Salvar";
            this.btnSalvar.Glyph = ((System.Drawing.Image)(resources.GetObject("btnSalvar.Glyph")));
            this.btnSalvar.Id = 0;
            this.btnSalvar.LargeGlyph = ((System.Drawing.Image)(resources.GetObject("btnSalvar.LargeGlyph")));
            this.btnSalvar.Name = "btnSalvar";
            this.btnSalvar.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnSalvar_ItemClick);
            // 
            // btnCancelar
            // 
            this.btnCancelar.Caption = "&Cancelar";
            this.btnCancelar.Glyph = ((System.Drawing.Image)(resources.GetObject("btnCancelar.Glyph")));
            this.btnCancelar.Id = 1;
            this.btnCancelar.LargeGlyph = ((System.Drawing.Image)(resources.GetObject("btnCancelar.LargeGlyph")));
            this.btnCancelar.Name = "btnCancelar";
            this.btnCancelar.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnCancelar_ItemClick);
            // 
            // barDockControlTop
            // 
            this.barDockControlTop.CausesValidation = false;
            this.barDockControlTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.barDockControlTop.Location = new System.Drawing.Point(0, 0);
            this.barDockControlTop.Size = new System.Drawing.Size(1199, 24);
            // 
            // barDockControlBottom
            // 
            this.barDockControlBottom.CausesValidation = false;
            this.barDockControlBottom.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.barDockControlBottom.Location = new System.Drawing.Point(0, 574);
            this.barDockControlBottom.Size = new System.Drawing.Size(1199, 0);
            // 
            // barDockControlLeft
            // 
            this.barDockControlLeft.CausesValidation = false;
            this.barDockControlLeft.Dock = System.Windows.Forms.DockStyle.Left;
            this.barDockControlLeft.Location = new System.Drawing.Point(0, 24);
            this.barDockControlLeft.Size = new System.Drawing.Size(0, 550);
            // 
            // barDockControlRight
            // 
            this.barDockControlRight.CausesValidation = false;
            this.barDockControlRight.Dock = System.Windows.Forms.DockStyle.Right;
            this.barDockControlRight.Location = new System.Drawing.Point(1199, 24);
            this.barDockControlRight.Size = new System.Drawing.Size(0, 550);
            // 
            // ResponsavelDTOBindingSource
            // 
            this.ResponsavelDTOBindingSource.DataSource = typeof(MechTech.Entities.ResponsavelDTO);
            // 
            // UFDTOBindingSource
            // 
            this.UFDTOBindingSource.DataSource = typeof(MechTech.Entities.UFDTO);
            // 
            // grpPrincipal
            // 
            this.grpPrincipal.AppearanceCaption.Options.UseTextOptions = true;
            this.grpPrincipal.AppearanceCaption.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.grpPrincipal.CaptionLocation = DevExpress.Utils.Locations.Left;
            this.grpPrincipal.Controls.Add(this.xtraTabControl);
            this.grpPrincipal.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grpPrincipal.Location = new System.Drawing.Point(0, 24);
            this.grpPrincipal.Name = "grpPrincipal";
            this.grpPrincipal.Size = new System.Drawing.Size(1199, 550);
            this.grpPrincipal.TabIndex = 4;
            this.grpPrincipal.Text = "Responsável";
            // 
            // xtraTabControl
            // 
            this.xtraTabControl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.xtraTabControl.Location = new System.Drawing.Point(21, 2);
            this.xtraTabControl.Name = "xtraTabControl";
            this.xtraTabControl.SelectedTabPage = this.xtraTabPage1;
            this.xtraTabControl.Size = new System.Drawing.Size(1176, 546);
            this.xtraTabControl.TabIndex = 39;
            this.xtraTabControl.TabPages.AddRange(new DevExpress.XtraTab.XtraTabPage[] {
            this.xtraTabPage1,
            this.xtraTabPage2,
            this.xtraTabPage3});
            // 
            // xtraTabPage1
            // 
            this.xtraTabPage1.Controls.Add(this.textEdit3);
            this.xtraTabPage1.Controls.Add(this.textEdit2);
            this.xtraTabPage1.Controls.Add(this.labelControl29);
            this.xtraTabPage1.Controls.Add(this.cepTextEdit);
            this.xtraTabPage1.Controls.Add(this.DataNascimentoDateEdit);
            this.xtraTabPage1.Controls.Add(this.labelControl28);
            this.xtraTabPage1.Controls.Add(this.URLTextEdit);
            this.xtraTabPage1.Controls.Add(this.contatoTextEdit);
            this.xtraTabPage1.Controls.Add(this.labelControl25);
            this.xtraTabPage1.Controls.Add(this.labelControl24);
            this.xtraTabPage1.Controls.Add(this.labelControl23);
            this.xtraTabPage1.Controls.Add(this.emailTextEdit);
            this.xtraTabPage1.Controls.Add(this.faxTextEdit);
            this.xtraTabPage1.Controls.Add(this.labelControl12);
            this.xtraTabPage1.Controls.Add(this.dddfaxTextEdit);
            this.xtraTabPage1.Controls.Add(this.telefoneTextEdit);
            this.xtraTabPage1.Controls.Add(this.labelControl11);
            this.xtraTabPage1.Controls.Add(this.dddtelefoneTextEdit);
            this.xtraTabPage1.Controls.Add(this.labelControl10);
            this.xtraTabPage1.Controls.Add(this.labelControl9);
            this.xtraTabPage1.Controls.Add(this.UFTextEdit);
            this.xtraTabPage1.Controls.Add(this.municipioTextEdit);
            this.xtraTabPage1.Controls.Add(this.codigoIBGEButtonEdit);
            this.xtraTabPage1.Controls.Add(this.labelControl8);
            this.xtraTabPage1.Controls.Add(this.labelControl7);
            this.xtraTabPage1.Controls.Add(this.complementoTextEdit);
            this.xtraTabPage1.Controls.Add(this.labelControl6);
            this.xtraTabPage1.Controls.Add(this.labelControl5);
            this.xtraTabPage1.Controls.Add(this.bairroTextEdit);
            this.xtraTabPage1.Controls.Add(this.labelControl4);
            this.xtraTabPage1.Controls.Add(this.numeroTextEdit);
            this.xtraTabPage1.Controls.Add(this.labelControl3);
            this.xtraTabPage1.Controls.Add(this.enderecoTextEdit);
            this.xtraTabPage1.Controls.Add(this.labelControl2);
            this.xtraTabPage1.Controls.Add(this.nomeTextEdit);
            this.xtraTabPage1.Controls.Add(this.labelControl1);
            this.xtraTabPage1.Controls.Add(this.idTextEdit);
            this.xtraTabPage1.Name = "xtraTabPage1";
            this.xtraTabPage1.Size = new System.Drawing.Size(1170, 518);
            this.xtraTabPage1.Text = "Básico";
            // 
            // xtraTabPage2
            // 
            this.xtraTabPage2.Controls.Add(this.UFNumeroRegistroLookUpEdit);
            this.xtraTabPage2.Controls.Add(this.labelControl13);
            this.xtraTabPage2.Controls.Add(this.labelControl21);
            this.xtraTabPage2.Controls.Add(this.nitTextEdit);
            this.xtraTabPage2.Controls.Add(this.labelControl20);
            this.xtraTabPage2.Controls.Add(this.numeroregistroTextEdit);
            this.xtraTabPage2.Controls.Add(this.UFRGLookUpEdit);
            this.xtraTabPage2.Controls.Add(this.rgTextEdit);
            this.xtraTabPage2.Controls.Add(this.labelControl19);
            this.xtraTabPage2.Controls.Add(this.rgemissorTextEdit);
            this.xtraTabPage2.Controls.Add(this.labelControl18);
            this.xtraTabPage2.Controls.Add(this.cnpjTextEdit);
            this.xtraTabPage2.Controls.Add(this.labelControl17);
            this.xtraTabPage2.Controls.Add(this.cpfTextEdit);
            this.xtraTabPage2.Controls.Add(this.ceiTextEdit);
            this.xtraTabPage2.Controls.Add(this.labelControl14);
            this.xtraTabPage2.Controls.Add(this.labelControl16);
            this.xtraTabPage2.Controls.Add(this.labelControl15);
            this.xtraTabPage2.Name = "xtraTabPage2";
            this.xtraTabPage2.Size = new System.Drawing.Size(1170, 518);
            this.xtraTabPage2.Text = "Documentos";
            // 
            // textEdit3
            // 
            this.textEdit3.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.ResponsavelDTOBindingSource, "Dddcelular", true));
            this.textEdit3.EnterMoveNextControl = true;
            this.textEdit3.Location = new System.Drawing.Point(551, 115);
            this.textEdit3.Name = "textEdit3";
            this.textEdit3.Properties.Appearance.Options.UseTextOptions = true;
            this.textEdit3.Properties.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.textEdit3.Properties.MaxLength = 2;
            this.textEdit3.Size = new System.Drawing.Size(35, 20);
            this.textEdit3.TabIndex = 54;
            this.textEdit3.ToolTip = "DDD do número do Celular";
            // 
            // textEdit2
            // 
            this.textEdit2.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.ResponsavelDTOBindingSource, "Celular", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.textEdit2.EnterMoveNextControl = true;
            this.textEdit2.Location = new System.Drawing.Point(592, 115);
            this.textEdit2.Name = "textEdit2";
            this.textEdit2.Properties.MaxLength = 9;
            this.textEdit2.Size = new System.Drawing.Size(97, 20);
            this.textEdit2.TabIndex = 55;
            this.textEdit2.ToolTip = "Número do Celular";
            // 
            // labelControl29
            // 
            this.labelControl29.Location = new System.Drawing.Point(487, 118);
            this.labelControl29.Name = "labelControl29";
            this.labelControl29.Size = new System.Drawing.Size(37, 13);
            this.labelControl29.TabIndex = 72;
            this.labelControl29.Text = "Celular:";
            // 
            // cepTextEdit
            // 
            this.cepTextEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.ResponsavelDTOBindingSource, "Cep", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.cepTextEdit.EnterMoveNextControl = true;
            this.cepTextEdit.Location = new System.Drawing.Point(57, 36);
            this.cepTextEdit.Name = "cepTextEdit";
            this.cepTextEdit.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Glyph, "", -1, true, true, false, DevExpress.XtraEditors.ImageLocation.MiddleCenter, ((System.Drawing.Image)(resources.GetObject("cepTextEdit.Properties.Buttons"))), new DevExpress.Utils.KeyShortcut(System.Windows.Forms.Keys.None), serializableAppearanceObject1, "", null, null, false)});
            this.cepTextEdit.Properties.Mask.EditMask = "99.999-999";
            this.cepTextEdit.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Simple;
            this.cepTextEdit.Properties.Mask.SaveLiteral = false;
            this.cepTextEdit.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.cepTextEdit.Properties.MaxLength = 8;
            this.cepTextEdit.Size = new System.Drawing.Size(100, 22);
            this.cepTextEdit.TabIndex = 41;
            this.cepTextEdit.ToolTip = "Código de endereçamento postal fornecido pelos CORREIOS";
            this.cepTextEdit.ButtonClick += new DevExpress.XtraEditors.Controls.ButtonPressedEventHandler(this.cepTextEdit_ButtonClick);
            this.cepTextEdit.Validated += new System.EventHandler(this.cepTextEdit_Validated);
            // 
            // DataNascimentoDateEdit
            // 
            this.DataNascimentoDateEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.ResponsavelDTOBindingSource, "DataNascimento", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.DataNascimentoDateEdit.EditValue = null;
            this.DataNascimentoDateEdit.EnterMoveNextControl = true;
            this.DataNascimentoDateEdit.Location = new System.Drawing.Point(550, 88);
            this.DataNascimentoDateEdit.MenuManager = this.barManager;
            this.DataNascimentoDateEdit.Name = "DataNascimentoDateEdit";
            this.DataNascimentoDateEdit.Properties.Appearance.Options.UseTextOptions = true;
            this.DataNascimentoDateEdit.Properties.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.DataNascimentoDateEdit.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.DataNascimentoDateEdit.Properties.CalendarTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            this.DataNascimentoDateEdit.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.DateTimeAdvancingCaret;
            this.DataNascimentoDateEdit.Size = new System.Drawing.Size(139, 20);
            this.DataNascimentoDateEdit.TabIndex = 49;
            // 
            // labelControl28
            // 
            this.labelControl28.Location = new System.Drawing.Point(487, 91);
            this.labelControl28.Name = "labelControl28";
            this.labelControl28.Size = new System.Drawing.Size(57, 13);
            this.labelControl28.TabIndex = 69;
            this.labelControl28.Text = "Data Nasc.:";
            // 
            // URLTextEdit
            // 
            this.URLTextEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.ResponsavelDTOBindingSource, "URL", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.URLTextEdit.EnterMoveNextControl = true;
            this.URLTextEdit.Location = new System.Drawing.Point(57, 167);
            this.URLTextEdit.Name = "URLTextEdit";
            this.URLTextEdit.Properties.MaxLength = 60;
            this.URLTextEdit.Size = new System.Drawing.Size(632, 20);
            this.URLTextEdit.TabIndex = 57;
            // 
            // contatoTextEdit
            // 
            this.contatoTextEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.ResponsavelDTOBindingSource, "Contato", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.contatoTextEdit.EnterMoveNextControl = true;
            this.contatoTextEdit.Location = new System.Drawing.Point(57, 141);
            this.contatoTextEdit.Name = "contatoTextEdit";
            this.contatoTextEdit.Properties.MaxLength = 50;
            this.contatoTextEdit.Size = new System.Drawing.Size(632, 20);
            this.contatoTextEdit.TabIndex = 56;
            // 
            // labelControl25
            // 
            this.labelControl25.Location = new System.Drawing.Point(4, 170);
            this.labelControl25.Name = "labelControl25";
            this.labelControl25.Size = new System.Drawing.Size(22, 13);
            this.labelControl25.TabIndex = 74;
            this.labelControl25.Text = "Site:";
            // 
            // labelControl24
            // 
            this.labelControl24.Location = new System.Drawing.Point(4, 144);
            this.labelControl24.Name = "labelControl24";
            this.labelControl24.Size = new System.Drawing.Size(43, 13);
            this.labelControl24.TabIndex = 73;
            this.labelControl24.Text = "Contato:";
            // 
            // labelControl23
            // 
            this.labelControl23.Location = new System.Drawing.Point(4, 196);
            this.labelControl23.Name = "labelControl23";
            this.labelControl23.Size = new System.Drawing.Size(28, 13);
            this.labelControl23.TabIndex = 75;
            this.labelControl23.Text = "Email:";
            // 
            // emailTextEdit
            // 
            this.emailTextEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.ResponsavelDTOBindingSource, "Email", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.emailTextEdit.EnterMoveNextControl = true;
            this.emailTextEdit.Location = new System.Drawing.Point(57, 193);
            this.emailTextEdit.Name = "emailTextEdit";
            this.emailTextEdit.Properties.CharacterCasing = System.Windows.Forms.CharacterCasing.Lower;
            this.emailTextEdit.Properties.Mask.IgnoreMaskBlank = false;
            this.emailTextEdit.Properties.Mask.ShowPlaceHolders = false;
            this.emailTextEdit.Properties.MaxLength = 40;
            this.emailTextEdit.Size = new System.Drawing.Size(632, 20);
            this.emailTextEdit.TabIndex = 58;
            this.emailTextEdit.ToolTip = "Endereço de email para contato";
            // 
            // faxTextEdit
            // 
            this.faxTextEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.ResponsavelDTOBindingSource, "Fax", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.faxTextEdit.EnterMoveNextControl = true;
            this.faxTextEdit.Location = new System.Drawing.Point(365, 114);
            this.faxTextEdit.Name = "faxTextEdit";
            this.faxTextEdit.Properties.MaxLength = 9;
            this.faxTextEdit.Size = new System.Drawing.Size(116, 20);
            this.faxTextEdit.TabIndex = 53;
            this.faxTextEdit.ToolTip = "Número do telefone para FAX";
            // 
            // labelControl12
            // 
            this.labelControl12.Location = new System.Drawing.Point(249, 117);
            this.labelControl12.Name = "labelControl12";
            this.labelControl12.Size = new System.Drawing.Size(22, 13);
            this.labelControl12.TabIndex = 71;
            this.labelControl12.Text = "Fax:";
            // 
            // dddfaxTextEdit
            // 
            this.dddfaxTextEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.ResponsavelDTOBindingSource, "Dddfax", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.dddfaxTextEdit.EnterMoveNextControl = true;
            this.dddfaxTextEdit.Location = new System.Drawing.Point(324, 114);
            this.dddfaxTextEdit.Name = "dddfaxTextEdit";
            this.dddfaxTextEdit.Properties.Appearance.Options.UseTextOptions = true;
            this.dddfaxTextEdit.Properties.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.dddfaxTextEdit.Properties.MaxLength = 2;
            this.dddfaxTextEdit.Size = new System.Drawing.Size(35, 20);
            this.dddfaxTextEdit.TabIndex = 52;
            this.dddfaxTextEdit.ToolTip = "DDD do número do FAX";
            // 
            // telefoneTextEdit
            // 
            this.telefoneTextEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.ResponsavelDTOBindingSource, "Telefone", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.telefoneTextEdit.EnterMoveNextControl = true;
            this.telefoneTextEdit.Location = new System.Drawing.Point(98, 115);
            this.telefoneTextEdit.Name = "telefoneTextEdit";
            this.telefoneTextEdit.Properties.MaxLength = 9;
            this.telefoneTextEdit.Size = new System.Drawing.Size(145, 20);
            this.telefoneTextEdit.TabIndex = 51;
            this.telefoneTextEdit.ToolTip = "Número do telefone principal";
            // 
            // labelControl11
            // 
            this.labelControl11.Location = new System.Drawing.Point(4, 118);
            this.labelControl11.Name = "labelControl11";
            this.labelControl11.Size = new System.Drawing.Size(46, 13);
            this.labelControl11.TabIndex = 70;
            this.labelControl11.Text = "Telefone:";
            // 
            // dddtelefoneTextEdit
            // 
            this.dddtelefoneTextEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.ResponsavelDTOBindingSource, "Dddtelefone", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.dddtelefoneTextEdit.EnterMoveNextControl = true;
            this.dddtelefoneTextEdit.Location = new System.Drawing.Point(57, 115);
            this.dddtelefoneTextEdit.Name = "dddtelefoneTextEdit";
            this.dddtelefoneTextEdit.Properties.Appearance.Options.UseTextOptions = true;
            this.dddtelefoneTextEdit.Properties.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.dddtelefoneTextEdit.Properties.MaxLength = 2;
            this.dddtelefoneTextEdit.Size = new System.Drawing.Size(35, 20);
            this.dddtelefoneTextEdit.TabIndex = 50;
            this.dddtelefoneTextEdit.ToolTip = "DDD do telefone principal";
            // 
            // labelControl10
            // 
            this.labelControl10.Location = new System.Drawing.Point(163, 40);
            this.labelControl10.Name = "labelControl10";
            this.labelControl10.Size = new System.Drawing.Size(17, 13);
            this.labelControl10.TabIndex = 62;
            this.labelControl10.Text = "UF:";
            // 
            // labelControl9
            // 
            this.labelControl9.Location = new System.Drawing.Point(487, 40);
            this.labelControl9.Name = "labelControl9";
            this.labelControl9.Size = new System.Drawing.Size(47, 13);
            this.labelControl9.TabIndex = 64;
            this.labelControl9.Text = "Município:";
            // 
            // UFTextEdit
            // 
            this.UFTextEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.ResponsavelDTOBindingSource, "Municipio.UF.Codigo", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.UFTextEdit.Location = new System.Drawing.Point(200, 36);
            this.UFTextEdit.Name = "UFTextEdit";
            this.UFTextEdit.Properties.ReadOnly = true;
            this.UFTextEdit.Size = new System.Drawing.Size(43, 20);
            this.UFTextEdit.TabIndex = 42;
            this.UFTextEdit.TabStop = false;
            this.UFTextEdit.ToolTip = "UF do município";
            // 
            // municipioTextEdit
            // 
            this.municipioTextEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.ResponsavelDTOBindingSource, "Municipio.Nome", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.municipioTextEdit.Location = new System.Drawing.Point(550, 36);
            this.municipioTextEdit.Name = "municipioTextEdit";
            this.municipioTextEdit.Properties.ReadOnly = true;
            this.municipioTextEdit.Size = new System.Drawing.Size(139, 20);
            this.municipioTextEdit.TabIndex = 44;
            this.municipioTextEdit.TabStop = false;
            this.municipioTextEdit.ToolTip = "Nome do município";
            // 
            // codigoIBGEButtonEdit
            // 
            this.codigoIBGEButtonEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.ResponsavelDTOBindingSource, "Municipio.CodigoIBGE", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.codigoIBGEButtonEdit.EnterMoveNextControl = true;
            this.codigoIBGEButtonEdit.Location = new System.Drawing.Point(324, 36);
            this.codigoIBGEButtonEdit.Name = "codigoIBGEButtonEdit";
            this.codigoIBGEButtonEdit.Properties.Appearance.Options.UseTextOptions = true;
            this.codigoIBGEButtonEdit.Properties.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.codigoIBGEButtonEdit.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Glyph, "", -1, true, true, false, DevExpress.XtraEditors.ImageLocation.MiddleCenter, ((System.Drawing.Image)(resources.GetObject("codigoIBGEButtonEdit.Properties.Buttons"))), new DevExpress.Utils.KeyShortcut(System.Windows.Forms.Keys.None), serializableAppearanceObject2, "", null, null, true)});
            this.codigoIBGEButtonEdit.Properties.Mask.EditMask = "d";
            this.codigoIBGEButtonEdit.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.codigoIBGEButtonEdit.Properties.Mask.SaveLiteral = false;
            this.codigoIBGEButtonEdit.Properties.Mask.ShowPlaceHolders = false;
            this.codigoIBGEButtonEdit.Properties.MaxLength = 7;
            this.codigoIBGEButtonEdit.Size = new System.Drawing.Size(157, 22);
            this.codigoIBGEButtonEdit.TabIndex = 43;
            this.codigoIBGEButtonEdit.ToolTip = "Código do município conforme tabela do IBGE";
            this.codigoIBGEButtonEdit.ButtonClick += new DevExpress.XtraEditors.Controls.ButtonPressedEventHandler(this.codigoIBGEButtonEdit_ButtonClick);
            this.codigoIBGEButtonEdit.Validated += new System.EventHandler(this.codigoIBGEButtonEdit_Validated);
            // 
            // labelControl8
            // 
            this.labelControl8.Location = new System.Drawing.Point(249, 40);
            this.labelControl8.Name = "labelControl8";
            this.labelControl8.Size = new System.Drawing.Size(54, 13);
            this.labelControl8.TabIndex = 63;
            this.labelControl8.Text = "Cód. Mun.:";
            // 
            // labelControl7
            // 
            this.labelControl7.Location = new System.Drawing.Point(249, 91);
            this.labelControl7.Name = "labelControl7";
            this.labelControl7.Size = new System.Drawing.Size(69, 13);
            this.labelControl7.TabIndex = 68;
            this.labelControl7.Text = "Complemento:";
            // 
            // complementoTextEdit
            // 
            this.complementoTextEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.ResponsavelDTOBindingSource, "Complemento", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.complementoTextEdit.EnterMoveNextControl = true;
            this.complementoTextEdit.Location = new System.Drawing.Point(324, 88);
            this.complementoTextEdit.Name = "complementoTextEdit";
            this.complementoTextEdit.Properties.MaxLength = 20;
            this.complementoTextEdit.Size = new System.Drawing.Size(157, 20);
            this.complementoTextEdit.TabIndex = 48;
            this.complementoTextEdit.ToolTip = "Complemento";
            // 
            // labelControl6
            // 
            this.labelControl6.Location = new System.Drawing.Point(4, 40);
            this.labelControl6.Name = "labelControl6";
            this.labelControl6.Size = new System.Drawing.Size(23, 13);
            this.labelControl6.TabIndex = 61;
            this.labelControl6.Text = "CEP:";
            // 
            // labelControl5
            // 
            this.labelControl5.Location = new System.Drawing.Point(4, 91);
            this.labelControl5.Name = "labelControl5";
            this.labelControl5.Size = new System.Drawing.Size(32, 13);
            this.labelControl5.TabIndex = 67;
            this.labelControl5.Text = "Bairro:";
            // 
            // bairroTextEdit
            // 
            this.bairroTextEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.ResponsavelDTOBindingSource, "Bairro", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.bairroTextEdit.EnterMoveNextControl = true;
            this.bairroTextEdit.Location = new System.Drawing.Point(57, 88);
            this.bairroTextEdit.Name = "bairroTextEdit";
            this.bairroTextEdit.Properties.MaxLength = 20;
            this.bairroTextEdit.Size = new System.Drawing.Size(186, 20);
            this.bairroTextEdit.TabIndex = 47;
            this.bairroTextEdit.ToolTip = "Bairro";
            // 
            // labelControl4
            // 
            this.labelControl4.Location = new System.Drawing.Point(487, 65);
            this.labelControl4.Name = "labelControl4";
            this.labelControl4.Size = new System.Drawing.Size(41, 13);
            this.labelControl4.TabIndex = 66;
            this.labelControl4.Text = "Número:";
            // 
            // numeroTextEdit
            // 
            this.numeroTextEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.ResponsavelDTOBindingSource, "Numero", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.numeroTextEdit.EnterMoveNextControl = true;
            this.numeroTextEdit.Location = new System.Drawing.Point(550, 62);
            this.numeroTextEdit.Name = "numeroTextEdit";
            this.numeroTextEdit.Properties.MaxLength = 6;
            this.numeroTextEdit.Size = new System.Drawing.Size(139, 20);
            this.numeroTextEdit.TabIndex = 46;
            this.numeroTextEdit.ToolTip = "Número";
            // 
            // labelControl3
            // 
            this.labelControl3.Location = new System.Drawing.Point(4, 65);
            this.labelControl3.Name = "labelControl3";
            this.labelControl3.Size = new System.Drawing.Size(49, 13);
            this.labelControl3.TabIndex = 65;
            this.labelControl3.Text = "Endereço:";
            // 
            // enderecoTextEdit
            // 
            this.enderecoTextEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.ResponsavelDTOBindingSource, "Endereco", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.enderecoTextEdit.EnterMoveNextControl = true;
            this.enderecoTextEdit.Location = new System.Drawing.Point(57, 62);
            this.enderecoTextEdit.Name = "enderecoTextEdit";
            this.enderecoTextEdit.Properties.MaxLength = 40;
            this.enderecoTextEdit.Size = new System.Drawing.Size(424, 20);
            this.enderecoTextEdit.TabIndex = 45;
            this.enderecoTextEdit.ToolTip = "Nome do logradouro";
            // 
            // labelControl2
            // 
            this.labelControl2.Location = new System.Drawing.Point(163, 13);
            this.labelControl2.Name = "labelControl2";
            this.labelControl2.Size = new System.Drawing.Size(31, 13);
            this.labelControl2.TabIndex = 60;
            this.labelControl2.Text = "Nome:";
            // 
            // nomeTextEdit
            // 
            this.nomeTextEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.ResponsavelDTOBindingSource, "Nome", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.nomeTextEdit.EnterMoveNextControl = true;
            this.nomeTextEdit.Location = new System.Drawing.Point(200, 10);
            this.nomeTextEdit.Name = "nomeTextEdit";
            this.nomeTextEdit.Properties.MaxLength = 40;
            this.nomeTextEdit.Size = new System.Drawing.Size(489, 20);
            this.nomeTextEdit.TabIndex = 40;
            this.nomeTextEdit.ToolTip = "Nome";
            // 
            // labelControl1
            // 
            this.labelControl1.Location = new System.Drawing.Point(4, 13);
            this.labelControl1.Name = "labelControl1";
            this.labelControl1.Size = new System.Drawing.Size(37, 13);
            this.labelControl1.TabIndex = 59;
            this.labelControl1.Text = "Código:";
            // 
            // idTextEdit
            // 
            this.idTextEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.ResponsavelDTOBindingSource, "Id", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.idTextEdit.Location = new System.Drawing.Point(57, 10);
            this.idTextEdit.Name = "idTextEdit";
            this.idTextEdit.Properties.Appearance.Options.UseTextOptions = true;
            this.idTextEdit.Properties.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.idTextEdit.Properties.ReadOnly = true;
            this.idTextEdit.Size = new System.Drawing.Size(100, 20);
            this.idTextEdit.TabIndex = 39;
            this.idTextEdit.TabStop = false;
            this.idTextEdit.ToolTip = "Código do responsável";
            // 
            // xtraTabPage3
            // 
            this.xtraTabPage3.Controls.Add(this.FimAtividadeDateEdit);
            this.xtraTabPage3.Controls.Add(this.labelControl22);
            this.xtraTabPage3.Controls.Add(this.labelControl27);
            this.xtraTabPage3.Controls.Add(this.cargoTextEdit);
            this.xtraTabPage3.Controls.Add(this.InicioAtividadeDateEdit);
            this.xtraTabPage3.Controls.Add(this.labelControl26);
            this.xtraTabPage3.Controls.Add(this.responsaCheckEdit);
            this.xtraTabPage3.Controls.Add(this.contadorCheckEdit);
            this.xtraTabPage3.Name = "xtraTabPage3";
            this.xtraTabPage3.Size = new System.Drawing.Size(1170, 518);
            this.xtraTabPage3.Text = "Responsabilidades";
            // 
            // UFNumeroRegistroLookUpEdit
            // 
            this.UFNumeroRegistroLookUpEdit.CausesValidation = false;
            this.UFNumeroRegistroLookUpEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.ResponsavelDTOBindingSource, "UFNumeroRegistro.ID", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.UFNumeroRegistroLookUpEdit.EnterMoveNextControl = true;
            this.UFNumeroRegistroLookUpEdit.Location = new System.Drawing.Point(298, 61);
            this.UFNumeroRegistroLookUpEdit.Name = "UFNumeroRegistroLookUpEdit";
            this.UFNumeroRegistroLookUpEdit.Properties.AllowNullInput = DevExpress.Utils.DefaultBoolean.True;
            this.UFNumeroRegistroLookUpEdit.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.UFNumeroRegistroLookUpEdit.Properties.Columns.AddRange(new DevExpress.XtraEditors.Controls.LookUpColumnInfo[] {
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("Codigo", "Sigla", 10, DevExpress.Utils.FormatType.None, "", true, DevExpress.Utils.HorzAlignment.Center),
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("Descricao", 30, "Descrição")});
            this.UFNumeroRegistroLookUpEdit.Properties.DataSource = this.UFDTOBindingSource;
            this.UFNumeroRegistroLookUpEdit.Properties.DisplayMember = "Codigo";
            this.UFNumeroRegistroLookUpEdit.Properties.NullText = "";
            this.UFNumeroRegistroLookUpEdit.Properties.ValueMember = "Id";
            this.UFNumeroRegistroLookUpEdit.Size = new System.Drawing.Size(150, 20);
            this.UFNumeroRegistroLookUpEdit.TabIndex = 51;
            this.UFNumeroRegistroLookUpEdit.ToolTip = "Selecione a UF da emissão do registro. CTRL+DEL para vazio";
            // 
            // labelControl21
            // 
            this.labelControl21.Location = new System.Drawing.Point(271, 64);
            this.labelControl21.Name = "labelControl21";
            this.labelControl21.Size = new System.Drawing.Size(17, 13);
            this.labelControl21.TabIndex = 60;
            this.labelControl21.Text = "UF:";
            // 
            // labelControl20
            // 
            this.labelControl20.Location = new System.Drawing.Point(8, 64);
            this.labelControl20.Name = "labelControl20";
            this.labelControl20.Size = new System.Drawing.Size(104, 13);
            this.labelControl20.TabIndex = 59;
            this.labelControl20.Text = "Nº Reg. no Conselho:";
            this.labelControl20.ToolTip = "Número de Registro no Conselho da Classe";
            // 
            // UFRGLookUpEdit
            // 
            this.UFRGLookUpEdit.CausesValidation = false;
            this.UFRGLookUpEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.ResponsavelDTOBindingSource, "UFRG.ID", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.UFRGLookUpEdit.EnterMoveNextControl = true;
            this.UFRGLookUpEdit.Location = new System.Drawing.Point(600, 35);
            this.UFRGLookUpEdit.Name = "UFRGLookUpEdit";
            this.UFRGLookUpEdit.Properties.AllowNullInput = DevExpress.Utils.DefaultBoolean.True;
            this.UFRGLookUpEdit.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.UFRGLookUpEdit.Properties.Columns.AddRange(new DevExpress.XtraEditors.Controls.LookUpColumnInfo[] {
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("Codigo", "Sigla", 10, DevExpress.Utils.FormatType.None, "", true, DevExpress.Utils.HorzAlignment.Center),
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("Descricao", 30, "Descrição")});
            this.UFRGLookUpEdit.Properties.DataSource = this.UFDTOBindingSource;
            this.UFRGLookUpEdit.Properties.DisplayMember = "Codigo";
            this.UFRGLookUpEdit.Properties.NullText = "";
            this.UFRGLookUpEdit.Properties.ValueMember = "Id";
            this.UFRGLookUpEdit.Size = new System.Drawing.Size(51, 20);
            this.UFRGLookUpEdit.TabIndex = 49;
            this.UFRGLookUpEdit.ToolTip = "Selecione a UF da emissão do RG. CTRL+DEL para vazio";
            // 
            // labelControl19
            // 
            this.labelControl19.Location = new System.Drawing.Point(577, 38);
            this.labelControl19.Name = "labelControl19";
            this.labelControl19.Size = new System.Drawing.Size(17, 13);
            this.labelControl19.TabIndex = 58;
            this.labelControl19.Text = "UF:";
            // 
            // labelControl18
            // 
            this.labelControl18.Location = new System.Drawing.Point(454, 38);
            this.labelControl18.Name = "labelControl18";
            this.labelControl18.Size = new System.Drawing.Size(40, 13);
            this.labelControl18.TabIndex = 57;
            this.labelControl18.Text = "Emissor:";
            // 
            // labelControl17
            // 
            this.labelControl17.Location = new System.Drawing.Point(271, 38);
            this.labelControl17.Name = "labelControl17";
            this.labelControl17.Size = new System.Drawing.Size(18, 13);
            this.labelControl17.TabIndex = 56;
            this.labelControl17.Text = "RG:";
            // 
            // ceiTextEdit
            // 
            this.ceiTextEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.ResponsavelDTOBindingSource, "Cei", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.ceiTextEdit.EnterMoveNextControl = true;
            this.ceiTextEdit.Location = new System.Drawing.Point(115, 35);
            this.ceiTextEdit.Name = "ceiTextEdit";
            this.ceiTextEdit.Properties.Mask.EditMask = "99.999.999.999-9";
            this.ceiTextEdit.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Simple;
            this.ceiTextEdit.Properties.Mask.SaveLiteral = false;
            this.ceiTextEdit.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.ceiTextEdit.Properties.MaxLength = 12;
            this.ceiTextEdit.Size = new System.Drawing.Size(150, 20);
            this.ceiTextEdit.TabIndex = 46;
            this.ceiTextEdit.ToolTip = "Número da CEI caso possua";
            this.ceiTextEdit.Validated += new System.EventHandler(this.ceiTextEdit_Validated);
            // 
            // labelControl16
            // 
            this.labelControl16.Location = new System.Drawing.Point(8, 38);
            this.labelControl16.Name = "labelControl16";
            this.labelControl16.Size = new System.Drawing.Size(21, 13);
            this.labelControl16.TabIndex = 55;
            this.labelControl16.Text = "CEI:";
            // 
            // labelControl15
            // 
            this.labelControl15.Location = new System.Drawing.Point(454, 12);
            this.labelControl15.Name = "labelControl15";
            this.labelControl15.Size = new System.Drawing.Size(21, 13);
            this.labelControl15.TabIndex = 54;
            this.labelControl15.Text = "NIT:";
            // 
            // labelControl14
            // 
            this.labelControl14.Location = new System.Drawing.Point(271, 12);
            this.labelControl14.Name = "labelControl14";
            this.labelControl14.Size = new System.Drawing.Size(23, 13);
            this.labelControl14.TabIndex = 53;
            this.labelControl14.Text = "CPF:";
            // 
            // cpfTextEdit
            // 
            this.cpfTextEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.ResponsavelDTOBindingSource, "Cpf", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.cpfTextEdit.EnterMoveNextControl = true;
            this.cpfTextEdit.Location = new System.Drawing.Point(298, 9);
            this.cpfTextEdit.Name = "cpfTextEdit";
            this.cpfTextEdit.Properties.Mask.EditMask = "999.999.999-99";
            this.cpfTextEdit.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Simple;
            this.cpfTextEdit.Properties.Mask.SaveLiteral = false;
            this.cpfTextEdit.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.cpfTextEdit.Properties.MaxLength = 11;
            this.cpfTextEdit.Size = new System.Drawing.Size(150, 20);
            this.cpfTextEdit.TabIndex = 44;
            this.cpfTextEdit.Tag = "0";
            this.cpfTextEdit.ToolTip = "Número do CPF caso o responsável seja PF";
            this.cpfTextEdit.Validated += new System.EventHandler(this.cpfTextEdit_Validated);
            // 
            // cnpjTextEdit
            // 
            this.cnpjTextEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.ResponsavelDTOBindingSource, "Cnpj", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.cnpjTextEdit.EnterMoveNextControl = true;
            this.cnpjTextEdit.Location = new System.Drawing.Point(115, 9);
            this.cnpjTextEdit.Name = "cnpjTextEdit";
            this.cnpjTextEdit.Properties.Mask.EditMask = "99.999.999/9999-99";
            this.cnpjTextEdit.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Simple;
            this.cnpjTextEdit.Properties.Mask.SaveLiteral = false;
            this.cnpjTextEdit.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.cnpjTextEdit.Properties.MaxLength = 14;
            this.cnpjTextEdit.Size = new System.Drawing.Size(150, 20);
            this.cnpjTextEdit.TabIndex = 43;
            this.cnpjTextEdit.ToolTip = "Número do CNPJ caso o responsável seja PJ";
            this.cnpjTextEdit.Validated += new System.EventHandler(this.cnpjTextEdit_Validated);
            // 
            // labelControl13
            // 
            this.labelControl13.Location = new System.Drawing.Point(8, 12);
            this.labelControl13.Name = "labelControl13";
            this.labelControl13.Size = new System.Drawing.Size(29, 13);
            this.labelControl13.TabIndex = 52;
            this.labelControl13.Text = "CNPJ:";
            // 
            // rgemissorTextEdit
            // 
            this.rgemissorTextEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.ResponsavelDTOBindingSource, "Rgemissor", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.rgemissorTextEdit.EnterMoveNextControl = true;
            this.rgemissorTextEdit.Location = new System.Drawing.Point(500, 35);
            this.rgemissorTextEdit.Name = "rgemissorTextEdit";
            this.rgemissorTextEdit.Properties.MaxLength = 4;
            this.rgemissorTextEdit.Size = new System.Drawing.Size(71, 20);
            this.rgemissorTextEdit.TabIndex = 48;
            this.rgemissorTextEdit.ToolTip = "Orgão emissor do RG";
            // 
            // rgTextEdit
            // 
            this.rgTextEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.ResponsavelDTOBindingSource, "Rg", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.rgTextEdit.EnterMoveNextControl = true;
            this.rgTextEdit.Location = new System.Drawing.Point(298, 35);
            this.rgTextEdit.Name = "rgTextEdit";
            this.rgTextEdit.Properties.MaxLength = 20;
            this.rgTextEdit.Size = new System.Drawing.Size(150, 20);
            this.rgTextEdit.TabIndex = 47;
            this.rgTextEdit.ToolTip = "Número do RG";
            // 
            // numeroregistroTextEdit
            // 
            this.numeroregistroTextEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.ResponsavelDTOBindingSource, "Numeroregistro", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.numeroregistroTextEdit.EnterMoveNextControl = true;
            this.numeroregistroTextEdit.Location = new System.Drawing.Point(115, 61);
            this.numeroregistroTextEdit.Name = "numeroregistroTextEdit";
            this.numeroregistroTextEdit.Properties.MaxLength = 15;
            this.numeroregistroTextEdit.Size = new System.Drawing.Size(150, 20);
            this.numeroregistroTextEdit.TabIndex = 50;
            this.numeroregistroTextEdit.ToolTip = "Número de registro no conselho de classe apropriado";
            // 
            // nitTextEdit
            // 
            this.nitTextEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.ResponsavelDTOBindingSource, "Nit", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.nitTextEdit.EnterMoveNextControl = true;
            this.nitTextEdit.Location = new System.Drawing.Point(500, 9);
            this.nitTextEdit.Name = "nitTextEdit";
            this.nitTextEdit.Properties.MaxLength = 15;
            this.nitTextEdit.Size = new System.Drawing.Size(151, 20);
            this.nitTextEdit.TabIndex = 45;
            this.nitTextEdit.ToolTip = "Número de identificador do trabalhador (NIT)";
            this.nitTextEdit.Validated += new System.EventHandler(this.nitTextEdit_Validated);
            // 
            // FimAtividadeDateEdit
            // 
            this.FimAtividadeDateEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.ResponsavelDTOBindingSource, "FimAtividade", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.FimAtividadeDateEdit.EditValue = null;
            this.FimAtividadeDateEdit.EnterMoveNextControl = true;
            this.FimAtividadeDateEdit.Location = new System.Drawing.Point(324, 36);
            this.FimAtividadeDateEdit.MenuManager = this.barManager;
            this.FimAtividadeDateEdit.Name = "FimAtividadeDateEdit";
            this.FimAtividadeDateEdit.Properties.Appearance.Options.UseTextOptions = true;
            this.FimAtividadeDateEdit.Properties.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.FimAtividadeDateEdit.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.FimAtividadeDateEdit.Properties.CalendarTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            this.FimAtividadeDateEdit.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.DateTimeAdvancingCaret;
            this.FimAtividadeDateEdit.Size = new System.Drawing.Size(100, 20);
            this.FimAtividadeDateEdit.TabIndex = 14;
            // 
            // labelControl22
            // 
            this.labelControl22.Location = new System.Drawing.Point(3, 13);
            this.labelControl22.Name = "labelControl22";
            this.labelControl22.Size = new System.Drawing.Size(33, 13);
            this.labelControl22.TabIndex = 17;
            this.labelControl22.Text = "Cargo:";
            // 
            // labelControl27
            // 
            this.labelControl27.Location = new System.Drawing.Point(226, 39);
            this.labelControl27.Name = "labelControl27";
            this.labelControl27.Size = new System.Drawing.Size(92, 13);
            this.labelControl27.TabIndex = 19;
            this.labelControl27.Text = "Fim das atividades:";
            // 
            // cargoTextEdit
            // 
            this.cargoTextEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.ResponsavelDTOBindingSource, "Cargo", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.cargoTextEdit.EnterMoveNextControl = true;
            this.cargoTextEdit.Location = new System.Drawing.Point(110, 10);
            this.cargoTextEdit.Name = "cargoTextEdit";
            this.cargoTextEdit.Properties.MaxLength = 30;
            this.cargoTextEdit.Size = new System.Drawing.Size(314, 20);
            this.cargoTextEdit.TabIndex = 12;
            this.cargoTextEdit.ToolTip = "Cargo do responsável na empresa";
            // 
            // InicioAtividadeDateEdit
            // 
            this.InicioAtividadeDateEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.ResponsavelDTOBindingSource, "InicioAtividade", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.InicioAtividadeDateEdit.EditValue = null;
            this.InicioAtividadeDateEdit.EnterMoveNextControl = true;
            this.InicioAtividadeDateEdit.Location = new System.Drawing.Point(110, 36);
            this.InicioAtividadeDateEdit.MenuManager = this.barManager;
            this.InicioAtividadeDateEdit.Name = "InicioAtividadeDateEdit";
            this.InicioAtividadeDateEdit.Properties.Appearance.Options.UseTextOptions = true;
            this.InicioAtividadeDateEdit.Properties.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.InicioAtividadeDateEdit.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.InicioAtividadeDateEdit.Properties.CalendarTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            this.InicioAtividadeDateEdit.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.DateTimeAdvancingCaret;
            this.InicioAtividadeDateEdit.Size = new System.Drawing.Size(100, 20);
            this.InicioAtividadeDateEdit.TabIndex = 13;
            // 
            // labelControl26
            // 
            this.labelControl26.Location = new System.Drawing.Point(3, 39);
            this.labelControl26.Name = "labelControl26";
            this.labelControl26.Size = new System.Drawing.Size(101, 13);
            this.labelControl26.TabIndex = 18;
            this.labelControl26.Text = "Início das atividades:";
            // 
            // responsaCheckEdit
            // 
            this.responsaCheckEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.ResponsavelDTOBindingSource, "Responsa", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.responsaCheckEdit.Location = new System.Drawing.Point(429, 35);
            this.responsaCheckEdit.Name = "responsaCheckEdit";
            this.responsaCheckEdit.Properties.Caption = "Responsável";
            this.responsaCheckEdit.Properties.NullStyle = DevExpress.XtraEditors.Controls.StyleIndeterminate.Unchecked;
            this.responsaCheckEdit.Size = new System.Drawing.Size(100, 19);
            this.responsaCheckEdit.TabIndex = 16;
            this.responsaCheckEdit.TabStop = false;
            this.responsaCheckEdit.ToolTip = "É responsável pela empresa (diretor, gerente, presidente, sócio, etc)";
            // 
            // contadorCheckEdit
            // 
            this.contadorCheckEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.ResponsavelDTOBindingSource, "Contador", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.contadorCheckEdit.Location = new System.Drawing.Point(429, 11);
            this.contadorCheckEdit.Name = "contadorCheckEdit";
            this.contadorCheckEdit.Properties.Caption = "Contador";
            this.contadorCheckEdit.Properties.NullStyle = DevExpress.XtraEditors.Controls.StyleIndeterminate.Unchecked;
            this.contadorCheckEdit.Size = new System.Drawing.Size(100, 19);
            this.contadorCheckEdit.TabIndex = 15;
            this.contadorCheckEdit.TabStop = false;
            this.contadorCheckEdit.ToolTip = "É contador ou técnico contábil";
            // 
            // frmUpdateResponsavel
            // 
            this.Appearance.Options.UseFont = true;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1199, 574);
            this.Controls.Add(this.grpPrincipal);
            this.Controls.Add(this.barDockControlLeft);
            this.Controls.Add(this.barDockControlRight);
            this.Controls.Add(this.barDockControlBottom);
            this.Controls.Add(this.barDockControlTop);
            this.Name = "frmUpdateResponsavel";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.frmUpdateResponsavel_FormClosed);
            this.Load += new System.EventHandler(this.frmUpdateResponsavel_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dxErrorProvider)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.barManager)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ResponsavelDTOBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.UFDTOBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.grpPrincipal)).EndInit();
            this.grpPrincipal.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.xtraTabControl)).EndInit();
            this.xtraTabControl.ResumeLayout(false);
            this.xtraTabPage1.ResumeLayout(false);
            this.xtraTabPage1.PerformLayout();
            this.xtraTabPage2.ResumeLayout(false);
            this.xtraTabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit3.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit2.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cepTextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DataNascimentoDateEdit.Properties.CalendarTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DataNascimentoDateEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.URLTextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.contatoTextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emailTextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.faxTextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dddfaxTextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.telefoneTextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dddtelefoneTextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.UFTextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.municipioTextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.codigoIBGEButtonEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.complementoTextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bairroTextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numeroTextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.enderecoTextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nomeTextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.idTextEdit.Properties)).EndInit();
            this.xtraTabPage3.ResumeLayout(false);
            this.xtraTabPage3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.UFNumeroRegistroLookUpEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.UFRGLookUpEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ceiTextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cpfTextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cnpjTextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rgemissorTextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rgTextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numeroregistroTextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nitTextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.FimAtividadeDateEdit.Properties.CalendarTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.FimAtividadeDateEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cargoTextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.InicioAtividadeDateEdit.Properties.CalendarTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.InicioAtividadeDateEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.responsaCheckEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.contadorCheckEdit.Properties)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private DevExpress.XtraEditors.DXErrorProvider.DXErrorProvider dxErrorProvider;
        private DevExpress.XtraEditors.GroupControl grpPrincipal;
        private System.Windows.Forms.BindingSource ResponsavelDTOBindingSource;
        private DevExpress.XtraBars.BarManager barManager;
        private DevExpress.XtraBars.Bar bar2;
        private DevExpress.XtraBars.BarButtonItem btnSalvar;
        private DevExpress.XtraBars.BarButtonItem btnCancelar;
        private DevExpress.XtraBars.BarDockControl barDockControlTop;
        private DevExpress.XtraBars.BarDockControl barDockControlBottom;
        private DevExpress.XtraBars.BarDockControl barDockControlLeft;
        private DevExpress.XtraBars.BarDockControl barDockControlRight;
        private System.Windows.Forms.BindingSource UFDTOBindingSource;
        private DevExpress.XtraTab.XtraTabControl xtraTabControl;
        private DevExpress.XtraTab.XtraTabPage xtraTabPage1;
        private DevExpress.XtraEditors.TextEdit textEdit3;
        private DevExpress.XtraEditors.TextEdit textEdit2;
        private DevExpress.XtraEditors.LabelControl labelControl29;
        private DevExpress.XtraEditors.ButtonEdit cepTextEdit;
        private DevExpress.XtraEditors.DateEdit DataNascimentoDateEdit;
        private DevExpress.XtraEditors.LabelControl labelControl28;
        private DevExpress.XtraEditors.TextEdit URLTextEdit;
        private DevExpress.XtraEditors.TextEdit contatoTextEdit;
        private DevExpress.XtraEditors.LabelControl labelControl25;
        private DevExpress.XtraEditors.LabelControl labelControl24;
        private DevExpress.XtraEditors.LabelControl labelControl23;
        private DevExpress.XtraEditors.TextEdit emailTextEdit;
        private DevExpress.XtraEditors.TextEdit faxTextEdit;
        private DevExpress.XtraEditors.LabelControl labelControl12;
        private DevExpress.XtraEditors.TextEdit dddfaxTextEdit;
        private DevExpress.XtraEditors.TextEdit telefoneTextEdit;
        private DevExpress.XtraEditors.LabelControl labelControl11;
        private DevExpress.XtraEditors.TextEdit dddtelefoneTextEdit;
        private DevExpress.XtraEditors.LabelControl labelControl10;
        private DevExpress.XtraEditors.LabelControl labelControl9;
        private DevExpress.XtraEditors.TextEdit UFTextEdit;
        private DevExpress.XtraEditors.TextEdit municipioTextEdit;
        private DevExpress.XtraEditors.ButtonEdit codigoIBGEButtonEdit;
        private DevExpress.XtraEditors.LabelControl labelControl8;
        private DevExpress.XtraEditors.LabelControl labelControl7;
        private DevExpress.XtraEditors.TextEdit complementoTextEdit;
        private DevExpress.XtraEditors.LabelControl labelControl6;
        private DevExpress.XtraEditors.LabelControl labelControl5;
        private DevExpress.XtraEditors.TextEdit bairroTextEdit;
        private DevExpress.XtraEditors.LabelControl labelControl4;
        private DevExpress.XtraEditors.TextEdit numeroTextEdit;
        private DevExpress.XtraEditors.LabelControl labelControl3;
        private DevExpress.XtraEditors.TextEdit enderecoTextEdit;
        private DevExpress.XtraEditors.LabelControl labelControl2;
        private DevExpress.XtraEditors.TextEdit nomeTextEdit;
        private DevExpress.XtraEditors.LabelControl labelControl1;
        private DevExpress.XtraEditors.TextEdit idTextEdit;
        private DevExpress.XtraTab.XtraTabPage xtraTabPage2;
        private DevExpress.XtraEditors.LookUpEdit UFNumeroRegistroLookUpEdit;
        private DevExpress.XtraEditors.LabelControl labelControl13;
        private DevExpress.XtraEditors.LabelControl labelControl21;
        private DevExpress.XtraEditors.TextEdit nitTextEdit;
        private DevExpress.XtraEditors.LabelControl labelControl20;
        private DevExpress.XtraEditors.TextEdit numeroregistroTextEdit;
        private DevExpress.XtraEditors.LookUpEdit UFRGLookUpEdit;
        private DevExpress.XtraEditors.TextEdit rgTextEdit;
        private DevExpress.XtraEditors.LabelControl labelControl19;
        private DevExpress.XtraEditors.TextEdit rgemissorTextEdit;
        private DevExpress.XtraEditors.LabelControl labelControl18;
        private DevExpress.XtraEditors.TextEdit cnpjTextEdit;
        private DevExpress.XtraEditors.LabelControl labelControl17;
        private DevExpress.XtraEditors.TextEdit cpfTextEdit;
        private DevExpress.XtraEditors.TextEdit ceiTextEdit;
        private DevExpress.XtraEditors.LabelControl labelControl14;
        private DevExpress.XtraEditors.LabelControl labelControl16;
        private DevExpress.XtraEditors.LabelControl labelControl15;
        private DevExpress.XtraTab.XtraTabPage xtraTabPage3;
        private DevExpress.XtraEditors.DateEdit FimAtividadeDateEdit;
        private DevExpress.XtraEditors.LabelControl labelControl22;
        private DevExpress.XtraEditors.LabelControl labelControl27;
        private DevExpress.XtraEditors.TextEdit cargoTextEdit;
        private DevExpress.XtraEditors.DateEdit InicioAtividadeDateEdit;
        private DevExpress.XtraEditors.LabelControl labelControl26;
        private DevExpress.XtraEditors.CheckEdit responsaCheckEdit;
        private DevExpress.XtraEditors.CheckEdit contadorCheckEdit;
    }
}