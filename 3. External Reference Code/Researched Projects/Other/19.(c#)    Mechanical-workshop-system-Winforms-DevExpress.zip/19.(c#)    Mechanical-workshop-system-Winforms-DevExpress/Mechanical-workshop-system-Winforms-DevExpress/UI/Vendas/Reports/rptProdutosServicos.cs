﻿using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using DevExpress.XtraReports.UI;

using MechTech.Util.Templates.Reports;

namespace MechTech.UI.Vendas.Reports
{
    public partial class rptProdutosServicos : rptBase
    {
        public rptProdutosServicos()
        {
            InitializeComponent();
        }

    }
}
