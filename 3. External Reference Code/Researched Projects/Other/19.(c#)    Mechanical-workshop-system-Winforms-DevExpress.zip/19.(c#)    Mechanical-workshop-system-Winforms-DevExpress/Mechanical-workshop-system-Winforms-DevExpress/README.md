# Mechanical-workshop-system
This app was developed to help mechanical workshops to manage their business and to have all of the information needed to keep
customers happy.

It was main developed with C# and Windows Forms, also it uses some DevExpress components. The main database was PostgreSQL and in this app I'have developed a mechanism that is responsible to make backups and restores to client databases automatically.

This application was developed in my software engineering specialization course only for study purpose, but after I've 
finished my course I had the chance to install it in some mechanical workshops.
