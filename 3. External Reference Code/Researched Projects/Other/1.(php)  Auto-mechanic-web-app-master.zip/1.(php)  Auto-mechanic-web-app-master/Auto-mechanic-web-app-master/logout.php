<?php
require('user.php');
$obj=new user();
$obj->logout();
?>