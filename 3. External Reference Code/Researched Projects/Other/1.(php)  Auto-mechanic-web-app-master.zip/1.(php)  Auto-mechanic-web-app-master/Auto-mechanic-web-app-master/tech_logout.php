<?php
require('Tech.php');
$obj=new tech();
$obj->logout();
?>