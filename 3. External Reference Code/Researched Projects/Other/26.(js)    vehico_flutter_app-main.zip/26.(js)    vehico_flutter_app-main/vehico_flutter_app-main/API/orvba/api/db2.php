<?php
$con = mysqli_connect("localhost","root","","orvba_db");

if($con){
}
else{
	echo "Connection Failed";
	exit();
}
?>