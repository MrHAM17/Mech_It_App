import 'package:customer_app/screens/login_screens/phone_number/phone_body.dart';
import 'package:flutter/material.dart';

class EnterPhoneNumber extends StatelessWidget {
  static String routeName = '/PhoneNumber';
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Body(),
    );
  }
}
