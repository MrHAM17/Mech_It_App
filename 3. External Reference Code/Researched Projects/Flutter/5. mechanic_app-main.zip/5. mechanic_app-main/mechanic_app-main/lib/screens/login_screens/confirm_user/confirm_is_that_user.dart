import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:mechanic_app/screens/login_screens/confirm_user/confirm_body.dart';

class ConfirmThisUser extends StatelessWidget {
  static String routeName = '/ConfirmThatUser';
  @override
  Widget build(BuildContext context) {
    return new Scaffold(
      body: Body(),
    );
  }
}
