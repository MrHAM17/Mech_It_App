// for fonts in the app
//we need also to add them pubspec.yaml
