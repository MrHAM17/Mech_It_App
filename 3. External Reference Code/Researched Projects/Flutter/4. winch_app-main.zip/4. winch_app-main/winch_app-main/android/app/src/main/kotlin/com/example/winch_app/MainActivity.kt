package com.example.winch_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
