// wl functions which used more that ones
