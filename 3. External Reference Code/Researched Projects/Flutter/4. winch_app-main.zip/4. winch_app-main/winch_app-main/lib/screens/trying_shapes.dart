// import 'dart:ui' as ui;
//
// child: CustomPaint(
// size: Size(WIDTH,(WIDTH*0.625).toDouble()), //You can Replace [WIDTH] with your desired width for Custom Paint and height will be calculated automatically
// painter: RPSCustomPainter(),
// ),
//
// class RPSCustomPainter extends CustomPainter{
//
//   @override
//   void paint(Canvas canvas, Size size) {
//
//
//
//     Paint paint_0 = new Paint()
//       ..color = Color.fromARGB(255, 33, 150, 243)
//       ..style = PaintingStyle.stroke
//       ..strokeWidth = 1;
//
//
//     Path path_0 = Path();
//     path_0.moveTo(size.width*0.0012500,size.height);
//     path_0.lineTo(size.width*0.9987500,size.height);
//     path_0.lineTo(size.width,0);
//     path_0.quadraticBezierTo(size.width*0.4996875,size.height*0.5973600,0,0);
//     path_0.quadraticBezierTo(size.width*0.0003125,size.height*0.2500000,size.width*0.0012500,size.height);
//     path_0.close();
//
//     canvas.drawPath(path_0, paint_0);
//
//
//   }
//
//   @override
//   bool shouldRepaint(covariant CustomPainter oldDelegate) {
//     return true;
//   }
//
// }
//
//
// //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//
// import 'dart:ui' as ui;
//
// child: CustomPaint(
// size: Size(WIDTH,(WIDTH*0.625).toDouble()), //You can Replace [WIDTH] with your desired width for Custom Paint and height will be calculated automatically
// painter: RPSCustomPainter(),
// ),
//
//
// class RPSCustomPainter extends CustomPainter{
//
//   @override
//   void paint(Canvas canvas, Size size) {
//
//
//
//     Paint paint_0 = new Paint()
//       ..color = Color.fromARGB(255, 33, 150, 243)
//       ..style = PaintingStyle.stroke
//       ..strokeWidth = 1;
//
//
//     Path path_0 = Path();
//     path_0.moveTo(0,0);
//     path_0.lineTo(size.width*0.9987500,0);
//     path_0.quadraticBezierTo(size.width*0.5006375,size.height*0.5919000,size.width*0.0012500,0);
//     path_0.quadraticBezierTo(size.width*0.0009375,0,0,0);
//     path_0.close();
//
//     canvas.drawPath(path_0, paint_0);
//
//
//   }
//
//   @override
//   bool shouldRepaint(covariant CustomPainter oldDelegate) {
//     return true;
//   }
//
// }
//
//
// /////////////////////////////////////////////////////////////////////////////////
//
// class RPSCustomPainter extends CustomPainter{
//
//   @override
//   void paint(Canvas canvas, Size size) {
//
//
//
//     Paint paint_0 = new Paint()
//       ..color = Color.fromARGB(255, 33, 150, 243)
//       ..style = PaintingStyle.stroke
//       ..strokeWidth = 1;
//
//
//     Path path_0 = Path();
//     path_0.moveTo(0,0);
//     path_0.lineTo(size.width*0.9987500,0);
//     path_0.quadraticBezierTo(size.width*0.4989750,size.height*0.7918000,size.width*0.0012500,0);
//     path_0.quadraticBezierTo(size.width*0.0009375,0,0,0);
//     path_0.close();
//
//     canvas.drawPath(path_0, paint_0);
//
//
//   }
//
//   @override
//   bool shouldRepaint(covariant CustomPainter oldDelegate) {
//     return true;
//   }
//
// }
//
// /////////////////////////////////////////////////////////////////////////////////////////////////
//
// class RPSCustomPainter extends CustomPainter{
//
//   @override
//   void paint(Canvas canvas, Size size) {
//
//
//
//     Paint paint_0 = new Paint()
//       ..color = Color.fromARGB(255, 33, 150, 243)
//       ..style = PaintingStyle.stroke
//       ..strokeWidth = 1;
//
//
//     Path path_0 = Path();
//     path_0.moveTo(size.width*0.0024155,size.height*0.0011774);
//     path_0.lineTo(size.width*0.9951691,size.height*0.0023548);
//     path_0.quadraticBezierTo(size.width*0.5001449,size.height*0.2980220,size.width*0.0024155,0);
//     path_0.quadraticBezierTo(size.width*0.0024155,size.height*0.0002943,size.width*0.0024155,size.height*0.0011774);
//     path_0.close();
//
//     canvas.drawPath(path_0, paint_0);
//
//
//   }
//
//   @override
//   bool shouldRepaint(covariant CustomPainter oldDelegate) {
//     return true;
//   }
//
// }
//
// ////////////////////////////////////////////////////////////////////////////////////////////////////
//
//
// class RPSCustomPainter extends CustomPainter{
//
//   @override
//   void paint(Canvas canvas, Size size) {
//
//
//
//     Paint paint_0 = new Paint()
//       ..color = Color.fromARGB(255, 33, 150, 243)
//       ..style = PaintingStyle.stroke
//       ..strokeWidth = 1;
//
//
//     Path path_0 = Path();
//     path_0.moveTo(size.width*0.0024155,size.height*0.0011774);
//     path_0.lineTo(size.width*0.9951691,size.height*0.0023548);
//     path_0.quadraticBezierTo(size.width*0.5001449,size.height*0.3294584,size.width*0.0024155,0);
//     path_0.quadraticBezierTo(size.width*0.0024155,size.height*0.0002943,size.width*0.0024155,size.height*0.0011774);
//     path_0.close();
//
//     canvas.drawPath(path_0, paint_0);
//
//
//   }
//
//   @override
//   bool shouldRepaint(covariant CustomPainter oldDelegate) {
//     return true;
//   }
//
// }
