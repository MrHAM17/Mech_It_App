import React from "react";

function Button() {

    return (
        <button type="button" className="btn btn-lg" style={{backgroundColor:'#cd0000', width:'100%'}}><a style={{textDecoration:'none', color:'white'}} href="http://localhost:3000/order"><b>order now</b></a></button>
    );
}
export default Button;




