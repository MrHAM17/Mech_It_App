export const FontFamily = {
  light: "Urbanist_300Light",
  regular: "Urbanist_400Regular",
  medium: "Urbanist_500Medium",
  semiBold: "Urbanist_600SemiBold",
  bold: "Urbanist_700Bold",
};
