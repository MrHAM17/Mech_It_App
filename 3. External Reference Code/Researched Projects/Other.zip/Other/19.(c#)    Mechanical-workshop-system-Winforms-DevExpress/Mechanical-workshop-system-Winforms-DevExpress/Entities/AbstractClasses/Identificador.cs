﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MechTech.Entities.AbstractClasses
{
    public abstract class Identificador
    {
        public abstract int Id { get; set; }
    }
}
