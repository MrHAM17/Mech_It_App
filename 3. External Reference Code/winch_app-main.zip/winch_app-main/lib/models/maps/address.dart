class Address
{
    String placeFormattedAddress;
    String placeName;
    String placeId;
    double latitude;
    double longitude;
    String descriptor;

    Address({this.placeFormattedAddress, this.placeName, this.placeId, this.latitude, this.longitude, this.descriptor});
}