class LangModel {
  String language;

  LangModel({this.language});
}
