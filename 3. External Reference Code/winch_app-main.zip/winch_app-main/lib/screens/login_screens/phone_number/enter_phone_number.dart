import 'package:flutter/material.dart';
import 'package:winch_app/screens/login_screens/phone_number/phone_body.dart';

class EnterPhoneNumber extends StatelessWidget {
  static String routeName = '/PhoneNumber';
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Body(),
    );
  }
}
